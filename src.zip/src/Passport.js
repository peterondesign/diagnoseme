import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import { findPassport } from "./actions/booking";
 
import "./css/Auth.css";

class Passport extends Component {
  state = {
    search: {},
    loading: false,
    isSubmitted: false,
    bookingType: 0,
    disable: true
  };

  handleChange = event => {
    const { name, value } = event.target;
    const { search } = this.state;

    this.setState({
      search: {
        ...search,
        [name]: value
      }
    });

  };

  handleSelectChange = event => {

    const { name, value } = event.target;
    const { search } = this.state;

    if (value == 1) {

      this.setState({
        disable: false
      });

    } else {

      this.setState({
        disable: true
      });

    }

    this.setState({
      bookingType: value,
      search: {
        ...search,
        [name]: value
      }
    });

  };

  handleButtonDisable = loading => {
    if (loading) {
      return true;
    }
    return false;
  };

  handleSubmit = event => {

    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let param = event.target.param.value;

    let type = this.state.bookingType;

    const search = {
      param,
      type,
    };

    console.log(search);

    if (search.param && search.type) {

      if (search.type == 1) {

        let booking = {
              booking_type: search.type,
              passport_number: search.param,
              order_id: null
            };

        localStorage.setItem('booking', JSON.stringify(booking));

        this.promise = this.props.findPassport(booking);

        this.promise
          .catch(() => {})
          .then(() => {
            this.setState({ loading: false });
          });
      }
      else if (search.type == 2) {

        let booking = {
              booking_type: search.type,
              order_id: search.param,
              passport_number: null
            };

            localStorage.setItem('booking', JSON.stringify(booking));

        this.promise = this.props.findPassport(booking);

        this.promise
          .catch(() => {})
          .then(() => {
            this.setState({ loading: false });
          });
      }

    } else {
      this.setState({
        loading: false
      });
    }

  };

  render() {

    const { search, loading, isSubmitted } = this.state;

    return (
      <div className="bg-transparent">
        <form className="auth-form-new" onSubmit={this.handleSubmit}>
          <Row>
          <Col md={12}>
              <div
                className={
                  "form-group" +
                  (isSubmitted && !search.param ? " has-error" : "")
                }
              >
                <label>
                  Select Booking type
                  <span className="red-asterisk">*</span>
                </label>
                <select
                  className="form-control"
                  name="type"
                  onChange={e => this.handleSelectChange(e)}
                >
                  <option value="">Choose type</option>
                  <option value="1">Passport Number</option>
                  <option value="2">Order Id</option>
                </select>
                {isSubmitted && !search.type && (
                  <div className="help-block">This field is required</div>
                )}
              </div>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              {(this.state.bookingType == 1 || this.state.bookingType == 0) && (
                <div
                  className={
                    "form-group" +
                    (isSubmitted && !search.param ? " has-error" : "")
                  }
                >
                  <label>
                    Passport Number
                    <span className="red-asterisk">*</span>
                  </label>
                  <input
                    type="text"
                    name="param"
                    className="form-control"
                    placeholder="Enter Passport Number"
                    onChange={this.handleChange}
                    disabled={this.state.disable}
                  />
                  {isSubmitted && !search.param && (
                    <div className="help-block">This field is required</div>
                  )}
                </div>
              )}
              {this.state.bookingType == 2 && (
                <div
                  className={
                    "form-group" +
                    (isSubmitted && !search.param ? " has-error" : "")
                  }
                >
                  <label>
                    Order Id
                    <span className="red-asterisk">*</span>
                  </label>
                  <input
                    type="text"
                    name="param"
                    className="form-control"
                    placeholder="Enter Order Id"
                    onChange={this.handleChange}
                  />
                  {isSubmitted && !search.param && (
                    <div className="help-block">This field is required</div>
                  )}
                </div>
              )}
            </Col>
            <Col md={12}>
              <button
                type="submit"
                className="btn auth-button btn-block"
                disabled={this.handleButtonDisable(loading)}
              >
                {loading && (
                  <i
                    className="fa fa-refresh fa-spin"
                    style={{ marginRight: "5px" }}
                  />
                )}
                {loading && <span>Processing...</span>}
                {!loading && <span>Submit</span>}
              </button>
            </Col>
          </Row>
        </form>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { booking: state.booking };
};

export default connect(mapStateToProps, { findPassport })(Passport);
