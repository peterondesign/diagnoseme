import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import { CookiesProvider } from "react-cookie";

import App from "./components/App";
import reducers from "./reducers";

// import * as serviceWorker from './serviceWorker';

const persistConfig = {
  key: "cart",
  storage: storage,
  whitelist: ["cart", "tests", "address"] // which reducer want to store
};
const pReducer = persistReducer(persistConfig, reducers);

// add this code in production
// const store = createStore(reducers, applyMiddleware(thunk));

// Remove this code in production
const store = createStore(
  pReducer,
  compose(
    applyMiddleware(thunk)
    ,
    window.__REDUX_DEVTOOLS_EXTENSION__
      ? window.__REDUX_DEVTOOLS_EXTENSION__()
      : f => f
  )
);

const persistor = persistStore(store);
export { persistor, store };

ReactDOM.render(
  <Provider store={store}>
    <CookiesProvider>
      <App />
    </CookiesProvider>
  </Provider>,
  document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();
