import axios from 'axios';

// export const API_URL = 'https://api.diagnosemeafrica.com/api/v2/'
export const API_URL = 'https://api-dev.diagnosemeafrica.com/api/v2/'
// export const API_URL = 'http://localhost:8080/api/v2/'

export default axios.create({
    baseURL: API_URL
});
