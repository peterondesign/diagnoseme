import axios from 'axios';

// export const API_URL = 'https://api.diagnosemeafrica.com/api/v1/'
export const API_URL = 'https://api-dev.diagnosemeafrica.com/api/v1/'
// export const API_URL = 'http://localhost:8080/api/v1/'

export default axios.create({
    baseURL: API_URL
});

