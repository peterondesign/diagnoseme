import * as Sentry from '@sentry/react';

class DebugSentry {
    static instantiate(){
        Sentry.init({
            dsn: "https://599a3ca3bcaa4592ac6b539fc9481739@o219546.ingest.sentry.io/1769523",
        });
    }

    static catchException(error, errorInfo){
        Sentry.withScope(scope => {
            Object.keys(errorInfo).forEach(key => {
              scope.setExtra(key, errorInfo[key]);
            });
            Sentry.captureException(error);
        });
    }
}

export default DebugSentry;