import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import bgelementsHomepage from "./assets/images/bgelementsHomepage.svg";

import Passport from "./Passport";
import BookingCalendar from "./Calendar";

import { connect } from "react-redux";

import "./css/Auth.css"; 

const Booking = props => {
  const response = props.center;
  return (
    <div className="bg-transparent">
      {/* <img src={bgelementsHomepage} id="bgelementsOtherpages"></img> */}
      <Container>
        <Row className="mx-auto panel">
          <Col md={8} className="card auth-card mx-auto">
            {props.history.location.pathname == "/success" && (
              <div className="alert alert-success text-center">
                Your appointment has been successfully booked.
              </div>
            )}
            <div className="panel-header">
              <Row className="auth-links-card">
                <div
                  class="nav col-md-12 auth-card-nav"
                  id="myTab"
                  role="tablist"
                >
                  <Link className="order-line" to="/">
                    <div class="text-center register-nav2">
                      Book an appointment
                    </div>
                  </Link>
                </div>
              </Row>

              <div>
                {response &&
                  (response.response === null ||
                    response.response.data === "Resource not found") && (
                    <Passport />
                  )}

                {response &&
                  response.response !== null &&
                    response.response.message ===
                      "Appointment already booked" && <Passport />}

                {response &&
                  response.response !== null &&
                    response.response.success &&
                    response.response.message !==
                      "Appointment already booked" && <BookingCalendar />}
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <ToastContainer autoClose={4000} />
    </div>
  );
};

const mapStateToProps = state => {
  console.log('center',state.center)
  return { center: state.center };
};

export default connect(mapStateToProps, {})(Booking);
