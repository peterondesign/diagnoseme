import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { Row, Col, Alert } from "react-bootstrap";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import { connect } from "react-redux";
import { getTimeSlots } from "./actions/booking";
import diagnosemeApi from "./apis/diagnosemeApi";
import { history } from "./helpers/history";
import { BallPulseSync } from "react-pure-loaders";

import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

const convertTime12to24 = (time12h) => {
  const [time, modifier] = time12h.split(" ");

  let [hours, minutes] = time.split(":");

  if (hours === "12") {
    hours = "00";
  }

  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }

  return `${hours}:${minutes}`;
};

class BookingCalendar extends Component {
  state = {
    selectedDate: new Date(),
    search: {},
    selectedCenter: null,
    dateIsSelected: false,
    loading: false,
    isSubmitted: false,
    workingHours: [],
    list: [],
    btn: false,
    showTime: false,
    forceStateUpdate: 0,
  };

  handleDateChange = (selectedDate) => {
    if (
      this.state.selectedCenter === null ||
      this.state.selectedCenter === undefined
    ) {
      toast.error("Choose a sample collection center to continue");
      this.setState({ dateIsSelected: true });
      return true;
    }

    const { search } = this.state;
    this.setState({ selectedDate, loading: true });
    let date = this.toJSONLocal(selectedDate);
    let collection_center_id = this.state.selectedCenter.id;

    const booking = this.props.booking.response;

    if (date && collection_center_id) {
      let booking = JSON.parse(localStorage.getItem("booking"));

      if (booking.booking_type == 1) {
        this.setState({
          search: {
            ...search,
            date: date,
            passport_number: booking.passport_number,
            order_id: null,
          },
        });
      } else {
        this.setState({
          search: {
            ...search,
            date: date,
            passport_number: null,
            order_id: booking.order_id,
          },
        });
      }
      const payload = {
        collection_center_id,
        date,
      };
      this.setState({ showTime: true });

      this.promise = this.props.getTimeSlots(payload);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });

      this.showTimeSlots(collection_center_id);
    }
  };

  handleTimeSlot = (event) => {
    const { name, value } = event.target;
    const { search } = this.state;

    this.setState({
      search: {
        ...search,
        [name]: value,
      },
      btn: true,
    });
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    const { search } = this.state;

    this.handleShowCenter(value);

    this.setState({
      search: {
        ...search,
        [name]: value,
      },
    });
  };

  handleShowCenter = (center_id) => {
    const { data } = this.props.center.response;
    let selectedCenter = data.find((item) => item.id == center_id);
    this.setState({
      selectedCenter,
      showTime: false,
    });
  };

  showTimeSlots = (center_id) => {
    const { data } = this.props.center.response;

    let selectedCenter = data.find((item) => item.id == center_id);

    let openHour = selectedCenter.open_hour;
    let closeHour = selectedCenter.close_hour;

    let open_time = null;
    if (selectedCenter.open_hour.charAt(2) == ":") {
      open_time = "1" + selectedCenter.open_hour.charAt(1);
    }
    if (
      selectedCenter.open_hour.charAt(2) == "0" ||
      selectedCenter.open_hour.charAt(2) == "1" ||
      selectedCenter.open_hour.charAt(2) == "2"
    ) {
      open_time = selectedCenter.open_hour.charAt();
    }
    let close_time = selectedCenter.close_hour.charAt();

    let list = [];
    let workingHours = [];
    let time = 23;
    let PMConvertion = convertTime12to24(selectedCenter.close_hour + " PM");
    for (var i = open_time; i < time; i++) {
      list.push(i);
      workingHours.push(`${i}:00`);
      if (i + ":00" == PMConvertion) {
        break;
      }
    }
    this.setState({
      list,
      workingHours,
    });

    // this.setState({
    //   forceStateUpdate: 1
    // });
  };

  handleButtonDisable = (loading) => {
    if (loading) {
      return true;
    }
    return false;
  };

  toJSONLocal(date) {
    var local = new Date(date);
    local.setMinutes(date.getMinutes() - date.getTimezoneOffset());
    return local.toJSON().slice(0, 10);
  }

  handleSubmit = (e) => {
    e.preventDefault();
    this.setState({ loading: true });
    diagnosemeApi
      .post(`booking/createReturneeBooking`, this.state.search)
      .then((response) => {
        if (!response.data.success) {
          this.setState({ loading: false });
          alert("Something went wrong!!! Please try again");
        } else {
          history.push("/booking/success");
          // window.location.href = "/booking/success";
        }
      })
      .catch((error) => console.log(error));
  };

  render() {
    const {
      btn,
      showTime,
      search,
      loading,
      workingHours,
      selectedCenter,
      selectedDate,
      dateIsSelected,
    } = this.state;
    const response = this.props.center;
    const booking = this.props.booking.response;
    let booking_count =
      (booking && booking.data !== null && booking.data[0]) || [];
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    let workingHoursArray = workingHours;
    let AvailableHours = [];
    let formattedDate = this.toJSONLocal(selectedDate);

    if (booking) {
      if (booking.message == "No booking yet") {
        AvailableHours = workingHoursArray;
      } else {
        booking.data.map((item, i) => {
          if (item.status == 1) {
            AvailableHours = workingHoursArray.filter(
              (workingHoursArray) => workingHoursArray != item.hour
            );
            workingHoursArray = AvailableHours;
          } else {
            AvailableHours = workingHoursArray;
          }
        });
      }
    }

    return (
      <div className="bg-transparent" id="booking-div" style={{padding: '50px 150px'}}>
        <form className="auth-form-new" onSubmit={this.handleSubmit}>
          <Row>
            <Col md={12}>
              <div
                className={
                  "form-group" +
                  (dateIsSelected && !search.collection_center
                    ? " has-error"
                    : "")
                }
              >
                <label>
                  Sample collection centers in{" "}
                  {response &&
                    response.response.data &&
                    response.response.data[0].state}
                  <span className="red-asterisk">*</span>
                </label>
                <select
                  name="collection_center_id"
                  id="collection_center_id"
                  className="form-control"
                  onChange={this.handleChange}
                >
                  <option value="" defaultValue="selected">
                    - Choose a sample collection center near you -
                  </option>
                  {response.response.data.map(function (center) {
                    return (
                      <option key={center.id} value={center.id}>
                        {center.name} - {center.address}
                      </option>
                    );
                  })}
                </select>
                {dateIsSelected && !search.collection_center && (
                  <div className="help-block">
                    Choose a sample collection center to continue
                  </div>
                )}
              </div>
            </Col>

            <Col md={12}>
              <Calendar
                onChange={this.handleDateChange}
                value={selectedDate}
                activeStartDate={tomorrow}
                tileDisabled={({ activeStartDate, date, view }) =>
                  date.getDay() === 0
                }
                minDate={tomorrow}
              />
            </Col>

            <Col md={12} className="center-display">
              {selectedCenter && selectedCenter != null && (
                <Alert variant="secondary" id="center-alert">
                  <h5 className="center-name" style={{ lineHeight: "25px" }}>
                    <b>{selectedCenter.name}</b>, {selectedCenter.address}
                  </h5>
                  <Row>
                    <Col md={8}>
                      <p className="center-text">
                        <b>Opening hour:</b> {selectedCenter.open_hour}
                      </p>
                    </Col>
                    <Col md={4}>
                      <p className="center-text">
                        <b>Closing hour:</b> {selectedCenter.close_hour}
                      </p>
                    </Col>
                    {/* <Col md={4}><p className="center-text"><b>Capacity:</b> {selectedCenter.capacity} persons/hr</p></Col> */}
                  </Row>
                </Alert>
              )}
            </Col>

            {showTime && loading && (
              <Col md={12} className="center-display">
                <div className="text-center">
                  <BallPulseSync color={"#F05F87"} loading="true" />
                  <p className="loading-p">Fetching available time slots...</p>
                </div>
              </Col>
            )}

            {showTime && AvailableHours.length == 0 && !loading && (
              <Col md={12} className="center-display">
                {selectedCenter && selectedCenter != null && (
                  <Alert variant="secondary" id="center-alert">
                    <h5 className="center-name" style={{ lineHeight: "25px" }}>
                      <b>{`We are sorry, ${selectedCenter.name} is fully booked for ${formattedDate}.`}</b>
                    </h5>
                  </Alert>
                )}
              </Col>
            )}

            {showTime && AvailableHours.length > 0 && !loading && (
              <Col md={12} className="center-display">
                {selectedCenter && selectedCenter != null && (
                  <Alert variant="secondary" id="center-alert">
                    <h5 className="center-name">
                      <b>{"Select your time slot in"}</b>, {selectedCenter.name}
                    </h5>
                    <Row>
                      <select
                        name="time"
                        id="time"
                        className="form-control"
                        onChange={this.handleTimeSlot}
                      >
                        <option value="" defaultValue="selected">
                          - Select Your Time Slot -
                        </option>

                        {booking &&
                          AvailableHours.map((time, i) => (
                            <option key={i} value={time}>
                              {time}
                            </option>
                          ))}
                      </select>
                    </Row>
                  </Alert>
                )}
              </Col>
            )}

            <Col md={12}>
              {btn && (
                <button
                  type="submit"
                  className="btn auth-button btn-block"
                  disabled={this.handleButtonDisable(loading)}
                >
                  {loading && (
                    <i
                      className="fa fa-refresh fa-spin"
                      style={{ marginRight: "5px" }}
                    />
                  )}
                  {loading && <span>Processing...</span>}
                  {!loading && <span>Complete</span>}
                </button>
              )}
            </Col>
          </Row>
        </form>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    booking: state.booking,
    center: state.center,
  };
};

export default connect(mapStateToProps, { getTimeSlots })(
  withRouter(BookingCalendar)
);
