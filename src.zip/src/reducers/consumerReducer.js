import {
  LOGIN,
  REGISTER,
  FORGOT_PASSWORD,
  EMAIL_CHECK,
  PHONE_CHECK,
  TOKEN_CHECK,
  RESET_PASSWORD,
  GET_PIN,
  DEACTIVATE_ACCOUNT,
  DELETE_ACCOUNT,
  CHANGE_PASSWORD,
  COMPLETE_ACCOUNT_SETUP,
  VERIFY_COVID_USER,
  BOOK_RETURNEE_APPOINTMENT,
  GET_RETURNEE_FLIGHT
} from "./../actions/types";

const INITIAL_STATE = {
  loading: false,
  response: null
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case REGISTER:
      return { ...state, loading: false, response: action.payload };
    case LOGIN:
      return {
        ...state,
        loading: false,
        isLoggedIn: true,
        response: action.payload
      };
    case FORGOT_PASSWORD:
      return { ...state, loading: false, response: action.payload };
    case EMAIL_CHECK:
      return { ...state, response: action.payload };
    case PHONE_CHECK:
      return { ...state, response: action.payload };
    case TOKEN_CHECK:
      return { ...state, response: action.payload };
    case RESET_PASSWORD:
      return { ...state, response: action.payload };
    case GET_PIN:
      return { ...state, response: action.payload };
    case DEACTIVATE_ACCOUNT:
      return { ...state, response: action.payload };
    case DELETE_ACCOUNT:
      return { ...state, response: action.payload };
    case CHANGE_PASSWORD:
      return { ...state, response: action.payload };
    case COMPLETE_ACCOUNT_SETUP:
      return { ...state, response: action.payload };
    case VERIFY_COVID_USER:
      return { ...state, response: action.payload }; 
    case BOOK_RETURNEE_APPOINTMENT:
      return { ...state, response: action.payload }; 
    case GET_RETURNEE_FLIGHT:
      return { ...state, response: action.payload }; 
    default:
      return state;
  }
};
