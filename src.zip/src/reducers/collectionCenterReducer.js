import { GET_PASSPORT_NUMBER } from '../actions/types';

const INITIAL_STATE = {
    response: null
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case GET_PASSPORT_NUMBER:
            return { ...state, response: action.payload };
        default:
            return state;
    }
};
  