import { ALL_BANNERS } from './../actions/types';

export default (state = [], action) => {
  switch (action.type) {
    case ALL_BANNERS:
      return {
        ...state,
        allBanners: action.payload, 
        showBanners: true 
      };
    default:
      return state;
  }
};
