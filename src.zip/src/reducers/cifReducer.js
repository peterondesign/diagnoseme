import { CIF1, CIF2, CIF3, CIF4, CIF5 } from '../actions/types';
  
export default (state=[], action) => {
    switch(action.type) {
        case CIF1:  
            // console.log('CIF1: ', action.payload);
            return  { 
                ...state, 
                cif_1: action.payload,
            } 
        case CIF2:  
            // console.log('CIF2: ', action.payload);
            return  { 
                ...state, 
                cif_2: action.payload,
            } 
        case CIF3:  
            // console.log('CIF3: ', action.payload);
            return  { 
                ...state, 
                cif_3: action.payload,
            }  
        case CIF4:  
            // console.log('CIF4: ', action.payload);
            return  { 
                ...state, 
                cif_4: action.payload,
            }  
        case CIF5:  
            // console.log('CIF5: ', action.payload);
            return  { 
                ...state, 
                cif_5: action.payload,
            }  
        default:
            return state;
    }
  }
  
  