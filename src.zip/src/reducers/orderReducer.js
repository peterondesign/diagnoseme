import {
    UPDATE_ORDER_PAYLOAD,
    GET_AIRPORT,
    GET_DEPENDENTS,
    GET_COLLECTION_CENTERS,
    ADD_DEPENDENT,
    CREATE_ORDER,
    GET_ORDER_USER_DETAILS,
    GET_PENDING_BOOKINGS,
    GET_ALL_PENDING_BOOKINGS,
    BOOK_APPOINTMENT,
    VALIDATE_COUPON
  } from "../actions/types";
  
  const INITIAL_STATE = {
    loading: false,
    response: null
  };
  
  export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
      case UPDATE_ORDER_PAYLOAD:
        return { ...state, response: action.payload };
      case GET_AIRPORT:
        return { ...state, airport: action.payload };
      case GET_DEPENDENTS:
        return { ...state, dependents: action.payload };
      case GET_COLLECTION_CENTERS:
        return { ...state, centers: action.payload };
      case ADD_DEPENDENT:
        return { ...state, dependent: action.payload };
      case CREATE_ORDER:
          return { ...state, covid_order: action.payload };
      case GET_ORDER_USER_DETAILS:
        return { ...state, order_user: action.payload };
      case GET_PENDING_BOOKINGS:
        return { ...state, pending_bookings: action.payload };
      case GET_ALL_PENDING_BOOKINGS:
        return { ...state, all_pending_bookings: action.payload };
      case BOOK_APPOINTMENT:
        return { ...state, appointment: action.payload };
      case VALIDATE_COUPON:
        return { ...state, coupon: action.payload };
      default:
        return state;
    }
  };
  