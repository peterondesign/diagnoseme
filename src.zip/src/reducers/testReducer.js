import { ALL_TESTS, FEATURED_TESTS } from './../actions/types';

export default (state = [], action) => {
  switch (action.type) {
    case ALL_TESTS:
      return {
        ...state,
        allTests: action.payload, 
        showTests: true 
      };
      case FEATURED_TESTS:
        return {
          ...state,
          allTests: action.payload, 
          showTests: true 
        };
    default:
      return state;
  }
};
