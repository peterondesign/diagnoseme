import { MAKE_PAYMENT } from '../actions/types';
  
export default (state=[], action) => {
    switch(action.type) {
        case MAKE_PAYMENT:      
        return  { 
            ...state, 
            response: action.payload,
        }    
        default:
            return state;
    }
  }
  
  