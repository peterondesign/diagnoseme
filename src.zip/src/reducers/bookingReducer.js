import { COLLECTION_CENTER_TIME_SLOTS } from '../actions/types';

const INITIAL_STATE = {
    response: null
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case COLLECTION_CENTER_TIME_SLOTS:
            return { ...state, response: action.payload };
        default:
            return state;
    }
};
  