import { ADD_TO_CART, DELETE_FROM_CART, EMPTY_CART } from '../actions/types';
import { toast } from "react-toastify";

const initialState = {
    cart: [],
}

export default (state=initialState, action) => {
    switch(action.type) {
        case ADD_TO_CART:
            let cart = Object.values(state.cart);
            let existed_test = cart.find(test => test.testId === action.payload.testId);
            
            if(existed_test) {
                toast.error(action.payload.test+' already exists in cart');
                return {
                    ...state,
                    cart: [...state.cart],
                }
            } else {
                toast.success(action.payload.test+' successfully addded to cart');
                return  { 
                    ...state, 
                    isCart: true,
                    cart: [action.payload, ...state.cart],
                }    
            }
        case EMPTY_CART:
            // toast.success('All items deleted from cart.');
            return {
                ...state,
                cart: []
            }
        case DELETE_FROM_CART:
            return Object.assign({}, state, {
                cart: [...state.cart.filter(item=> item.testId !== action.payload.id) ],
                isCart: true,
            });
        default:
            return state;
    }
}
