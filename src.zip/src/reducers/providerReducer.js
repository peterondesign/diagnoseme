export default (state = [], action) => {
    switch (action.type) {
      case "PROVIDER_REQUEST":
        return action.payload;
      default:
        return state;
    }
  };
  