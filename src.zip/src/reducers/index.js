import { combineReducers } from 'redux';

import consumerUser from './consumerReducer';
import allTests from './testReducer';
import allBanners from './bannerReducer';
import cart from './cartReducer';
import providerReducer from './providerReducer';
import addressReducer from './addressReducer';
import paymentReducer from './paymentReducer'
import collectionCenterReducer from './collectionCenterReducer'
import bookingReducer from './bookingReducer'
import orderReducer from './orderReducer'
import cifReducer from './cifReducer';


export default combineReducers({
    user : consumerUser,
    tests : allTests,
    banners : allBanners,
    cart: cart,
    provider: providerReducer,
    address: addressReducer,
    payment: paymentReducer,
    booking: bookingReducer,
    center: collectionCenterReducer,
    order: orderReducer,
    cif: cifReducer,
});

