import React from "react";
import { Row, Container, Button, Card, Col } from "react-bootstrap";
import Accordion from "react-bootstrap/Accordion";
import Form from "react-bootstrap/Form";
import { Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import "../css/HomeCovid.css";
import whatisdiagnoseme from "../assets/images/whatisdiagnoseme.png";
import whatisdiagnosememobile from "../assets/images/whatisdiagnosememobile.png";
import qualitystatement from "../assets/images/qualitystatement.png";
import qualitystatementmobile from "../assets/images/qualitystatementmobile.png";
import ourlab_molecular from "../assets/images/ourlab_molecular.svg";
import ourlab_molecular2 from "../assets/images/ourlab_molecular2.svg";
import ourlab_histo from "../assets/images/ourlab_histo.svg";
import histo2 from "../assets/images/histo2.svg";
import clinical_chem from "../assets/images/clinical_chem.svg";

import MediaQuery from "react-responsive";

const Home = () => {
  return (
    <div>
      <div className="pb-0">
        <div className="section-white-home">
          <Container>
            <Row>
              <Col md={7}>
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={whatisdiagnoseme}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={whatisdiagnosememobile}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

              <Col md={5} className="my-auto">
                <p className="title-header">DiagnoseMe - providing a solution</p>
                <p className="body-text text-justify">
                  We are bringing accurate testing to Africans by providing
                  previously inaccessible advanced molecular diagnostics across
                  multiple disease areas: cardiology, pathology, gynaecology,
                  oncology and gastroenterology.
                  <br></br> <br></br>
                  Our goal is to make precision medicine a reality for Africans
                </p>
                <p className="body-text text-justify">
                  DiagnoseMe brings accurate, advanced molecular and in-vitro
                  diagnostics testing closer to Africans. DiagnoseMe leverages
                  best-in-class equipment and technology to provide precise,
                  reliable and prompt laboratory testing services to lead the
                  charge in the delivery of precision diagnostics.
                </p>
                <br></br> <br></br>
                <p className="body-header"><b>Serving unmet needs</b></p>
                <p className="body-text text-justify">
                  While developed countries have begun to implement advanced
                  precision diagnostics to make therapeutic decisions; access to
                  molecular diagnostics remains an unsolved challenge in Africa
                  and Nigeria. As a result, health care providers in Nigeria are
                  left with the only option of sending pathological samples
                  overseas for testing. This inevitably leads to delays in life
                  saving clinical decision making that could improve the
                  patients’ health outcome.
                  <br></br> <br></br>
                  This is where we come in.
                </p>
              </Col>

            </Row>
          </Container>
        </div>

        <div className="section-blue-home mb-0">
          <Container>
            <Row className="qualitystatement-order">
              <Col md={6} className="my-auto">
                <p className="title-header">Quality Statement</p>
                <p className="body-text text-justify">
                  At DiagnoseMe, we place a high value on the provision of
                  prompt, precise and reliable diagnostic services. Our core
                  objectives are firmly rooted in the quality of the service we
                  provide to our clients. Our qualified and experienced team
                  utilise best-in-class equipment and infrastructure to provide
                  optimum service.
                  <br></br> <br></br>
                  We are compliant with the international standard of good
                  practice ISO15189 and have automated our processes to mitigate
                  the chances of human error. We also participate in all
                  relevant technical External Quality Assurance (EQA) schemes,
                  which are used to further enhance the quality of all our
                  procedures.
                  <br></br> <br></br>
                  Our laboratory personnel are well trained across various
                  specialities and are certified in good laboratory practice and
                  the National Code of Health Research Ethics. Additionally, our
                  consultant pathologists are available to participate either
                  physically or remotely at multidisciplinary meetings in order
                  to support patient care and improve patient health outcomes.
                  <br></br> <br></br>
                  To support the smooth functioning of our processes, we have
                  deployed a highly efficient laboratory information management
                  system that facilitates timely delivery of results. Patient
                  privacy and confidentiality are paramount, as such, we make
                  use of a fully encrypted cloud system with reliable access
                  control that only allows the user to view his/her results.
                  <br></br> <br></br>
                  We are committed to you.
                </p>
              </Col>

              <Col md={6} className="my-auto">
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={qualitystatement}
                    id="qualitystatement"
                    alt="Quality Statement"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={qualitystatementmobile}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>
            </Row>
          </Container>
        </div>

        {/* <div className="section-white-home mt-2">
          <Container>
            <Row>
              <Col md={5}>
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={ourlab_molecular}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={ourlab_molecular}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

              <Col md={7} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Our Lab</p>
                <br></br>
                <p className="title-header">Molecular Diagnostics</p>
                <p className="body-text text-justify">
                  The Molecular diagnostics lab
                  is equipped with world-class
                  instruments and infrastructure of
                  international standard. The laboratory
                  boasts of fully automated instruments
                  from renowned manufacturers like
                  Thermo Fisher, Roche Diagnostics,
                  Promega, to mention a few. The
                  reputation of these instruments for
                  reliability, accuracy and effi ciency
                  ensures that data resulting from the
                  use of these instruments are of widely
                  acceptable and robust standards.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  Our molecular diagnostic scientists also
                  bring with them a cumulative of over
                  20years of skills and expertise to run the
                  laboratory seamlessly.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  Specifically, the Molecular Diagnostics
                  laboratory has the capacity to process
                  a diverse range of biological specimen
                  types for use in downstream applications
                  like next-generation sequencing and realtime PCR for detection of target genes and
                  genetic variants.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  In addition, several molecular diagnostics
                  tests are available to hospitals and
                  healthcare institutions, to aid prediction
                  and diagnosis of diseases such as cancers.
                </p>
                <br></br>
              </Col>

            </Row>
          </Container>
        </div>

        <div className="section-blue-home mb-0">
          <Container>
            <Row className="qualitystatement-order">
              <Col md={8} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Molecular Diagnostics</p>
                <p className="title-header">Flagship Tests</p>
                <table class="table diagnoseme_blue table-hover table-bordered table-striped w-100">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Mode of Detection</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>KRAS</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>EGFR</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>NRAS</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>BRAF Panel</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>BRAF V600E</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>BREAST CANCER PREDICTIVE PANEL</td>
                      <td>Whole genome genotyping</td>
                    </tr>
                    <tr>
                      <td>BREAST CANCER DETECTION PANEL</td>
                      <td>STRAT4 test</td>
                    </tr>
                    <tr>
                      <td>OVARIAN CANCER PREDICTIVE PANEL</td>
                      <td>Whole genome genotyping</td>
                    </tr>
                    <tr>
                      <td>OVARIAN CANCER DETECTION PANEL</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>LEUKEMIA DETECTION PANEL</td>
                      <td>BCR-ABL test</td>
                    </tr>
                    <tr>
                      <td>HLA TYPING</td>
                      <td>qPCR</td>
                    </tr>
                  </tbody>
                </table>
              </Col>

              <Col md={4} className="my-auto">
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={histo2}
                    id="qualitystatement"
                    alt="Quality Statement"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={histo2}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>git 
                </MediaQuery>
              </Col>
            </Row>
          </Container>
        </div> */}

        {/* <div className="section-white-home mt-2">
          <Container>
            <Row>
              <Col md={5}>
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={ourlab_histo}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={ourlab_histo}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

              <Col md={7} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Our Lab</p>
                <br></br>
                <p className="title-header">Histopathology</p>
                <p className="body-text text-justify">
                  Histopathology is the bedrock of
                  understanding the pathogenesis of
                  various neoplastic and non-neoplastic
                  diseases as well as being signifi cant in
                  cancer diagnosis and management.
                  Here at DiagnoseMe, we provide
                  comprehensive, timely and accurate
                  histology, cytology and immunohistochemistry services, at competitive
                  prices. Our service encompasses all
                  aspects of general pathology
                  particularly breast and prostate
                  pathology. We off er gynaecological
                  (liquid based and conventional) and
                  non-gynaecological cytology. We have
                  a wide range of immunohistochemistry
                  antibodies in order to aid cancer
                  diagnosis, prognosis and treatment.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  The Consultant Pathologist is available to
                  participate either remotely or physically
                  at multidisciplinary meetings in order to
                  support patient care.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  We strive to participate in all relevant
                  technical External Quality Assurance (EQA)
                  schemes, which are used to ensure the
                  quality of tissue processing and reporting.
                </p>
              </Col>
            </Row>
          </Container>
        </div> */}

        {/* <div className="section-blue-home mb-0">
          <Container>
            <Row className="qualitystatement-order">
              <Col md={8} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Histopathology</p>
                <p className="title-header">Flagship Tests</p>
                <table class="table diagnoseme_pink table-hover table-bordered table-striped w-100">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Mode of Detection</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>ER</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>HER2</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>PR</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>CA-125</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>CD3</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>CD20</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>CD45</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                    <tr>
                      <td>EGFR</td>
                      <td>Immunohistochemistry</td>
                    </tr>
                  </tbody>
                </table>
              </Col>

              <Col md={4} className="my-auto">
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={ourlab_molecular}
                    id="qualitystatement"
                    alt="Quality Statement"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={ourlab_molecular}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>
            </Row>
          </Container>
        </div> */}

        <div className="section-white-home last_section my-auto">
          <Container>
            <Row>

              <Col md={5}>
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={clinical_chem}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={clinical_chem}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

              <Col md={7} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Our Lab</p>
                <p className="title-header" style={{ paddingTop: '5px' }}>Clinical Chemistry and Immunology</p>
                <p className="body-text text-justify">
                  Clinical chemistry is a medical
                  specialty and a branch of laboratory
                  medicine that involves the use of body
                  fluids like urine, blood and CSF, for
                  biochemical investigation in order
                  to discover changes in the body’s
                  chemistry. This provides a means for
                  clinicians to determine the functionality
                  of vital organs, diagnose diseases and
                  recommend appropriate treatment.
                  </p>
                <br></br>
                <p className="body-text text-justify">
                  Our Chemistry tests are performed
                  using automated and semi automated
                  analyzers such as Cobas c311, Cobas
                  e411, and Mindray BS120 analyzers
                  which effectively reduces processing
                  time, human errors, and produces results
                  with high levels of accuracy, precision, reproducibility and reliability.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  The Haematology laboratory performs
                  routine testing to aid diagnosis, treatment
                  and prevention of diseases related to blood.
                  Using the Sysmex XN 1000, we provide
                  reliable and reproducible results with
                  approximately 28 parameters in the
                  shortest possible time.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  We participate in
                  both National and International quality
                  assurance programmes in addition to
                  using internal quality control measures
                  daily to minimize errors related to
                  reagent, instrument and operators. We
                  also have highly experienced and trained
                  Consultants in Clinical Chemistry as well as
                  Medical laboratory professionals.
                </p>
              </Col>

            </Row>
          </Container>
        </div>

        {/* <div className="section-blue-home mb-0">
          <Container>
            <Row className="qualitystatement-order">
              <Col md={12} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Clinical Chemistry and Immunology</p>
                <p className="title-header">Flagship Tests</p>
                <table class="table diagnoseme_pink table-hover table-bordered table-striped w-100">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Mode of Detection</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Vitamin Deficiency
</td>
                      <td>Immunoassay</td>
                    </tr>
                    <tr>
                      <td>Lipid Panel (HDL, LDL,
Cholesterol, TG..)</td>
                      <td>Immunoassay</td>
                    </tr>
                    <tr>
                      <td>Tumor Markers</td>
                      <td>Immunoassay</td>
                    </tr>
                    <tr>
                      <td>Fertility/Hormones</td>
                      <td>Immunoassay</td>
                    </tr>
                    <tr>
                      <td>Thyroid Function</td>
                      <td>Immunoassay</td>
                    </tr>
                    <tr>
                      <td>General Chemistry</td>
                      <td>Clinical Chemistry</td>
                    </tr>
                    <tr>
                      <td>Therapeutic drug monitoring</td>
                      <td>Clinical Chemistry</td>
                    </tr>
                    <tr>
                      <td>Diabetes (Glucose, HbA1C, Microalbumin…)</td>
                      <td>Clinical Chemistry</td>
                    </tr>
                    <tr>
                      <td>Food Intolerance and Allergy tests</td>
                      <td>RDT</td>
                    </tr>
                    <tr>
                      <td>Food Intolerence (40 food parameters)</td>
                      <td>RDT</td>
                    </tr>
                    <tr>
                      <td>Specific Allergy tests (Nut Mix, Cereal, Wheat, Seafood)</td>
                      <td>RDT</td>
                    </tr>
                    <tr>
                      <td>Comprehensive Allergy Panel (25 common ragweed)</td>
                      <td>RDT</td>
                    </tr>
                  </tbody>
                </table>
              </Col>

              <Col md={4} className="my-auto">
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={qualitystatement}
                    id="qualitystatement"
                    alt="Quality Statement"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={qualitystatementmobile}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

            </Row>
          </Container>
        </div> */}


        {/* <div className="section-white-home mt-2">
          <Container>
            <Row>
              <Col md={5}>
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={whatisdiagnoseme}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={whatisdiagnosememobile}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>

              <Col md={7} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Our Lab</p>
                <br></br>
                <p className="title-header">Microbiology</p>
                <p className="body-text text-justify">
                  The Microbiology Laboratory off ers
                  a wide range of diagnostic tests
                  in bacteriology, parasitology and
                  virology.The bacteriology section of
                  the laboratory isolates and identifi es
                  clinically signifi cant microorganisms
                  from clinical specimens and performs
                  antimicrobial susceptibility testing on
                  the bacterial pathogens. For these
                  purposes, the laboratory is equipped
                  with automated BD Phoenix M50 and
                  Bactec FX40 system to provide accurate
                  identifi cation of the microbes. The
                  parasitology section provides services
                  for the diagnosis of parasitic infections.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  For malaria parasites, blood specimens
                  are analyzed using WHO recommended
                  staining method and the parasites
                  identifi ed to specie level using the parasight
                  platform.
                </p>
                <br></br>
                <p className="body-text text-justify">
                  GeneXpert system, antibody enzyme
                  immunoassays and serology platforms are
                  provided to aid in the diagnosis of viral
                  infections.
                <br></br>
                </p>
                <p className="body-text text-justify">
                  The Laboratory unit has fully
                  trained and certifi ed personnel to perform
                  all services provided.
                  An in-house Consultant Clinical Microbiologist is also available to advise
                  Physicians on patient antibiotic choice and
                  other treatment support strategies.
                </p>
              </Col>
            </Row>
          </Container>
        </div>

        <div className="section-blue-home mb-0">
          <Container>
            <Row className="qualitystatement-order">
              <Col md={8} className="my-auto">
                <p className="body-text text-justify" style={{ color: '#F05F87' }}>Histopathology</p>
                <p className="title-header">Flagship Tests</p>
                <table class="table diagnoseme_pink table-hover table-bordered table-striped w-100">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Mode of Detection</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>SAR-COV-2
</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HIV Resistant Testing & Genotyping</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HIV Resistant</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HIV 1 Viral Load</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HBV, HCV, HDV Viral Load</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HERPES</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>CHLAMYDIA AND GONORRHEA</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HIGH RISK HPV</td>
                      <td>qPCR</td>
                    </tr>
                    <tr>
                      <td>HIGH RISK HPV+PAP SMEAR</td>
                      <td>qPCR</td>
                    </tr>
                  </tbody>
                </table>
              </Col>

              <Col md={4} className="my-auto">
                <MediaQuery minDeviceWidth={990}>
                  <img
                    src={qualitystatement}
                    id="qualitystatement"
                    alt="Quality Statement"
                  ></img>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={990}>
                  <img
                    src={qualitystatementmobile}
                    id="whatisdiagnoseme"
                    alt="What is DiagnoseMe"
                  ></img>
                </MediaQuery>
              </Col>
            </Row>
          </Container>
        </div> */}





        <div className="bg-darkblue last_section mb-0">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={6}>
                  <p className="newsletter-text">Let’s keep you up to date</p>
                </Col>
                <Col md={6} className="my-auto">
                  <Form action="https://diagnosemeafrica.us4.list-manage.com/subscribe/post?u=d9204974d7ff947e60919326d&amp;id=a3894e63d2" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                    <div className="newsletter-box">
                      <Form.Control
                        type="email"
                        name="EMAIL"
                        id="mce-EMAIL"
                        placeholder="Enter email address"
                        className="height-input-auto"
                      />
                      <Button
                        variant="primary"
                        className="btn-custom"
                        type="submit"
                        value="Submit"
                      >
                        <a name="subscribe" id="mc-embedded-subscribe" className="newsletter-button">
                          Subscribe
                        </a>
                      </Button>
                    </div>
                  </Form>
                </Col>
              </Row>
            </div>
          </Container>
        </div>
      </div>

      {/* //Newsletter CTA Section */}
    </div>
  );
};

export default Home;
