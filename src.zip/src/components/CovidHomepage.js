import React from "react";
import { Row, Container, Button, Card, Col } from "react-bootstrap";
import Accordion from "react-bootstrap/Accordion";
import Form from "react-bootstrap/Form";
import { Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import "../css/Home.css";
import LandingImage from "../assets/images/covid_landing.png";
import LandingImage2 from "../assets/images/landing_img.jpg";
import bgelementsHomepage from "../assets/images/background_element.svg";
import ProviderImage from "../assets/images/provider_img.png";
import Test from "./Test";

const CovidHomepage = () => {
  return (
    <div>
      <Col className="banner-info">
        <a href="tel:+2347003424667363" className="my-auto banner-text">
          Call us 0700DIAGNOSEME (+234 700 342 466 7363) for support or
          enquiries
        </a>
      </Col>
      <div className="homepage_section section-padding">
        <Container>
          <Row className="reverse_on_mobile">
            <Col md={8} className="landing-col-2">
              <Col className="landing-content">
                <h1 className="landing-header">
                  COVID-19 Tests now available!
                </h1>
                <p className="landing-text">
                  DiagnoseMe is the diagnostics platform of 54gene. We are an
                  NCDC accredited COVID-19 testing centre providing precise,
                  efficient and real-time detection results.
                  <span className="landing-span">
                    Get your results within 48 hours!
                  </span>
                </p>

                <div className="homepage-text-buttons">
                  <Link
                    to="/order/purpose"
                    className="homepage-text-primary-button"
                  >
                    {" "}
                    <b>
                      Order Test <span style={{ marginLeft: "10px" }}>></span>
                    </b>
                  </Link>

                  {/* <div className="homepage-text-secondary-button">
                    <Link
                      to="/auth/purpose"
                      className="homepage-text-secondary-button"
                    >
                      <svg
                        className="my-auto ml-2 mr-2"
                        xmlns="http://www.w3.org/2000/svg"
                        width="18.233"
                        height="2"
                        viewBox="0 0 18.233 2"
                      >
                        <path
                          id="StraightLine"
                          d="M47.233,0H29"
                          transform="translate(-29 1)"
                          fill="none"
                          stroke="#6473a8"
                          strokeWidth="2"
                        />
                      </svg>
                      Create Account
                    </Link>
                  </div> */}
                </div>
              </Col>
            </Col>

            <Col md={4} className="how_it_works_col">
              <div className="how_it_works_step">
                <div>1</div>
                <div>
                  <p>Order a test</p>
                  <p>You will need to specify details if for travel purposes</p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>2</div>
                <div>
                  <p>Book an Appointment</p>
                  <p>Select your preferred sample collection centre</p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>3</div>
                <div>
                  <p>Complete Customer Identification Form</p>
                  <p>
                    You are required to fill a Case Form (as mandated by the
                    NCDC).
                  </p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>4</div>
                <div>
                  <p>Present your Appointment Slip</p>
                  <p>
                    You will be sent an appointment barcode. Kindly present this
                    to be admitted entry at the center
                  </p>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>

      <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
      <Col className="banner-info">
        <a href="tel:+2347003424667363" className="my-auto banner-text">
          Call us 0700DIAGNOSEME (+234 700 342 466 7363) for support or
          enquiries
        </a>
      </Col>
      <div className="section-padding">
        <Container>
          <Row>
            <Col md={3}>
              <img src={LandingImage} className="landing-image" alt=""></img>
            </Col>
            <Col md={4} className="how_it_works_col">
              <div className="how_it_works_step">
                <div>1</div>
                <div>
                  <p>Order a test</p>
                  <p>You will need to specify details if for travel purposes</p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>2</div>
                <div>
                  <p>Complete Customer Identification Form</p>
                  <p>
                    You are required to fill a Case Form (as mandated by the
                    NCDC).
                  </p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>3</div>
                <div>
                  <p>Book an Appointment</p>
                  <p>Select your preferred sample collection centre</p>
                </div>
              </div>
              <div className="how_it_works_step">
                <div>4</div>
                <div>
                  <p>Present your Appointment Slip</p>
                  <p>
                    You will be sent an appointment barcode. Kindly present this
                    to be admitted entry at the center
                  </p>
                </div>
              </div>
            </Col>
            <Col md={5} className="landing-col-2">
              <Col className="landing-content">
                <h1 className="landing-header">
                  COVID-19 Tests now available!
                </h1>
                <p className="landing-text">
                  We are an NCDC accredited COVID-19 testing centre providing
                  precise, efficient and real-time detection results.
                  <span className="landing-span">
                    Get your results within 48 hours!
                  </span>
                </p>

                <div className="homepage-text-buttons">
                  <Link
                    to="/order/purpose"
                    className="homepage-text-primary-button"
                  >
                    {" "}
                    <b>
                      Order Test <span style={{ marginLeft: "10px" }}>></span>
                    </b>
                  </Link>

                  {/* <div className="homepage-text-secondary-button">
                    <Link
                      to="/auth/purpose"
                      className="homepage-text-secondary-button"
                    >
                      <svg
                        className="my-auto ml-2 mr-2"
                        xmlns="http://www.w3.org/2000/svg"
                        width="18.233"
                        height="2"
                        viewBox="0 0 18.233 2"
                      >
                        <path
                          id="StraightLine"
                          d="M47.233,0H29"
                          transform="translate(-29 1)"
                          fill="none"
                          stroke="#6473a8"
                          strokeWidth="2"
                        />
                      </svg>
                      Create Account
                    </Link>
                  </div> */}
                </div>
              </Col>
            </Col>
          </Row>
        </Container>
      </div>

      {/* //Homepage Section */}

      {/* About DiagnoseMe Section */}
      <div className="bg-white section-padding">
        <Container>
          <Row>
            <Col md={7} className="homepage-text-group">
              <div className="about-diagnoseme-text-group">
                <h3 className="provider-title-header">
                  Are you a healthcare provider looking to order COVID-19 tests
                  ?
                </h3>
                <p className="provider-title-sub">
                  We are extending flexible options your way. Please select your
                  preferred option below:
                </p>
                <div className="text-center-mobile">
                  <Link
                    to="/providers"
                    className="homepage-text-secondary-button provider-home-btn"
                  >
                    <svg
                      className="mr-3"
                      xmlns="http://www.w3.org/2000/svg"
                      width="18.233"
                      height="2"
                      viewBox="0 0 18.233 2"
                    >
                      <path
                        id="StraightLine"
                        d="M47.233,0H29"
                        transform="translate(-29 1)"
                        fill="none"
                        stroke="#6473a8"
                        strokeWidth="2"
                      />
                    </svg>
                    Book an appointment directly for your patient
                  </Link>
                </div>
                <div className="text-center-mobile">
                  <a
                    href="tel:+2347003424667363"
                    className="homepage-text-secondary-button provider-home-btn"
                  >
                    <svg
                      className="mr-3"
                      xmlns="http://www.w3.org/2000/svg"
                      width="18.233"
                      height="2"
                      viewBox="0 0 18.233 2"
                    >
                      <path
                        id="StraightLine"
                        d="M47.233,0H29"
                        transform="translate(-29 1)"
                        fill="none"
                        stroke="#6473a8"
                        strokeWidth="2"
                      />
                    </svg>
                    Call for sample pick up - 0700DIAGNOSEME
                  </a>
                </div>
              </div>
            </Col>
            <Col md={5}>
              <Row>
                <img src={ProviderImage} id="provider-image" alt=""></img>
              </Row>
            </Col>
          </Row>
        </Container>
      </div>

      {/* //About DiagnoseMe Section */}

      {/* FAQ on Homepage Section */}

      <div className="bg-light-greypearl">
        <Container>
          <div className="section-padding">
            <Row>
              <Col md={12}>
                <p className="mt-3 mb-1 pt-3 pb-1 title-header text-center-desktop">
                  Frequently Asked Questions
                </p>
              </Col>
              <div className="faq-on-homepage">
                <Accordion defaultActiveKey="0">
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="0">
                      <p className="body-text">What is DiagnoseMe?</p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="0">
                      <Card.Body>
                        <p className="body-text">
                          DiagnoseMe is an in-vitro diagnostics product designed
                          to bring accurate testing closer to Africans.<br></br>
                          It leverages best-in-class equipment and technology to
                          provide precise, reliable and prompt laboratory
                          testing services. DiagnoseMe leads the charge in
                          ensuring timely testing that provides for a better
                          quality of healthcare within the African ecosystem.
                        </p>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="1">
                      <p className="body-text">
                        How do I create a DiagnoseMe Account?
                      </p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="1">
                      <Card.Body>
                        <p className="body-text">
                          Sign up <Link to="/auth/signup">here</Link>
                        </p>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="2">
                      <p className="body-text">
                        How do I order a test on the DiagnoseMe website?
                      </p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="2">
                      <Card.Body>
                        <div className="body-text">
                          <ul>
                            {/* <li>
                              Shop tests <Link to="/buytests">here</Link>
                            </li> */}
                            <li>Order your test</li>
                            <li>Fill in all necessary details</li>
                            <li>Make your payment</li>
                            <li>
                              Book an appointment for your sample collection
                            </li>
                          </ul>
                        </div>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="3">
                      <p className="body-text">How can I pay for a test?</p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="3">
                      <Card.Body>
                        <p className="body-text">
                          Once you have ordered your test on our portal, you can
                          make payment either via card payment or bank transfer.
                          For card payments, we accept both local and
                          international payments via Visa or Mastercard using a
                          secure payment gateway.
                          <br></br>
                          If you would like to do a bank transfer instead, you
                          may use your USSD, mobile banking or internet banking
                          platforms.
                        </p>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="4">
                      <p className="body-text">Where is my result?</p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="4">
                      <Card.Body>
                        <p className="body-text">
                          You may view the status of your result on your{" "}
                          <Link to="/auth/login">dashboard.</Link>
                        </p>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                  <Card>
                    <Accordion.Toggle as={Card.Header} eventKey="5">
                      <p className="body-text">How secure is my data?</p>
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey="5">
                      <Card.Body>
                        <p className="body-text">
                          We use a heavily secure, state of the art cloud
                          architecture system. Our data is fully encrypted, and
                          is rendered useless outside of our system. Reliable
                          access control ensures that only authorized personnel
                          have access to the information they require and we
                          also keep a log of IP addresses that access our
                          information. Multiple brute force access attempts will
                          be flagged from external IPs which are then blocked.
                        </p>
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                </Accordion>
              </div>
            </Row>

            <Col md={12} className="mt-4 mb-3 pt-4 pb-3">
              <div className="mx-auto text-center">
                <Link to="/help" className="homepage-text-outline-button">
                  View All FAQs
                </Link>
              </div>
            </Col>
          </div>
        </Container>
      </div>

      {/* //FAQ Section */}

      {/* Newsletter CTA Section */}

      <div className="bg-darkblue">
        <Container>
          <div className="section-padding last_section">
            <Row>
              <Col md={6}>
                <p className="newsletter-text">
                  {" "}
                  Stay up to date with discounts, new tests and company news
                </p>
              </Col>
              <Col md={6} className="my-auto">
                <Form>
                  <div className="newsletter-box">
                    <Form.Control
                      type="email"
                      placeholder="Enter email address"
                      className="height-input-auto"
                    />
                    <Button
                      variant="primary"
                      className="btn-custom"
                      type="submit"
                      value="Submit"
                    >
                      <Link to="/" className="newsletter-button">
                        Subscribe
                      </Link>
                    </Button>
                  </div>
                </Form>
              </Col>
            </Row>
          </div>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>

      {/* //Newsletter CTA Section */}
    </div>
  );
};

export default CovidHomepage;
