import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

import "react-phone-input-2/lib/style.css";
import "../css/Home.css";


const Covid19Privacy = () => {
    return (
        <div>
            <div className="section-padding">
                <Container>

                    <Row>
                        <Col md={12} id="terms">

                            <div className="title-header">COVID 19 PRIVACY TERMS</div>
                            <br></br>
                                <br></br>
                                <ol>
                                    <li>
                                        These terms refer to data that we collect for COVID-19 related testing operations.
                                        For information on any other rights for any other data collected please see our
                                        Privacy Notice at <Link to="/privacy">https://diagnosemeafrica.com/privacy</Link>
                                    </li>
                                    <br></br>
                                    <li>
                                        We have been accredited and appointed by the Nigeria government to carry out
                                        molecular based COVID-19 tests otherwise known as Real-time Polymerase Chain
                                        Reaction tests (rPCR) and only act as data processors for COVID-19 testing
                                        operations.
                                    </li><br></br>
                                    <li>
                                        We carry out testing operations across different States in Nigeria and the State
                                        Governments act as Data Controller for all COVID-19 tests.
                                    </li><br></br>
                                    <li>
                                        The collection of data for testing operations is limited to the purpose of processing
                                        samples collected to provide test results.
                                    </li><br></br>
                                    <li>
                                        We do not collect any information that is not required for processing samples.
                                    </li>
                                    <br></br>
                                    <li>
                                        In line with the Nigerian Data Protection Regulations, the purpose of carrying out
                                        tests is in the vital interests of the citizens of Nigeria including the vital interest of
                                        the persons to be tested.
                                    </li><br></br>
                                    <li>
                                        We do not carry out any processing activity that has not been authorized by the
                                        State or Federal Government.
                                    </li><br></br>
                                    <li>
                                        Our Privacy Notice applies to the extent that we collect your samples for any other
                                        diagnostic tests.
                                    </li><br></br>
                                    <li>
                                        The right to your data may be overridden by the vital interest rights of other citizens
                                        as may be determined by the Nigerian Government.
                                    </li>
                                    <br></br>
                                    <li>
                                        We may share your personal data and test results with regulatory agencies including
                                        the National Center for Disease Control, the applicable State Government as well as
                                        any regulatory body designated by the Federal Government.
                                    </li><br></br>
                                    <li>
                                        In some cases, we are required to return samples collected as well as any personal
                                        data and health information to the relevant State or government authority.
                                    </li><br></br>
                                    <li>
                                        We do not retain any part of your data related to COVID-19 tests and follow
                                        approved regulations for discarding bio-samples collected that is not returned to the
                                        Government.
                                    </li><br></br>
                                </ol>

                        </Col>

                    </Row>
                </Container>
            </div>
        </div>
    );
}

export default Covid19Privacy;
