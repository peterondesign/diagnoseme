import React from 'react';
import Logo from '../assets/images/diagnoseme_logo.svg'
import '../css/Footer.css';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col } from 'react-bootstrap';

const Footer = () => {

  return (
    <div className="footer-box">
      <Container>
        <div className="footer-top-section">
          <Row>
            <Col md={6} className="text-center-mobile">
              <a href="mailto:hello@diagnosemeafrica.com" style={{ color: "#CED6EC" }}>hello@diagnosemeafrica.com</a>
            </Col>
            <Col md={6} className="text-center-mobile">
              <a href="tel:+234 7000544363" className="footer-top-section-right" style={{ color: "#CED6EC" }}>Phone:  (NG) +234 7000544363</a>
            </Col>
          </Row>
        </div>
      </Container>
    </div>



  );

}

export default Footer



