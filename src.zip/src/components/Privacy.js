import React, { Component } from "react";
import { Container, Row, Col, NavLink } from "react-bootstrap";
import "react-phone-input-2/lib/style.css";
import "../css/Home.css";
import { Link } from "react-router-dom";


import { connect } from "react-redux";
import { registerProvider } from "./../actions/provider";

class Terms extends Component {

    render() {

        return (
            <div>
                <div className="section-padding">
                    <Container>
                        {/* Terms Section */}

                        <Row>
                            <Col md={12} id="terms">

                                <div className="title-header">DiagnoseMe Privacy Notice</div>
                                <br></br>
                                <ol><li><b>Introduction</b></li>
                                <br></br>
                                    <ol>
                                        <li>
                                            We are committed to safeguarding the privacy of DiagnoseMe website visitors and service users.
                                        </li>
                                        <br></br>
                                        <li>
                                            This notice applies where we are acting as a data controller with respect to the
                                            personal data of our website visitors and service users; in other words, where we
                                            determine the purposes and means of the processing of that personal data.
                                        </li><br></br>
                                        <li>
                                            We use cookies on our website. Insofar as those cookies are not strictly necessary
                                            for the provision of our website and services, we will ask you to consent to our use
                                            of cookies when you first visit our website.
                                        </li><br></br>
                                        <li>
                                        In this notice, &quot;we&quot;, &quot;us&quot; and &quot;our&quot; refer to DiagnoseMe which is a registered
                                        trademark of Stack Diagnostics Nigeria Ltd carrying out business under the trade
                                        name 54Gene. [ For more information about us, see Section 12.1]
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>How we use your personal data</b></li>
                                    <ol>
                                        <li>
                                            We collect and process genetic data and biological samples as well as information
                                            relating to your health (all together referred to as “special category data”)
                                            provided by you for the purpose of carrying out diagnostic tests to provide you
                                            with a result. The legal basis for this processing is your explicit consent by signing
                                            up to the DiagnoseMe platform.
                                        </li><br></br>
                                        <li>
                                            We may collect your information and data from corporate clients to whom we
                                            provide Diagnostic services. Where a corporate client provides personal
                                            information of their employees, they act as Data Controllers and are responsible to
                                            their employees; and we act as Data Processors. Our legal basis for carrying out
                                            processing activity in this instance shall be in the performance of the contract with
                                            the corporate client.
                                        </li><br></br>
                                        <li>
                                            We may process data about your use of our website and services (&quot;usage data&quot;).
                                            The usage data may include your IP address, geographical location, browser type
                                            and version, operating system, referral source, length of visit, page views and
                                            website navigation paths, as well as information about the timing, frequency and
                                            pattern of your service use. The source of the usage data is our analytics tracking
                                            system. This usage data may be processed for the purposes of analyzing the use
                                            of the website and services. The legal basis for this processing is our legitimate
                                            interest of monitoring and improving our website and services.
                                        </li><br></br>
                                        <li>
                                            We may process your DiagnoseMe account data (&quot;account data&quot;) as provided by
                                            you which includes your name and email address. We may process account data for the purposes of operating our website, providing our services, ensuring thesecurity of our website and services, maintaining back-ups of our databases and
                                            communicating with you. The legal basis for this processing is our legitimate
                                            interests for the proper administration of our website and business.
                                        </li><br></br>
                                        <li>
                                            We may process your information included in your personal profile on our website
                                            (&quot;profile data&quot;). The profile data may include your name, address, telephone
                                            number, email address, profile pictures, gender, date of birth, location of
                                            residence, relationship status, interests and hobbies, educational details and
                                            employment details. The profile data may be processed for the purposes of
                                            enabling and monitoring your use of our website and services. The legal basis for
                                            this processing is in the performance of the contract to provide you this service.
                                        </li><br></br>
                                        <li>
                                            We may process information that you provide to us for the purpose of subscribing
                                            to our email notifications and/or newsletters (&quot;notification data&quot;) for the
                                            purposes of sending you the relevant notifications and/or newsletters. The legal
                                            basis for this processing is your consent.
                                        </li><br></br>
                                        <li>
                                            We may process any of your personal data identified in this notice where
                                            necessary for the purposes of obtaining or maintaining insurance coverage,
                                            managing risks, or obtaining professional advice. The legal basis for this
                                            processing is our legitimate interests, namely the proper protection of our business
                                            against risks.
                                        </li><br></br>
                                        <li>
                                            In addition to the specific purposes for which we may process your personal data
                                            set out above, we may also process any of your personal data where such
                                            processing is necessary for compliance with a legal obligation to which we are
                                            subject, or in order to protect your vital interests or the vital interests of other
                                            natural persons.
                                        </li><br></br>
                                        <li>
                                            Please do not supply any other person&#39;s personal data to us, unless we prompt you
                                            to do so. You may choose to supply personal data of others for which you confirm
                                            that you have their explicit consent to so do and our terms of use and privacy
                                            notice shall apply to how we use that data. You shall be responsible for any liability
                                            arising from the status of such person’s consent to have their data processed.
                                        </li><br></br>
                                        

                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Providing your personal data to others</b></li>
                                    <ol>
                                        <li>
                                            We may disclose your personal data to any member of our group of companies this
                                            means our subsidiaries, our ultimate holding company and all its subsidiaries
                                            insofar as reasonably necessary for the purposes, and on the legal bases, set out
                                            in this notice. [ Information about our group of companies can be found at
                                            <a href="https://54gene.com" target="_blank" rel="noopener noreferrer">54gene.com</a>.]
                                        </li><br></br>
                                        <li>
                                            We may disclose your personal data to our insurers and/or professional advisers
                                            insofar as reasonably necessary for the purposes of obtaining or maintaining
                                            insurance coverage, managing risks, obtaining professional advice, or the
                                            establishment, exercise or defense of legal claims, whether in court proceedings or
                                            in an administrative or out-of-court procedure.
                                        </li><br></br>
                                        <li>
                                            We may disclose your personal information and special category of information to
                                            our suppliers or subcontractors insofar as reasonably necessary for providing any
                                            of our services as stated in our terms.
                                        </li><br></br>
                                        <li>
                                            Financial transactions relating to our website and services are handled by our
                                            payment services providers. We will share transaction data with
                                            our payment services providers only to the extent necessary for the purposes of
                                            processing your payments, refunding such payments and dealing with complaints
                                            and queries relating to such payments and refunds. 
                                            {/* You can find information about
                                            the payment services providers&#39; privacy policies and practices at [URLs]. */}
                                             
                                        </li><br></br>
                                        <li>
                                            In addition to the specific disclosures of personal data set out above, we may
                                            disclose your personal data where such disclosure is necessary for compliance with
                                            a legal obligation to which we are subject, or in order to protect your vital interests
                                            or the vital interests of another natural person. We may also disclose your
                                            personal data where such disclosure is necessary for the establishment, exercise
                                            or defense of legal claims, whether in court proceedings or in an administrative or
                                            out-of-court procedure.
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>International transfers of your personal data</b></li>
                                    <ol>
                                        <li>
                                            We and our other group companies have offices and facilities in Nigeria, the
                                            United States and the United Kingdom. The National Information Technology
                                            Development Agency and the Attorney General of Nigeria have recognized these
                                            countries as adequate with respect to the data protection laws of each of these
                                            countries. Transfers to each of these countries will be protected by appropriate
                                            safeguards.
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Retaining and deleting personal data</b></li>
                                    <ol>
                                        <li>Personal data that we process for any purpose or purposes shall not be kept for longer than is necessary for that purpose or those purposes.
                                         </li><br></br>
                                        <li>We will retain your personal data as follows:
                                             <ul>
                                                <li>
                                                    personally identifiable information relating to your DiagnoseMe account
                                                    information will be retained for a minimum period of one year following your
                                                    sign up, and for a maximum period of 2 years following sign up to have it
                                                    retained by us.
                                                 </li><br></br>
                                                <li>
                                                    genetic data and biological samples provided by you for diagnostic tests will
                                                    be retained by our labs for a minimum period of one year and a maximum
                                                    period of 3 years.
                                                </li><br></br>
                                            </ul>
                                        </li><br></br>
                                        <li>
                                            In some cases it is not possible for us to specify in advance the periods for which
                                            your personal data will be retained. In such cases, we will determine the period of
                                            retention based on the research purposes and activities of the Company.
                                         </li><br></br>
                                        <li>
                                            Notwithstanding the other provisions of this Section 6, we may retain your
                                            personal data where such retention is necessary for compliance with a legal
                                            obligation to which we are subject, or in order to protect your vital interests or the
                                            vital interests of another natural person.
                                         </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Amendments</b></li>
                                    <ol>
                                        <li>
                                            We may update this notice from time to time by publishing a new version on our website.
                                         </li><br></br>
                                        <li>
                                            You should check this page occasionally to ensure you are happy with any changes to this notice.
                                        </li><br></br>
                                        <li>
                                            We will notify you of changes to this notice by email or through the private messaging system on our website.
                                         </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Your rights</b></li>
                                    <ol>
                                        <li>
                                            Some of the rights you have for providing us your information are complex, and
                                            not all of the details have been included in our summaries. Accordingly, you should
                                            read the relevant laws and guidance from the regulatory authorities for a full
                                            explanation of these rights.
                                         </li><br></br>
                                        <li>Your principal rights under data protection laws for providing your data to 54Gene are:
                                            <ul>

                                                <li>the right to access;</li>
                                                <li>the right to rectification;</li>
                                                <li>the right to erasure;</li>
                                                <li>the right to restrict processing;</li>
                                                <li>the right to object to processing;</li>
                                                <li>the right to data portability;</li>
                                                <li>the right to complain to a supervisory authority; and</li>
                                                <li>the right to withdraw consent.</li>
                                            </ul>
                                        </li><br></br>
                                        <li>
                                            You have the right to confirmation as to whether or not we process your personal
                                            data and, where we do, access to the personal data, together with certain
                                            additional information. That additional information includes details of the purposes
                                            of the processing, the categories of personal data concerned and the recipients of
                                            the personal data. Providing the rights and freedoms of others are not affected, we
                                            will supply to you a copy of your personal data. The first copy will be provided free
                                            of charge, but additional copies may be subject to a reasonable fee. You can
                                            access your personal data when logged into our website by opening the settings on
                                            your account information.
                                         </li><br></br>
                                        <li>
                                            You have the right to have any inaccurate personal data about you rectified and,
                                            taking into account the purposes of the processing, to have any incomplete
                                            personal data about you completed.
                                         </li><br></br>
                                        <li>
                                            In some circumstances you have the right to the erasure of your personal data
                                            without undue delay. Those circumstances include where: the personal data is no
                                            longer necessary in relation to the purposes for which they were collected or otherwise processed; you withdraw consent to consent-based processing; you
                                            object to the processing under certain rules of applicable data protection law; the
                                            processing is for direct marketing purposes; and the personal data have been
                                            unlawfully processed. However, there are exclusions of this right to erasure where
                                            processing is necessary: for exercising the right of freedom of expression and
                                            information; for compliance with a legal obligation; or for the establishment,
                                            exercise or defense of legal claims.
                                         </li><br></br>
                                        <li>
                                            In some circumstances you have the right to restrict the processing of your
                                            personal data. Those circumstances are: you contest the accuracy of the personal
                                            data; processing is unlawful but you oppose erasure; we no longer need the
                                            personal data for the purposes of our processing, but you require personal data for
                                            the establishment, exercise or defense of legal claims; and you have objected to
                                            processing, pending the verification of that objection. Where processing has been
                                            restricted on this basis, we may continue to store your personal data. However, we
                                            will only otherwise process it: with your consent; for the establishment, exercise or
                                            defense of legal claims; for the protection of the rights of another natural or legal
                                            person; or for reasons of important public interest.
                                         </li><br></br>
                                         <li>
                                            You have the right to object to our processing of your personal data on grounds
                                            relating to your particular situation, but only to the extent that the legal basis for
                                            the processing is that the processing is necessary for: the performance of a task
                                            carried out in the public interest or in the exercise of any official authority vested
                                            in us; or the purposes of the legitimate interests pursued by us or by a third party.
                                            If you make such an objection, we will cease to process the personal information
                                            unless we can demonstrate compelling legitimate grounds for the processing which
                                            override your interests, rights and freedoms, or the processing is for the
                                            establishment, exercise or defense of legal claims.
                                         </li><br></br>
                                        <li>
                                            You have the right to object to our processing of your personal data for direct
                                            marketing purposes (including profiling for direct marketing purposes). If you
                                            make such an objection, we will cease to process your personal data for this
                                            purpose.
                                         </li><br></br>
                                        <li>To the extent that the legal basis for our processing of your personal data is:
                                             <ul>
                                                <li>
                                                    consent; or
                                                 </li>
                                                <li>
                                                    that the processing is necessary for the performance of a contract to which
                                                    you are party or in order to take steps at your request prior to entering into
                                                    a contract,
                                                 </li>
                                            </ul>

                                                and such processing is carried out by automated means, you have the right to
                                                receive your personal data from us in a structured, commonly used and machine-
                                                readable format. However, this right does not apply where it would adversely
                                                affect the rights and freedoms of others.

                                         </li><br></br>
                                        <li>
                                            If you consider that our processing of your personal information infringes data
                                            protection laws, you have a legal right to lodge a complaint with a supervisory
                                            authority responsible for data protection. You may do so in the EU member state
                                            of your habitual residence, your place of work or the place of the alleged infringement. 
                                            In Nigeria, you may do so to do the National Information Technology
                                            Development Agency.
                                        </li><br></br>
                                        <li>
                                            To the extent that the legal basis for our processing of your personal information is
                                            consent, you have the right to withdraw that consent at any time. Withdrawal will
                                            not affect the lawfulness of processing before the withdrawal.
                                        </li><br></br>
                                        <li>
                                            You may exercise any of your rights in relation to your personal data by written
                                            notice to us in addition to the other methods specified in this Section.
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>About cookies</b></li>
                                    <ol>
                                        <li>
                                            A cookie is a file containing an identifier (a string of letters and numbers) that is
                                            sent by a web server to a web browser and is stored by the browser. The identifier
                                            is then sent back to the server each time the browser requests a page from the
                                            server.
                                        </li><br></br>
                                        <li>
                                            Cookies may be either &quot;persistent&quot; cookies or &quot;session&quot; cookies: a persistent
                                            cookie will be stored by a web browser and will remain valid until its set expiry
                                            date, unless deleted by the user before the expiry date; a session cookie, on the
                                            other hand, will expire at the end of the user session, when the web browser is
                                            closed.
                                        </li><br></br>
                                        <li>
                                            Cookies do not typically contain any information that personally identifies a user,
                                            but personal information that we store about you may be linked to the information
                                            stored in and obtained from cookies.
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Cookies that we use</b></li>
                                    <ol>
                                        <li>We use cookies for the following purposes:
                                            <ul>
                                                <li>
                                                    authentication - we use cookies to identify you when you visit our website
                                                    and as you navigate our website;
                                                </li>
                                                <li>
                                                status - to help us determine if you are logged into our website;
                                                </li>
                                                <li>
                                                personalisation - we use cookies to store information about your preferences and to personalise the website for you;
                                                </li>
                                                <li>
                                                security - we use cookies as an element of the security measures used to protect user accounts, including preventing fraudulent use of login credentials, and to protect our website and services generally;
                                                </li>
                                                <li>
                                                advertising - we use cookies to help us to display advertisements that will be relevant to you;
                                                </li>
                                                <li>
                                                personalisation - we use cookies to store information about your preferences and to personalise the website for you;
                                                </li>
                                                <li>
                                                analysis - we use cookies to help us to analyse the use and performance of our website and services; and
                                                </li>
                                                <li>
                                                cookie consent - we use cookies to store your preferences in relation to the use of cookies more generally.
                                                </li>
                                            </ul>
                                        </li><br></br>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Cookies used by our service providers</b></li>
                                    <ol>
                                        <li>We use Google Analytics to analyse the use of our website. Google Analytics gathers information about website use by means of cookies. The information gathered relating to our website is used to create reports about the use of our website. Google's privacy policy is available at: https://policies.google.com/privacy
                                        </li><br></br>
                                    </ol>

                                    
                                    <br></br><br></br>


                                    <li><b>Managing cookies</b></li>
                                    <ol>
                                        <li>
                                            Most browsers allow you to refuse to accept cookies and to delete cookies. The
                                            methods for doing so vary from browser to browser, and from version to version.
                                            You can however obtain up-to-date information about blocking and deleting
                                            cookies via these links:
                                            <br></br>
                                            <ul>
                                                <li>
                                                <a href="https://support.google.com/chrome/answer/95647">https://support.google.com/chrome/answer/95647 (Chrome);</a></li>
                                                <li><a href="https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences">https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences</a>  (Firefox);</li>
                                                <li><a href="https://www.opera.com/help/tuhrefrials/security/cookies/">https://www.opera.com/help/tutorials/security/cookies/</a>  (Opera);</li>
                                                <li><a href="https://support.microsoft.com/en-gb/help/17442/windows-internet-explorer-delete-manage-cookies">https://support.microsoft.com/en-gb/help/17442/windows-internet-explorer-delete-manage-cookies</a> (Internet Explorer);</li>
                                                <li><a href="https://support.apple.com/kb/PH21411">https://support.microsoft.com/en-gb/help/17442/windows-internet-explorer-delete-manage-cookies </a>(Safari);</li>
                                                <li><a href="https://privacy.microsoft.com/en-us/windows-10-microsoft-edge-and-privacy">https://support.microsoft.com/en-gb/help/17442/windows-internet-explorer-delete-manage-cookies </a>(Edge);
                                                </li>
                                            </ul>
                                            <br></br>
                                            <li>Blocking all cookies will have a negative impact upon the usability of many websites.
                                            </li><br></br>
                                            <li>If you block cookies, you will not be able to use all the features on our website.
                                            </li><br></br>
                                        </li>
                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Our Details</b></li>
                                    <ol>
                                        <li>This website is owned and operated by 54gene Inc registered in Nigeria as Stack Diagnostics Nigeria Limited carrying on business under the trade name 54Gene.
                                        </li><br></br>
                                        {/* <li>Our principal place of business is at 17b Sybil Iroche Street, Lekki Penninsula Scheme One, Lagos, Nigeria.
                                        </li><br></br> */}
                                        <li>You can contact us:
                                            <ul>
                                                <li>
                                                    by using our website contact form;
                                                </li>
                                                <li>
                                                    by telephone, on [the contact number published on our website from time to time; or
                                                </li>
                                                <li>
                                                    by email, using [the email address published on our website from time to time.
                                                </li>
                                            </ul>
                                        </li>

                                    </ol>

                                    <br></br><br></br>


                                    <li><b>Data protection officer</b></li>
                                    <ol>
                                        <li>Our data protection officer's contact details are:
                                            
                                            <ul>
                                                <li>
                                                Email Address – <a href="mailto:dataprotection@54gene.com">dataprotection@54gene.com</a>
                                                </li>
                                                <li>
                                                Phone Number – <a href="tel:+2347034294430">+234 703 429 4430</a>
                                                </li>
                                            </ul>
                                        
                                        </li><br></br>

                                    </ol>




                                </ol>


                            </Col>

                        </Row>
                    </Container>
                </div>
            </div>
        );
    }
}

const mapPropsToState = state => {
    return { provider: state.provider };
};

export default connect(mapPropsToState, { registerProvider })(Terms);
