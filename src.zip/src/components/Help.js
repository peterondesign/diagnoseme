import React, { Component } from "react";
import { Tabs, Tab, Container, Row, Col } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import Accordion from "react-bootstrap/Accordion";
import { Link } from "react-router-dom";
import "react-phone-input-2/lib/style.css";
import "../css/Home.css";
import "../css/Help.css";
import bgelementsHomepage from "../assets/images/bgelementsHomepage.svg";
import DebugSentry from '../apis/DebugSentry';


class Help extends Component {

    constructor(props) {
        super(props);
    
        DebugSentry.instantiate();
      }
    
      componentDidCatch(error, errorInfo) {
        DebugSentry.catchException(error, errorInfo);
      }

    render() {

        return (
            <div>
                {/* Contact Section */}
                <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
                <div className="section-padding body_half_full">
                    <Container>
                        <Row className="blue-help-bg help-items-padding">
                            <Col md={12} className="mb-5">
                                <div className="title-header" style={{ color: 'white' }}>
                                    Need help? Send us an email or give us a phone call
                                </div>
                            </Col>
              
                            <Col md={6}>
                                <div className="body-text">
                                    <a href="mailto:hello@diagnosemafrica.com" style={{ color: 'white' }}>hello@diagnosemeafrica.com</a>
                                </div>
                            </Col>
                            <Col md={6}>
                                <div className="body-text float-right-none-on-mobile">
                                    <a href="tel:+2347000544363" style={{ color: 'white' }}>Phone: 0700DIAGNOSEME (+234 700 342 466 7363)</a>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </div>
                {/* //Contact Section */}

                {/* FAQ Section */}
                {/* <div className="section-padding">
                    <Container>
                        <Row className="white-help-bg help-items-padding">
                            <Col md={6} className="my-auto">
                                <div className="my-auto title-header">
                                    Frequently Asked Questions
                                </div>
                            </Col>
                            <Col
                                md={6}
                            >
                            </Col>

                            <Col md={12}>
                                <Tabs defaultActiveKey="Payment" className="faq-categories">
                                    <Tab eventKey="About-us" className="faq-category" title="About us">
                                        <Accordion defaultActiveKey="0" className="fixed-height-accordion">
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="0">
                                                    <p className="body-text-blue">What is DiagnoseMe?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="0">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            DiagnoseMe is an in-vitro diagnostics product designed to bring accurate testing closer to Africans.<br></br>
                                                            It leverages best-in-class equipment and technology to provide precise, reliable and prompt laboratory testing services. DiagnoseMe leads the charge in ensuring timely testing that provides for a better quality of healthcare within the African ecosystem.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="1">
                                                    <p className="body-text-blue">Is DiagnoseMe a hospital?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="1">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            DiagnoseMe is not a hospital
                                                             It is a diagnostics brand that is designed to provide precise, reliable and prompt laboratory testing services to consumers and health care providers.

                                                        </p>
                                                    </Card.Body>

                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="2">
                                                    <p className="body-text-blue">Is DiagnoseMe a lab?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="2">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            DiagonoseMe offers laboratory testing services in various specialty areas in a bid to provide a better quality of healthcare within continental Africa.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="3">
                                                    <p className="body-text-blue">Where is the DiagnoseMe office?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="3">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            At present, the DiagnoseMe office is located on 17 Sybil Iroche street, Lekki Phase 1.
                                            </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="4">
                                                    <p className="body-text-blue">I need help from DiagnoseMe

                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="4">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Please contact us on: <a href="tel:07005444363">07005444363</a> or email <a href="mailto:hello@diagnomeafrica.com">hello@diagnomeafrica.com</a>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                    <Tab eventKey="My-account" data-title="Managing my account" className="faq-category" title="My account">
                                        <Accordion defaultActiveKey="5" className="fixed-height-accordion">
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="5">
                                                    <p className="body-text-blue">How do I create a DiagnoseMe Account?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="5">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Sign up <Link to="/auth/signup">here</Link>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="6">
                                                    <p className="body-text-blue">Do I need to create an account to order a test?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="6">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Yes you have to create an account. This is in line with a privacy policy to share your result with you in the most protected way
                                                        </p>
                                                    </Card.Body>

                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="7">
                                                    <p className="body-text-blue">Can I share my account with another person?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="7">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            This is not advisable. Your information and results are private to you and if you decide to share this with anybody, DiagnoseMe will not be liable for any consequences.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="8">
                                                    <p className="body-text-blue">How do I reset my password?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="8">
                                                    <Card.Body>
                                                        <div className="body-text">
                                                            <ul><li>Enter your email  <Link to="/auth/forgot_password">here</Link>
                                                            </li>
                                                                <li>An email will be sent to you.  If you don’t get an email:
                                                                    Check your Spam or Bulk Mail folders
                                                            </li>
                                                            <li>Click the button to reset your passport
                                                            </li>
                                                            <li> Choose a password that you haven't already used with this account.
                                                            </li>
                                                            </ul>
                                                        </div>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="9">
                                                    <p className="body-text-blue">How do I edit/change the information on my account?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="9">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                           You can edit your phone number, name, and date of birth on your profile page
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                    <Tab eventKey="Order-Fulfillment" className="faq-category" title="Order Fulfillment/Tracking">
                                        <Accordion defaultActiveKey="10" className="fixed-height-accordion" >
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="10">
                                                    <p className="body-text-blue">Where can I buy a kit?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="10">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Sign up <Link to="/auth/signup">here</Link>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="11">
                                                    <p className="body-text-blue">How do I order a test on the DiagnoseMe website?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="11">
                                                    <Card.Body>
                                                        <div className="body-text">
                                                            <ul>
                                                                <li>Shop tests <Link to="/buytests">here</Link></li>
                                                                <li>Pick a test you want</li>
                                                                <li>Fill in all necessary details</li>
                                                                <li>Make your payments</li>
                                                                <li>We call you to confirm your order</li>
                                                            </ul>
                                                        </div>
                                                    </Card.Body>

                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="12">
                                                    <p className="body-text-blue">What tests do you offer?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="12">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            View available tests <Link to="/buytests">here</Link>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="13">
                                                    <p className="body-text-blue">How can I return my samples?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="13">
                                                    <Card.Body>
                                                        <div className="body-text">
                                                            <ul>
                                                                <li>You can drop off at an approved collection center</li>
                                                                <li>Or we can pick up from you from your preferred location. (available to customers in Lagos only)</li>
                                                            </ul>
                                                        </div>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="14">
                                                    <p className="body-text-blue">How long does the testing process take?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="14">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        The testing process varies for different tests. You can view the turnaround time (time from when your sample is received in the lab until your report is ready)
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="15">
                                                    <p className="body-text-blue">How much is shipping?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="15">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        Shipping depends on your location. You can view the shipping costs during checkout
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="16">
                                                    <p className="body-text-blue">Can I change my delivery date to suit my availability?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="16">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Yes you can. Please contact us at least 24hours before your preferred deliverable time/date
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="17">
                                                    <p className="body-text-blue">Where is my sample?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="17">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You can track your order status by viewing the test details on your <Link to="/">dashboard</Link>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="18">
                                                    <p className="body-text-blue">Where is my result?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="18">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You can track your order status by viewing the test details on your <Link to="/">dashboard</Link>
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="19">
                                                    <p className="body-text-blue">Can my result be emailed to me?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="19">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Your results are only made available to you through your personal DiagnoseMe account. Log in to your  DiagnoseMe account to view your results or track your order
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                    <Tab eventKey="Payment" className="faq-category" title="Payment">
                                        <Accordion defaultActiveKey="0" className="fixed-height-accordion">
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="20">
                                                    <p className="body-text-blue">How do I order a test?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="20">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        View our <Link to="/buytests">tests</Link> and select “Buy Test”. Follow the steps involved and select your preferred delivery method.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="21">
                                                    <p className="body-text-blue">Can I access your services using my HMO?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="21">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        You cannot currently access your services using my HMO
                                                        </p>
                                                    </Card.Body>

                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="22">
                                                    <p className="body-text-blue">Can I gift a DiagnoseMe Kit/Test?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="22">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        You cannot currently gift a DiagnoseMe Kit/Test.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="23">
                                                    <p className="body-text-blue">How can I pay for a test?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="23">
                                                    <Card.Body>
                                                        <div className="body-text">
                                                            <ul>
                                                                <li>You can drop off at an approved collection center</li>
                                                                <li>Or we can pick up from you from your preferred location. (available to customers in Lagos only)</li>
                                                            </ul>
                                                        </div>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="24">
                                                    <p className="body-text-blue">What are the next steps after payment?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="24">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You will be contacted by our customer support representative to confirm that payment was received on your order and also confirm your availability on the scheduled date and time.

                                                        <br></br>

                                                            On the date of your sample collection, please await the phlebotomist assigned to your preferred location or visit the nearest blood collection centre to you.

                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="25">
                                                    <p className="body-text-blue">Refund/cancellation policy
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="25">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You may request a refund 7 days after your order has been placed if you have not been contacted to schedule your sample collection and informed of the next steps after payment.
                                                        <br></br>
                                                            If you would like to request a refund on this basis, kindly contact hello@diagnosemeafrica.com or call 07000544363 to make your refund request. In certain cases, you may be asked to send proof of payment in order to claim your refund.
                                                        <br></br>
                                                            Once confirmed, you should receive a full refund within 72 hours after your request has been received.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                    <Tab eventKey="Privacy" data-title="Privacy/Credibility/Security" title="Privacy" className="faq-category">
                                        <Accordion defaultActiveKey="26" className="fixed-height-accordion">
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="26">
                                                    <p className="body-text-blue">How secure is my data?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="26">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            We use a heavily secure, state of the art cloud architecture system. Our data is fully encrypted, and is rendered useless outside of our system. Reliable access control ensures that only authorized personnel have access to the information they require and we also keep a log of IP addresses that access our information. Multiple brute force access attempts will be flagged from external IPs which are then blocked.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="27">
                                                    <p className="body-text-blue">Is my data used for research?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="27">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            We have identified the importance of implementing clear work processes that alienates and guards against inappropriate use of samples in either case.
                                                            <br></br>
                                                            For diagnostics and research, we have designed separate portals. For DiagnoseMe, the portal allows for diagnostic requests, feedback and results retrieval.
                                                            <br></br>
                                                            In the case of research, the portal allows for collection of research participant information with unique participant identification code that ensures privacy and confidentiality.
                                                            <br></br>
                                                            We have deployed a state-of-the-art laboratory logistics management information system that specifically tracks the samples for the purposes for which it was collected.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="28">
                                                    <p className="body-text-blue">Do I need a doctor’s prescription to order a test?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="28">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            The tests that are marked ‘Doctor Ordered’ may only be ordered following prescription from a doctor. However, for tests without this marking, you may place an order for the test without the doctor’s prescription.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="29">
                                                    <p className="body-text-blue">Will you send my results to my doctor?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="29">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Your results are only made available to you through your personal DiagnoseMe account. Log in to your  DiagnoseMe account to view your results or track your order
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                    <Tab eventKey="Reports" className="faq-category" title="Reports">
                                        <Accordion defaultActiveKey="30" className="fixed-height-accordion">
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="30">
                                                    <p className="body-text-blue">How soon can I get my results?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="30">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            Each test type has its own peculiar turn around time indicated on the portal.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="31">
                                                    <p className="body-text-blue">How do I receive my results?
                                                    </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="31">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        When your report(s) is/are ready, you will receive an email to view your report details on your dashboard
                                                        </p>
                                                    </Card.Body>

                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="32">
                                                    <p className="body-text-blue">Can I download my results from the DiagnoseMe platform?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="32">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                        Yes, you can download your results from the DiagnoseMe platform. Note that: to access this report you will need to enter your Patient Identification Number
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="33">
                                                    <p className="body-text-blue">How accurate are my results?
                                            </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="33">
                                                    <Card.Body>
                                                        <div className="body-text">
                                                            <ul>
                                                                <li>You can drop off at an approved collection center</li>
                                                                <li>Or we can pick up from you from your preferred location. (available to customers in Lagos only)</li>
                                                            </ul>
                                                        </div>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="34">
                                                    <p className="body-text-blue">Can DiagnoseMe results be used for clinical purposes?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="34">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You will be contacted by our customer support representative to confirm that payment was received on your order and also confirm your availability on the scheduled date and time.

                                                        <br></br>

                                                            On the date of your sample collection, please await the phlebotomist assigned to your preferred location or visit the nearest blood collection centre to you.

                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                            <Card>
                                                <Accordion.Toggle as={Card.Header} eventKey="35">
                                                    <p className="body-text-blue">Where is my result?
                                                </p>
                                                </Accordion.Toggle>
                                                <Accordion.Collapse eventKey="35">
                                                    <Card.Body>
                                                        <p className="body-text">
                                                            You may request a refund 7 days after your order has been placed if you have not been contacted to schedule your sample collection and informed of the next steps after payment.
                                                        <br></br>
                                                            If you would like to request a refund on this basis, kindly contact hello@diagnosemeafrica.com or call 07000544363 to make your refund request. In certain cases, you may be asked to send proof of payment in order to claim your refund.
                                                        <br></br>
                                                            Once confirmed, you should receive a full refund within 72 hours after your request has been received.
                                                        </p>
                                                    </Card.Body>
                                                </Accordion.Collapse>
                                            </Card>
                                        </Accordion>
                                    </Tab>
                                </Tabs>

                            </Col>
                        </Row>
                    </Container>

                </div> */}
                {/* //FAQ Section */}
            </div>
        );
    }
}


export default Help;
