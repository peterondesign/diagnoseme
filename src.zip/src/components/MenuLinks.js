import React, { Component } from 'react';
import { NavLink, Link } from "react-router-dom";
import {Row} from "react-bootstrap";
import DebugSentry from '../apis/DebugSentry';

class MenuLinks extends React.Component {
  constructor(props) {
    super(props);
    // Any number of links can be added here
    this.state = {
      links: [
      //   {
      //   text: 'Buy Tests',
      //   link: '/buytests',
      // }, 
      {
        text: 'For Providers',
        link: '/providers',
      }, {
        text: 'Help',
        link: '/help',
      }],
      
    }
    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }


  render() {

    let links = this.state.links.map((link, i) => <div className="menu-item-desktop" ref={i + 1}><NavLink to={link.link} className="menu-item-desktop" activeClassname="header-active-mobile" >{link.text}</NavLink></div>);
    const user = localStorage.getItem('user')


    return (

      user == null ? <>
      
        <div className={`${this.props.menuStatus}`} id="menu">
          <ul>
            {links}
          </ul>
         
        </div>
      </> : <>
          <div className={this.props.menuStatus} id="menu-backdrop"></div>
          <div ref="root" className={this.props.menuStatus} id='menu'>
            <ul>
              {/* <div className="menu-item-desktop" activeClassname="header-active-mobile" ><NavLink to="/buytests" activeClassname="header-active-mobile" onClick={this._menuToggle} className="menu-item-desktop">Buy Tests</NavLink></div> */}
              <div className="menu-item-desktop" activeClassname="header-active-mobile" ><NavLink to="/order/myappointments" activeClassname="header-active-mobile" onClick={this._menuToggle} className="menu-item-desktop">My Appointments</NavLink></div>
              <div className="menu-item-desktop" activeClassname="header-active-mobile" ><NavLink to="/help" activeClassname="header-active-mobile" onClick={this._menuToggle} className="menu-item-desktop">Help</NavLink></div>
            </ul>
          </div>

        </>

    )
  }
}

export default MenuLinks;