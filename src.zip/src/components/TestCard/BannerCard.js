import React, { useState } from "react";
import { Col, Row } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import { PropTypes } from 'prop-types'
import { Link } from "react-router-dom";
import Button from "react-bootstrap/Button";
import bgelementsHomepage from '../../assets/images/bgelementsHomepage.svg';
import '../../css/BuyTests.css';
import TestDetailsModalToggle from '../Modal/TestDetailsModalToggle';


const BannerCard = ({tat,onCloseModal, testId, test_for, why, sample, id,label, price,description,test,images,is_bundle, image, banner_description }) => {
    const  [ modalShow, setModalShow ] = useState(false)
   
    onCloseModal = () => {
      alert('dddd')
    }


    return (
            <Row>
                <Col md={6}>
                    
                    <img src={image} id="HomepageImage"  alt="banner"></img>
                </Col>
                <Col md={6} className="homepage-text-group">
                    <div className="homepage-text-group-box">
                        <div className="homepage-text-main-copy">
                            {banner_description}
                        </div>
                        <div className="homepage-text-sub-copy">
                            {description}
                        </div>
                        <div className="homepage-text-buttons">
                            <Button  onClick = {() => setModalShow(true)} style={{cursor:'pointer'}} className="homepage-text-primary-button">

                                <TestDetailsModalToggle
                                    test_for={test_for}
                                    why={why}
                                    sample={sample}
                                    testId={testId}
                                    is_bundle={is_bundle}
                                    images={images}
                                    tat={tat}
                                    onCloseModal={onCloseModal}
                                    title="Buy Test" test={test} price={price} />

                            </Button>

                            <div className="homepage-text-secondary-button">
                                <Link to="/buytests" className="homepage-text-secondary-button">
                                    <svg className="ml-2 mr-2" xmlns="http://www.w3.org/2000/svg" width="18.233" height="2" viewBox="0 0 18.233 2">
                                        <path id="StraightLine" d="M47.233,0H29" transform="translate(-29 1)" fill="none" stroke="#6473a8" strokeWidth="2" />
                                    </svg>View All Tests
                                        </Link>

                            </div>
                        </div>
                    </div>
                </Col>
            </Row>

    );
};

Card.propTypes = {
    price: PropTypes.string,
    images: PropTypes.string,
    description: PropTypes.string,
    test: PropTypes.string
}

export default BannerCard;


