import React, { useState } from "react";
import { Col } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import { PropTypes } from 'prop-types'
import { Link } from "react-router-dom";
import '../../css/BuyTests.css';
import TestDetailsModalToggle from '../Modal/TestDetailsModalToggle';
import TestDetailsModal from '../Modal/TestDetailsModal';
import Button from "react-bootstrap/Button";


const TestCard = ({ tat, onCloseModal, onHide, show, testId, test_for, why, sample, id, label, price, description, testName, images, is_bundle, delivery_methods }) => {
  const [modalShow, setModalShow] = useState(false)
  onCloseModal = () => {
    alert('dddd')
  }
  const handleShow = () => setModalShow(true)
  const handleClose= () => setModalShow(false)
  return (
    <div>
      <div style={{ cursor: 'pointer' }}>
        <Card className="test-card">
          <Card.Img variant="top" src={images} onClick={() => setModalShow(true)} className="card-img-top" />
          <Card.Body>
            <Link to="" onClick={() => setModalShow(true)}><p className="test-name">{testName}</p></Link>
            <p className="test-description-short">
              {description}
            </p>
            <div className="test-payment-section mt-3">
              <div className="test-price">
                <span style={{ fontFamily: "arial" }}>₦</span>{parseInt(price).toLocaleString('us', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <Button className="buy-test-button">

                <TestDetailsModalToggle
                  test_for={test_for}
                  why={why}
                  sample={sample}
                  testId={testId}
                  is_bundle={is_bundle}
                  images={images}
                  tat={tat}
                  onCloseModal={onCloseModal}
                  title="Buy Test"
                  test={testName} 
                  price={price} 
                  delivery_methods={delivery_methods}/>

              </Button>
            </div>
          </Card.Body>
        </Card>
        <TestDetailsModal
              show={modalShow}
              onHide={() => setModalShow(false)}
              testId={testId}
              test={testName}
              price={price}
              test_for={test_for}
              why={why}
              sample={sample}
              images={images}
              is_bundle={is_bundle}
              onCloseModal={() => setModalShow(false)}
              tat={tat}
            />
      </div>
    </div>
  );
};

Card.propTypes = {
  label: PropTypes.string,
  images: PropTypes.string,
  description: PropTypes.string,
  testName: PropTypes.string
}

export default TestCard;


