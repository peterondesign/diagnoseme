    import React from 'react';
    import '../css/Home.css';
    import { Row,Container,Button, Card, Col, Tabs, Tab} from 'react-bootstrap';
    import TestImage from '../assets/images/header-image.png'


    function Errorpage() {
    return (
    <div className="Errorpage">
        <Container>
        <header className="App-header">
        <Row className="intro">
        <img src=""></img>
        <Col className="text-center">
        <h3 className="text-center">No results found</h3>
        <p className=" mx-auto col-md-6">No results found for "Sexual Health Test" (there might be a spelling error) - put in your email and we would let you know when this test is available</p>
        <input placeholder="Your email address" type="email"></input><input type="submit" className="notify-btn"></input>
        </Col>

        </Row>
        </header>
       
        <header>
        <Row className="container test-menu mx-auto">
        <Card className="shadow col-md-2 col-lg-2">
            <Card.Body>
            {/* <img src={Logo} className="img-fluid"></img> */}
            </Card.Body>
            <Card.Footer className="test-footer"><p className="test-name">Cervical Screening Test</p> <span className="test-price">₦16,000</span><a className="btn-default btn" href="#" data-toggle="modal" data-target="#viewtest">Buy Test</a></Card.Footer>
        </Card>

        <Card className="shadow col-md-2 col-lg-2">
            <Card.Body>
            <Card.Text>
            </Card.Text>
            </Card.Body>
            <Card.Footer className="test-footer"><p className="test-name">Cervical Screening Test</p> <span className="test-price">₦16,000</span><a className="btn-default btn" href="#" data-toggle="modal" data-target="#viewtest">Buy Test</a></Card.Footer>
        </Card>

        <Card className="shadow col-md-2 col-lg-2">
            <Card.Body>
            <Card.Text>
            </Card.Text>
            </Card.Body>
            <Card.Footer className="test-footer"><p className="test-name">Cervical Screening Test</p> <span className="test-price">₦16,000</span><a className="btn-default btn" href="#" data-toggle="modal" data-target="#viewtest">Buy Test</a></Card.Footer>
        </Card>

        <Card className="shadow col-md-2 col-lg-2">
            <Card.Body>
            <Card.Text>
            </Card.Text>
            </Card.Body>
            <Card.Footer className="test-footer"><p className="test-name">Cervical Screening Test</p><span className="test-price">₦16,000</span> <a className="btn-default btn" href="#" data-toggle="modal" data-target="#viewtest">Buy Test</a></Card.Footer>
        </Card>
        <div className="mx-auto "><a className="btn-default btn all-test-button" href="#">View all tests</a></div>
        </Row>
        
        </header>
        </Container>
        <div class="modal fade" id="viewtest" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        
        </div>
        <div class="modal-body">
        <Row className=" mx-auto">
              <Col styles={{ backgroundImage:`url(${TestImage})` }} className="test-image"><img className="test-image" src={TestImage} width="100%"></img></Col>
              <Col>
              <h6 className="test-modal-name">Cervical Screening Test</h6>
              <i className="fa fa-clock-o"></i><span className="test-modal-name">72 - 120 hours</span><br></br>
              <span className="test-delivery-name">At-home service</span>
              <span className="test-delivery-name">Self-sampling tests</span>
              <span className="test-delivery-name">Collection center</span>
              </Col>
        </Row>
          <hr></hr>
          <Tabs defaultActiveKey="home" className="noanim-tab-example" transition={false} id="noanim-tab-example">
            <Tab eventKey="home" title="Test For">
            <div className="container test-tab">
            <h5>Test For</h5>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 

            At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Loremundefined</p>
            </div>
            </Tab>
            <Tab eventKey="profile" title="Why get tested">

            <div className="container test-tab">
            <h5>Why get tested</h5>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 

            At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Loremundefined</p>
            </div>

            </Tab>
            <Tab eventKey="contact" title="Sample required">

            <div className="container test-tab">
            <h5>Sample required</h5>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 

            At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Loremundefined</p>
            </div>
            </Tab>
            </Tabs>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    </div>
    );
    }
    export default Errorpage;
