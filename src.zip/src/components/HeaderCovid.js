import React, { Component } from 'react';
import { NavDropdown } from 'react-bootstrap';
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import MobileHeader from './MobileHeader';
import MediaQuery from 'react-responsive';
import Cart from './Cart'

import Logo from '../assets/images/diagnoseme_logo.svg'
import '../css/Header.css';
// import Cart from './Cart'
import { Container, Row, Col, Badge } from 'react-bootstrap';
import Sticky from 'react-sticky-el';
import DebugSentry from '../apis/DebugSentry';

class Header extends Component {
  state = {
    show: false
  }
  logout = () => {
    localStorage.removeItem('user')
    window.location.href = "/"
  }

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  render() {
    const user = localStorage.getItem('user')
    return (
      <div>
        <Sticky style={{zIndex: '120'}}>

          <div className="bg-dark-blue">

            {/* Mobile Header Starts */}

            <MediaQuery maxDeviceWidth={1200}>
              <MobileHeader />
            </MediaQuery>

            {/* //Mobile Header Starts */}

            <MediaQuery minDeviceWidth={1200}>
              <Container>
                <Row>
                  <Col md={3}>
                   
                  </Col>

                  <Col md={6} className="text-center">
                  <NavLink  to="/"><img src={Logo} className="header-logo text-center" style={{width: '30%', textAlign: 'center'}} alt=""></img></NavLink>
                  </Col>

                  <Col md={3}>
                  </Col>
                </Row>
              </Container>
            </MediaQuery>
          </div>
          <div style={{ position: 'absolute', zIndex: 99, opacity: 1 }}>
            {
              this.state.show ? <Cart /> : <div></div>
            }
          </div>
          </Sticky>
      </div>

    );
  }
}

const mapStateToProps = state => {
  return {
          cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(Header);



