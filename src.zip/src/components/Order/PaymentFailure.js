import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container , Row , Col, Card, Form, ProgressBar } from 'react-bootstrap';

import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import FailedImage from './../../assets/images/verification/VerificationFailed.svg';
import InfoIcon from './../../assets/images/information_icon.svg';
import DebugSentry from "../../apis/DebugSentry";

export default class PaymentFailure extends Component {
    constructor(props) {
        super(props);
    
        DebugSentry.instantiate();
      }
    
      componentDidCatch(error, errorInfo) {
        DebugSentry.catchException(error, errorInfo);
      }

    render() {
        return (

            <Container className="main-container">
                <Row>

                    <Col md={10} className="mx-auto">
                    <Card.Header className="card-header">Your COVID-19 Order</Card.Header>

                            <Card className="card-shadow" style={{ width: '100%' }}>
                                
                                <Card.Body>
                            
                                        <Col md={12} style={{ marginBottom: '40px' }}>

                                        <Card className="card-shadow-inside" style={{ width: '100%' , minHeight: '150px' }}>

                                        <p className="header-description" style={{ textAlign: 'center' }}>Payment Failed</p>

                                        <img src={FailedImage} className="img-responsive" alt="Sucess" />
                                        <br></br>

                                        <p  style={{ textAlign: 'center' }}>Something went wrong while processing your payment. if you have <br></br>
                                        not been charged for this transaction, please try again. 
                                        <br></br>
                                        <br></br>
                                        For support, <a href="" >call us 0700DIAGNOSEME(+234 700 342 466 7363)
                                        </a></p><br></br>

                                        <button type="submit" style={{ marginLeft: 'auto' }} className="btn btn-primary order-next mx-auto">
                                    Go Back
                                        </button>
                                        {/* <Card md={8} style={{ marginTop: '50px' }}>
                                            <Card.Body>
                                            <Row>
                                                <Col md={2}>
                                                <svg width="82" height="82" viewBox="0 0 82 82" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M4git0.6 4.43522e-07C32.5701 4.43522e-07 24.7205 2.38115 18.0439 6.84233C11.3672 11.3035 6.16343 17.6444 3.09051 25.0631C0.0175912 32.4817 -0.786424 40.645 0.780136 48.5207C2.3467 56.3963 6.21347 63.6305 11.8915 69.3085C17.5695 74.9865 24.8037 78.8533 32.6794 80.4199C40.555 81.9864 48.7183 81.1824 56.137 78.1095C63.5556 75.0366 69.8965 69.8328 74.3577 63.1562C78.8189 56.4795 81.2 48.6299 81.2 40.6C81.2008 35.2681 80.1512 29.9883 78.1111 25.0621C76.0711 20.1359 73.0805 15.6599 69.3103 11.8897C65.5401 8.11949 61.0641 5.12895 56.1379 3.08889C51.2117 1.04882 45.9319 -0.000787695 40.6 4.43522e-07ZM44.309 59.339H36.852V31.211H44.308L44.309 59.339ZM40.581 28.147C39.8162 28.1195 39.0764 27.8677 38.4538 27.4228C37.8311 26.9779 37.3531 26.3596 37.0792 25.645C36.8054 24.9304 36.7479 24.151 36.9138 23.4039C37.0797 22.6569 37.4618 21.9751 38.0123 21.4436C38.5629 20.9121 39.2577 20.5543 40.0102 20.4148C40.7627 20.2754 41.5395 20.3603 42.244 20.6592C42.9485 20.958 43.5496 21.4576 43.9722 22.0955C44.3949 22.7335 44.6205 23.4817 44.621 24.247C44.6197 24.7707 44.5132 25.2887 44.308 25.7705C44.1027 26.2523 43.8028 26.6879 43.426 27.0516C43.0493 27.4153 42.6033 27.6997 42.1146 27.8879C41.6259 28.076 41.1044 28.1641 40.581 28.147Z" fill="#D8D8D8"/>
                                                    </svg>

                                                </Col>

                                                <Col md={10}>
                                                <p>You are required to complete your <u>case information form</u> and <u>select your appointment date and time</u> </p>
                                                </Col>

                                            </Row>
                                            </Card.Body>
                                        </Card> */}
                                        
                                        </Card>

                                        
                                        
                                        </Col>


                                </Card.Body>
                                {/* <Col md={12} style={{ display: 'flex' }}>
                                <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                Dashboard
                            </button>
                            </Col> */}
                            </Card>

                    </Col>
                    
                </Row>
            </Container>
        )
    }
}
