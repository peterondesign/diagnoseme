import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar , Button } from 'react-bootstrap';
import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from 'react-bootstrap/Card';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import { add_cif1 } from "../../actions/cif";
import CIF2 from '../../components/Order/CIF2';
import history from './../../history';

class CIF1 extends Component
{
    constructor(props)
    {
        super(props);

        this.state = {
            isSubmitted: false,
            user: {},
            cifStep: 1
        }
        DebugSentry.instantiate();
    }


    componentDidCatch(error, errorInfo)
    {
        DebugSentry.catchException(error, errorInfo);
    }

    componentDidMount(){
        const cif_user = this.props.order.order_user;
        if(cif_user === undefined){
            history.push('/');
        }
      }

    handleChange = event => {
        const { name, value } = event.target;
        const { user } = this.state;
    
        this.setState({
          user: {
            ...user,
            [name]: value
          }
        });
    };

    handleSubmit = (event) => {
        console.log('cif1 data: ',this.state.user)
        this.props.add_cif1(this.state.user);
        event.preventDefault();

        this.setState({
            isSubmitted: true,
            cifStep: 2
        })
    }
    

    render()
    {
        const cif_user = this.props.order.order_user;
        const {
            user,
            isSubmitted,
            cifStep
        } = this.state;
        var today = new Date();
        var birthDate = new Date(cif_user.data.dob);
        var age = today.getFullYear() - birthDate.getFullYear();

        return (

            <Container className="main-container" >
                {
                    cifStep === 1 ? (
                    <Row>
                    {/* <Col md={12} className="" >
                        <Card style={{ margin: '10px' }}>
                            <Card.Body>

                                <p>Pending Case Information Forms</p>

                                <Row className="mx-auto">
                                    <Col md={4}>
                                    <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }} className="btn btn-lg btn-outline-default">John Smith</Button>
                                    </Col>

                                    <Col md={4}>
                                    <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }}  className="btn btn-lg btn-outline-default">John Smith</Button>

                                    </Col>

                                    <Col md={4}>

                                    <Button style={{ backgroundColor: '#BBBBBB' ,  border: '0px' , borderRadius: '5px'}}  className="btn btn-lg btn-outline-default">John Smith</Button>

                                    </Col>
                                </Row>

                            </Card.Body>
                        </Card>
                    </Col> */}
                    <form onSubmit={this.handleSubmit}>

                    <Col md={12} className="" >
                        <Card style={{ margin: '10px' }} className="cif-card">
                            <Card.Body>
                                <p className="header-description">Case Information Form [{cif_user && cif_user.data.name}]</p>


                                <Form.Check style={{ width: '150px' }}  inline label="1" type="radio" defaultChecked="true" />

                                <Form.Check style={{ width: '150px' }}  inline label="2" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="3" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="4" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="5" type="radio" />                                

                                <p className="section-header">Section 1/5</p>
                                <Row md={12}>
                                    
                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">First Name</Card.Title>
                                        <Form.Control type="text" placeholder="" name="firstname" onChange={this.handleChange} value={cif_user && cif_user.data.first_name} required readonly="true" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Last Name</Card.Title>
                                        <Form.Control type="text" placeholder="" name="lastname" onChange={this.handleChange} value={cif_user && cif_user.data.last_name} required readonly="true"/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Email Address<span className="red-asterisk">*</span></Card.Title>
                                        <Form.Control type="email" placeholder="" name="email" onChange={this.handleChange} value={cif_user && cif_user.data.email} required readonly="true"/>
                                        {isSubmitted && !user.email && (
                                            <div className="help-block">
                                                Email address is required
                                            </div>
                                        )}
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Date of Birth</Card.Title>
                                        <Form.Control type="date" name="dob" onChange={this.handleChange} value={cif_user && cif_user.data.dob} required readonly="true"/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Age</Card.Title>
                                        <Form.Control type="number" placeholder="" name="age" value={cif_user && age} onChange={this.handleChange} readonly="true"/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}> 
                                        <Card.Title className="input-label">Gender</Card.Title>
                                        <Form.Control as="select" name="gender" onChange={this.handleChange} required readonly="true">
                                            <option value="">Select Gender</option>
                                            <option value={cif_user && cif_user.data.gender} selected>{cif_user && cif_user.data.gender}</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </Form.Control>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Nationality</Card.Title>
                                        <Form.Control type="text" placeholder="" name="nationality" onChange={this.handleChange}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">LGA</Card.Title>
                                        <Form.Control type="text" placeholder="" name="lga" onChange={this.handleChange}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Address</Card.Title>
                                        <Form.Control type="text" placeholder="" name="address" onChange={this.handleChange}/>
                                    </Col> 
                                </Row>
                                
                            </Card.Body>
                            
                        </Card>

                        <Col md={12} style={{ display: 'flex' }}>

                            <Link to="/order/CIF">
                                <button type="button"  style={{ marginRight: 'auto' }}  className="btn btn-primary order-next">
                                    Previous
                                </button>
                            </Link>

                            <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                Next
                            </button>
                        </Col>

                    </Col>
                    </form>
                </Row>
                    ): (<CIF2/>)
                }
                
            </Container>
        )

    }

}
  
const mapDispatchToProps = (dispatch) => {
    return {
        add_cif1: (user) => { dispatch(add_cif1(user)) },
    }
}

const mapStateToProps = (state) => {
    return {
      order: state.order,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {}
)(CIF1)

