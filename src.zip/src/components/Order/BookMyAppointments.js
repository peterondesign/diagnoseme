import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  ProgressBar,
  Alert,
  Modal
} from "react-bootstrap";
import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from "react-bootstrap/Card";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import calendar_graphic from "./../../assets/images/calender_graphic.svg";

import proof_of_id from "./../../assets/images/passport_id.png";
import mask_wearer from "./../../assets/images/mask_wearer.svg";
import Button from "react-bootstrap/Button";
import Table from "react-bootstrap/Table";
import Carousel from "react-bootstrap/Carousel";

import Nav from "react-bootstrap/Nav";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { withRouter } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import { connect } from "react-redux";
import { getTimeSlots } from "./../../actions/booking";
import { getCollectionCenters, bookAppointment } from "./../../actions/order";
import diagnosemeApi from "./../../apis/diagnosemeApi";
import history from "./../../history";
import { BallPulseSync } from "react-pure-loaders";

const convertTime12to24 = (time12h) => {
  const [time, modifier] = time12h.split(" ");

  let [hours, minutes] = time.split(":");

  if (hours === "12") {
    hours = "00";
  }

  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }

  return `${hours}:${minutes}`;
};

class BookAppointment extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    selectedDate: new Date(),
    search: {},
    centers: {},
    selectedCenter: null,
    dateIsSelected: false,
    loadingTime: false,
    isSubmitted: false,
    workingHours: [],
    list: [],
    btn: false,
    showTime: false,
    forceStateUpdate: 0,
    details: "",
    loading: true,
    collection_center_id: null,
  };

  handleDateChange = (selectedDate) => {
    if (
      this.state.selectedCenter === null ||
      this.state.selectedCenter === undefined
    ) {
      toast.error("Choose a sample collection center to continue");
      this.setState({ dateIsSelected: true });
      return true;
    }

    const { search } = this.state;
    this.setState({ selectedDate, loadingTime: true });
    let date = this.toJSONLocal(selectedDate);
    let collection_center_id = this.state.selectedCenter.id;

    if (date && collection_center_id) {
      const payload = {
        collection_center_id,
        date,
      };
      this.setState({ showTime: true });

      this.promise = this.props.getTimeSlots(payload);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });

      this.showTimeSlots(collection_center_id);
    }
  };

  handleTimeSlot = (event) => {
    const { name, value } = event.target;
    const { search } = this.state;

    this.setState({
      search: {
        ...search,
        [name]: value,
      },
      btn: true,
    });
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    const { search } = this.state;

    this.handleShowCenter(value);

    this.setState({
      search: {
        ...search,
        [name]: value,
      },
    });
  };

  handleShowCenter = (center_id) => {
    const { data } = this.props.center.response;
    let selectedCenter = data.find((item) => item.id == center_id);
    this.setState({
      selectedCenter,
      showTime: false,
    });
  };

  showTimeSlots = (center_id) => {
    const { centers } = this.props.order;
    let selectedCenter = centers.data.find((center) => center.id === center_id);

    let openHour = selectedCenter.open_hour;
    let closeHour = selectedCenter.close_hour;

    let open_time = null;
    if (selectedCenter.open_hour.charAt(2) == ":") {
      open_time = "1" + selectedCenter.open_hour.charAt(1);
    }
    if (
      selectedCenter.open_hour.charAt(2) == "0" ||
      selectedCenter.open_hour.charAt(2) == "1" ||
      selectedCenter.open_hour.charAt(2) == "2"
    ) {
      open_time = selectedCenter.open_hour.charAt();
    }
    let close_time = selectedCenter.close_hour.charAt();

    let list = [];
    let workingHours = [];
    let time = 23;
    let PMConvertion = convertTime12to24(selectedCenter.close_hour + " PM");
    for (var i = open_time; i < time; i++) {
      list.push(i);
      workingHours.push(`${i}:00`);
      if (i + ":00" == PMConvertion) {
        break;
      }
    }
    this.setState({
      list,
      workingHours,
    });
  };

  handleButtonDisable = (loading) => {
    if (loading) {
      return true;
    }
    return false;
  };

  toJSONLocal(date) {
    var local = new Date(date);
    local.setMinutes(date.getMinutes() - date.getTimezoneOffset());
    return local.toJSON().slice(0, 10);
  }

  handleSubmit = (event) => {
    event.preventDefault();
    const { selectedDate } = this.state;
    let date = this.toJSONLocal(selectedDate);
    let hour = event.target.time.value;
    let orders = JSON.parse(localStorage.getItem("ordersPayload"));
    const payload = {
      date,
      hour,
      collection_center_id: orders.collection_center_id,
      orders: orders.orders,
    };
    this.setState({ loading: true });
    this.promise = this.props.bookAppointment(payload);
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    const { orders, collection_center_id } = JSON.parse(
      localStorage.getItem("ordersPayload")
    );
    let name = "";
    orders.map((data) => {
      return (name += `${data.name}, `);
    });
    this.promise = this.props.getCollectionCenters();
    this.promise
      .catch(() => {})
      .then(() => {
        let selectedCenter = null;
        const { centers } = this.props.order;
        selectedCenter = centers.data.find(
          (center) => center.id === collection_center_id
        );
        this.setState({
          details: name,
          loading: false,
          collection_center_id,
          selectedCenter,
          centers: centers.data,
        });
      });
  }

  handleShow = () => {
    this.setState({
      show: true
    });
  };

  handleClose = () => {
    this.setState({
      show: false
    });
  };

  render() {
    const { details, loading } = this.state;
    const {
      btn,
      showTime,
      loadingTime,
      search,
      workingHours,
      selectedCenter,
      selectedDate,
      dateIsSelected,
    } = this.state;
    const response = this.props.center;
    const booking = this.props.booking.response;
    let booking_count =
      (booking && booking.data !== null && booking.data[0]) || [];
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    let workingHoursArray = workingHours;
    let AvailableHours = [];
    let formattedDate = this.toJSONLocal(selectedDate);
    console.log(selectedCenter);

    if (booking) {
      if (booking.message == "No booking yet") {
        AvailableHours = workingHoursArray;
      } else {
        booking.data.map((item, i) => {
          if (item.status == 1) {
            AvailableHours = workingHoursArray.filter(
              (workingHoursArray) => workingHoursArray != item.hour
            );
            workingHoursArray = AvailableHours;
          } else {
            AvailableHours = workingHoursArray;
          }
        });
      }
    }
    return (
      <div>
        <div className="bluebackground">
          <Container>
            <Row>
              <Col md={12} className="landing_header_row">
                <div className="mt-5 landing_header_text">
                  <Link to="/order/myappointments">
                    <span style={{ color: "#DEE3F4", marginBottom: "15px" }}>
                      Back to Pending Bookings
                    </span>
                  </Link>
                  <p>Booking for {!loading && details} </p>
                </div>
                <div className="mt-1 landing_header_img">
                  <img
                    src={calendar_graphic}
                    alt="calendar_graphic"
                    id="calendar_graphic"
                  ></img>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
        <div className="appointment_section">
          <Container>
            <Row className="reverse_on_mobile landing_header_row">
              <div className="appointment_section_table">
                <div className="bg-transparent" id="booking-div">
                  <form
                    className=""
                    style={{ padding: "30px" }}
                    onSubmit={this.handleSubmit}
                  >
                    <Row>
                      <Col md={12}>
                        <div className="form-group">
                          <label>
                            Sample Collection State{" "}
                            <span className="red-asterisk">*</span>
                          </label>
                          {!loading && selectedCenter && (
                            <input
                              name="state"
                              id="state"
                              className="form-control"
                              value={selectedCenter.state}
                              readonly="true"
                            />
                          )}
                        </div>
                      </Col>

                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (dateIsSelected && !search.collection_center
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>
                            Sample collection centers
                            <span className="red-asterisk">*</span>
                          </label>
                          <select
                            name="collection_center_id"
                            id="collection_center_id"
                            className="form-control"
                            onChange={this.handleChange}
                          >
                            {!loading && selectedCenter && (
                              <option
                                key={selectedCenter.id}
                                value={selectedCenter.id}
                                selected
                              >
                                {selectedCenter.name} - {selectedCenter.address}
                              </option>
                            )}
                          </select>
                          {dateIsSelected && !search.collection_center && (
                            <div className="help-block">
                              Choose a sample collection center to continue
                            </div>
                          )}
                        </div>
                      </Col>

                      <Col md={12}>
                        <Calendar
                          onChange={this.handleDateChange}
                          value={selectedDate}
                          activeStartDate={tomorrow}
                          tileDisabled={({ activeStartDate, date, view }) =>
                            date.getDay() === 0
                          }
                          minDate={tomorrow}
                        />
                      </Col>

                      <Col md={12} className="center-display">
                        {selectedCenter && selectedCenter != null && (
                          <Alert variant="secondary" id="center-alert">
                            <h5
                              className="center-name"
                              style={{ lineHeight: "25px" }}
                            >
                              <b>{selectedCenter.name}</b>,{" "}
                              {selectedCenter.address}
                            </h5>
                            <Row>
                              <Col md={8}>
                                <p className="center-text">
                                  <b>Opening hour:</b>{" "}
                                  {selectedCenter.open_hour}
                                </p>
                              </Col>
                              <Col md={4}>
                                <p className="center-text">
                                  <b>Closing hour:</b>{" "}
                                  {selectedCenter.close_hour}
                                </p>
                              </Col>
                              {/* <Col md={4}><p className="center-text"><b>Capacity:</b> {selectedCenter.capacity} persons/hr</p></Col> */}
                            </Row>
                          </Alert>
                        )}
                      </Col>

                      {showTime && !AvailableHours && (
                        <Col md={12} className="center-display">
                          <div className="text-center">
                            <BallPulseSync color={"#F05F87"} loading="true" />
                            <p className="loading-p">
                              Fetching available time slots...
                            </p>
                          </div>
                        </Col>
                      )}

                      {showTime && AvailableHours.length == 0 && !loading && (
                        <Col md={12} className="center-display">
                          {selectedCenter && selectedCenter != null && (
                            <Alert variant="secondary" id="center-alert">
                              <h5
                                className="center-name"
                                style={{ lineHeight: "25px" }}
                              >
                                <b>{`We are sorry, ${selectedCenter.name} is fully booked for ${formattedDate}.`}</b>
                              </h5>
                            </Alert>
                          )}
                        </Col>
                      )}

                      {showTime && AvailableHours.length > 0 && !loading && (
                        <Col md={12} className="center-display">
                          {selectedCenter && selectedCenter != null && (
                            <Alert variant="secondary" id="center-alert">
                              <h5 className="center-name">
                                <b>{"Select your time slot in"}</b>,{" "}
                                {selectedCenter.name}
                              </h5>
                              <Row>
                                <select
                                  name="time"
                                  id="time"
                                  className="form-control"
                                  onChange={this.handleTimeSlot}
                                >
                                  <option value="" defaultValue="selected">
                                    - Select Your Time Slot -
                                  </option>

                                  {booking &&
                                    AvailableHours.map((time, i) => (
                                      <option key={i} value={time}>
                                        {time}
                                      </option>
                                    ))}
                                </select>
                              </Row>
                            </Alert>
                          )}
                        </Col>
                      )}

                      <Col md={12}>
                        {btn && (
                          <button
                            type="submit"
                            className="btn auth-button btn-block"
                            disabled={this.handleButtonDisable(loading)}
                          >
                            {loading && (
                              <i
                                className="fa fa-refresh fa-spin"
                                style={{ marginRight: "5px" }}
                              />
                            )}
                            {loading && <span>Processing...</span>}
                            {!loading && <span>Complete</span>}
                          </button>
                        )}
                      </Col>
                    </Row>
                  </form>
                </div>
              </div>


              <Modal
                show={this.state.show} onHide={this.handleClose}
              >
                <Modal.Header closeButton>
                  <Modal.Title>Modal heading</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  Woohoo, you're reading this text in a modal!
                </Modal.Body>
              </Modal>

              <div className="appointment_section_info">
                <p>Appointment Checklist</p>
                <Carousel className="appointment-carousel">
                  <Carousel.Item>
                    <div className="mt-5 appointment_info">
                      <div>
                        <i className="fa fa-check mr-2"></i>
                        <p style={{ width: "85%" }}>
                          Proof of identification (acceptable forms of ID
                          include: passports, National ID cards & Driver’s
                          license)
                        </p>
                      </div>
                      <div className="appointment_image">
                        <img
                          src={proof_of_id}
                          alt="proof_of_id"
                          id="mask_wearer"
                        ></img>
                      </div>
                    </div>
                  </Carousel.Item>
                  <Carousel.Item>
                    <div className="mt-5 appointment_info">
                      <div>
                        <i className="fa fa-check mr-2"></i>
                        <p style={{ width: "85%" }}>
                          A face mask worn over your nose and mouth
                        </p>
                      </div>
                      <div className="appointment_image">
                        <img
                          src={mask_wearer}
                          alt="mask_wearer"
                          id="mask_wearer"
                        ></img>
                      </div>
                    </div>
                  </Carousel.Item>
                </Carousel>
              </div>
            </Row>
          </Container>
          <ToastContainer autoClose={2000} />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    booking: state.booking,
    center: state.center,
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  getTimeSlots,
  getCollectionCenters,
  bookAppointment,
})(withRouter(BookAppointment));
