import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  Alert,
  Button,
} from "react-bootstrap";

import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { connect } from "react-redux";
import history from "./../../history";
import {
  getDependents,
  getCollectionCenters,
  addDependent,
  updatePayload,
  getAirports,
} from "./../../actions/order";

class OrderDetails extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    isSubmitted: false,
    displayDependent: false,
    dependents: {},
    submitDependent: false,
    dependentData: {},
    data: {},
    showForm: false,
    useDependentEmail: false,
    selectedDependents: [],
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    this.props.getCollectionCenters();
    this.props.getAirports();
    this.handleGetDependent();
    this.handleUpdatePayload();
    this.intitializeBenefactor();
  }

  handleUpdatePayload = () => {
    let payload = JSON.parse(localStorage.getItem("payload"));
    this.promise = this.props.updatePayload(payload);
  };

  intitializeBenefactor = () => {
    let dependents = null;
    const { selectedDependents } = this.state;
    let { response } = this.props.order;
    const user = JSON.parse(localStorage.getItem("user"));
    const benefactor = {
      dependent_id: null,
      name: user.name,
      email: user.email,
    };
    dependents = [...selectedDependents, benefactor];
    this.setState({
      selectedDependents: dependents,
    });
    response = {
      ...response,
      order: dependents,
    };
    this.promise = this.props.updatePayload(response);
  };

  handleGetDependent = () => {
    this.promise = this.props.getDependents();
    this.promise
      .catch(() => {})
      .then(() => {
        const { data } = this.props.order.dependents;
        this.setState({
          dependents: data,
        });
      });
  };

  handleAddDependent = (event) => {
    event.preventDefault();
    this.setState({ submitDependent: true });
    const { useDependentEmail } = this.state;
    const user = JSON.parse(localStorage.getItem("user"));

    let first_name = event.target.dependent_first_name.value;
    let last_name = event.target.dependent_last_name.value;
    let name = first_name + " " + last_name;
    let dob = event.target.dependent_dob.value;
    let phone = event.target.dependent_phone.value;
    let gender = event.target.dependent_gender.value;
    let email = null;

    if (useDependentEmail) {
      email = event.target.dependent_email.value;

      if (!email || email == "") {
        email = user.email;
      }
    } else {
      email = user.email;
    }

    const dependent = {
      name,
      first_name,
      last_name,
      email,
      dob,
      phone,
      gender,
    };

    if (first_name && last_name && email && gender && dob && phone) {
      this.promise = this.props.addDependent(dependent);
      this.promise
        .catch(() => {})
        .then(() => {
          this.promise = this.props.getDependents();
          this.promise
            .catch(() => {})
            .then(() => {
              const { data } = this.props.order.dependents;
              this.setState({
                dependents: data,
                showForm: false,
              });
            });
        });
    }
  };

  handleSelectDependent = (event) => {
    const { name, value, id, checked } = event.target;
    const { selectedDependents } = this.state;
    let { response } = this.props.order;
    let dependents = null;

    if (checked === false) {
      dependents = selectedDependents.filter(
        (dependent) => dependent.dependent_id != id
      );
    } else if (checked) {
      const selected = {
        dependent_id: id,
        name: name,
        email: value,
      };
      dependents = [...selectedDependents, selected];
    }

    this.setState({
      selectedDependents: dependents,
    });

    response = {
      ...response,
      order: dependents,
    };
    this.promise = this.props.updatePayload(response);
  };

  handleDependentData = (event) => {
    const { name, value } = event.target;
    const { dependentData } = this.state;
    this.setState({
      dependentData: {
        ...dependentData,
        [name]: value,
      },
    });
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    const { data } = this.state;
    const { response } = this.props.order;

    this.setState({
      data: {
        ...data,
        [name]: value,
      },
    });
    const payload = {
      ...response,
      [name]: value,
    };
    this.promise = this.props.updatePayload(payload);
  };

  handleReviewOrder = (e) => {
    e.preventDefault();
    this.setState({ isSubmitted: true });
    const { data } = this.state;

    if (data.collection_center && data.test_for) {
      let { response, centers } = this.props.order;
      localStorage.setItem("response", JSON.stringify(response));
      localStorage.setItem("collection_center", response.collection_center);
      localStorage.setItem("order", JSON.stringify(response.order));
      localStorage.setItem("centers", JSON.stringify(centers.data));

      history.push("/order/review");
    }
  };

  OnChange = (event) => {
    const { name, value } = event.target;
    let { response } = this.props.order;
    const { data } = this.state;

    this.setState({
      data: {
        ...response,
        ...data,
        [name]: value,
      },
    });

    if (value === "dependent") {
      const user = JSON.parse(localStorage.getItem("user"));
      const { selectedDependents } = this.state;
      let { response } = this.props;
      let dependents = selectedDependents.filter(
        (dependent) => dependent.name != user.name
      );
      this.setState({
        selectedDependents: dependents,
      });

      response = {
        ...response,
        order: dependents,
      };
      this.promise = this.props.updatePayload(response);
    }

    if (value === "self_dependent" || value === "dependent") {
      this.setState({
        displayDependent: true,
      });
    } else {
      this.setState({
        displayDependent: false,
      });
    }
  };

  render() {
    // const data = this.props.order.dependents;
    const {
      dependents,
      displayDependent,
      showForm,
      selectedDependents,
      dependentData,
      submitDependent,
      isSubmitted,
      useDependentEmail,
      data,
    } = this.state;
    let centersInState, selectedAiport, selectedAiportState, payload;
    const { centers, response, airport } = this.props.order;
    payload = JSON.parse(localStorage.getItem("payload"));
    if (payload && payload.purpose == "Travel") {
      if (airport && centers) {
        selectedAiport = airport.data.filter(
          (port) => port.id == payload.returnee.airport
        );
        centersInState = centers.data.filter(
          (center) => center.state == selectedAiport[0].state
        );
        selectedAiportState = selectedAiport[0].state;
        localStorage.setItem("selectedAiportState", selectedAiportState);
      }
    }

    return (
      <Container className="main-container">
        <Row>
          <Col md={10} className="mx-auto">
            <Card.Header className="card-header">
              Your COVID-19 Order
            </Card.Header>

            <Card className="card-shadow" style={{ width: "100%" }}>
              <Link to="/order/travel" className="return-anchor">
                <i
                  className="fa fa-arrow-left"
                  style={{ marginRight: "5px" }}
                />
                Back to Travel{" "}
              </Link>
              <Card.Body>
                <Card className="card-shadow-inside" style={{ width: "100%" }}>
                  <p className="header-description">Order Details </p>

                  <Row>
                    <Col md={12}>
                      <Card.Title className="input-label">
                        Who this order for?
                      </Card.Title>
                    </Col>

                    <Col md={12}>
                      <div className="col-md-12" onChange={this.OnChange}>
                        <Row>
                          <Col md={4}>
                            <input
                              type="radio"
                              value="self"
                              name="test_for"
                              className={
                                "dependent-radio form-group" +
                                (isSubmitted && !data.test_for
                                  ? " has-bug"
                                  : "")
                              }
                            />
                            <span className="dependent-span"> Myself</span>
                          </Col>

                          <Col md={4}>
                            <input
                              type="radio"
                              value="self_dependent"
                              name="test_for"
                              className={
                                "dependent-radio form-group" +
                                (isSubmitted && !data.test_for
                                  ? " has-bug"
                                  : "")
                              }
                            />
                            <span className="dependent-span">
                              {" "}
                              Myself & Others
                            </span>
                          </Col>

                          <Col md={4}>
                            <input
                              type="radio"
                              value="dependent"
                              name="test_for"
                              className={
                                "dependent-radio form-group" +
                                (isSubmitted && !data.test_for
                                  ? " has-bug"
                                  : "")
                              }
                            />
                            <span className="dependent-span"> Others</span>
                          </Col>
                        </Row>
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    {displayDependent && (
                      <Row style={{ margin: "40px 0px", width: "100%" }}>
                        <hr></hr>
                        <Col md={8}>
                          {dependents && dependents.length > 0 && (
                            <Card.Title className="input-label">
                              Select others to be added for this order
                            </Card.Title>
                          )}
                        </Col>

                        <Col md={4} style={{ display: "flex" }}>
                          <button
                            className="add-new"
                            style={{ marginLeft: "auto" }}
                            onClick={() => this.setState({ showForm: true })}
                          >
                            + Add New Dependent
                          </button>
                        </Col>
                      </Row>
                    )}

                    <Col md={12} className="float-left my-auto">
                      {displayDependent && (
                        <>
                          {dependents && dependents.length == 0 && (
                            <Alert
                              variant="info"
                              style={{
                                color: "#293144",
                                backgroundColor: "#e2e6e6",
                                borderColor: "#e8ebeb",
                                padding: "5px",
                              }}
                            >
                              <h6 className="no-dependent">
                                You currently have no dependent
                              </h6>
                            </Alert>
                          )}
                          <br></br>
                        </>
                      )}

                      {displayDependent && (
                        <Row style={{ padding: "0px 15px" }}>
                          {dependents &&
                            dependents.map((dependent) => (
                              <Col md={4} style={{ padding: "1px" }}>
                                <div
                                  key={dependent.id}
                                  className="dependent-box"
                                >
                                  <input
                                    type="checkbox"
                                    id={dependent.id}
                                    name={dependent.name}
                                    value={dependent.email}
                                    className="dependent-radio"
                                    onClick={this.handleSelectDependent}
                                  />
                                  <span className="dependent-name">
                                    {dependent.name}
                                  </span>
                                </div>
                              </Col>
                            ))}
                          <br></br>
                        </Row>
                      )}
                    </Col>
                  </Row>

                  {showForm && (
                    <form onSubmit={this.handleAddDependent}>
                      <hr></hr>
                      <Row>
                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            First Name
                          </Card.Title>
                          <Form.Control
                            type="text"
                            name="dependent_first_name"
                            placeholder=""
                            onChange={this.handleDependentData}
                            className={
                              "form-group" +
                              (submitDependent &&
                              !dependentData.dependent_first_name
                                ? " has-bug"
                                : "")
                            }
                          />
                          {submitDependent &&
                            !dependentData.dependent_first_name && (
                              <div className="help-block">
                                This field is required
                              </div>
                            )}
                        </Col>

                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            Last Name
                          </Card.Title>
                          <Form.Control
                            type="text"
                            name="dependent_last_name"
                            placeholder=""
                            onChange={this.handleDependentData}
                            className={
                              "form-group" +
                              (submitDependent &&
                              !dependentData.dependent_last_name
                                ? " has-bug"
                                : "")
                            }
                          />
                          {submitDependent &&
                            !dependentData.dependent_last_name && (
                              <div className="help-block">
                                This field is required
                              </div>
                            )}
                        </Col>

                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            Phone Number
                          </Card.Title>
                          <Form.Control
                            type="number"
                            name="dependent_phone"
                            placeholder=""
                            onChange={this.handleDependentData}
                            className={
                              "form-group" +
                              (submitDependent && !dependentData.dependent_phone
                                ? " has-bug"
                                : "")
                            }
                          />
                          {submitDependent &&
                            !dependentData.dependent_phone && (
                              <div className="help-block">
                                This field is required
                              </div>
                            )}
                        </Col>

                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            Date of Birth
                          </Card.Title>
                          <Form.Control
                            type="date"
                            name="dependent_dob"
                            placeholder=""
                            onChange={this.handleDependentData}
                            className={
                              "form-group" +
                              (submitDependent && !dependentData.dependent_dob
                                ? " has-bug"
                                : "")
                            }
                          />
                          {submitDependent && !dependentData.dependent_dob && (
                            <div className="help-block">
                              This field is required
                            </div>
                          )}
                        </Col>

                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            State of residence
                          </Card.Title>
                          <Form.Control
                            type="text"
                            name="dependent_state"
                            placeholder=""
                            onChange={this.handleDependentData}
                            className={
                              "form-group" +
                              (submitDependent && !dependentData.dependent_state
                                ? " has-bug"
                                : "")
                            }
                          />
                          {submitDependent &&
                            !dependentData.dependent_state && (
                              <div className="help-block">
                                This field is required
                              </div>
                            )}
                        </Col>

                        <Col md={6} style={{ marginBottom: "10px" }}>
                          <Card.Title className="input-label">
                            Gender
                          </Card.Title>
                          <Form.Control
                            as="select"
                            name="dependent_gender"
                            onChange={this.handleDependentData}
                            // className={
                            //   "form-group" +
                            //   (submitDependent && !dependentData.dependent_gender ? " has-bug" : "")
                            // }
                          >
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                          </Form.Control>
                          {/* {submitDependent && !dependentData.dependent_gender && (
                              <div className="help-block">This field is required</div>
                          )} */}
                        </Col>

                        {useDependentEmail && (
                          <Col md={6} style={{ marginBottom: "10px" }}>
                            <Card.Title className="input-label">
                              Email Address
                            </Card.Title>
                            <Form.Control
                              type="email"
                              name="dependent_email"
                              placeholder=""
                              onChange={this.handleDependentData}
                            />
                          </Col>
                        )}

                        <Col md={12}>
                          {!useDependentEmail && (
                            <p
                              style={{
                                margin: "15px 0px",
                                fontSize: "12px",
                                cursor: "pointer",
                                color: "#507fd4",
                              }}
                              onClick={() =>
                                this.setState({
                                  useDependentEmail: !useDependentEmail,
                                })
                              }
                            >
                              Add email for dependent to receive access to
                              result
                            </p>
                          )}

                          {useDependentEmail && (
                            <p
                              style={{
                                margin: "15px 0px",
                                fontSize: "12px",
                                cursor: "pointer",
                                color: "#507fd4",
                              }}
                              onClick={() =>
                                this.setState({
                                  useDependentEmail: !useDependentEmail,
                                })
                              }
                            >
                              Remove email for you to have access to result
                            </p>
                          )}
                        </Col>

                        <Col md={12} style={{ display: "flex" }}>
                          <button
                            type="submit"
                            style={{ marginLeft: "auto" }}
                            className="btn btn-primary order-next"
                          >
                            Add Dependent
                          </button>
                        </Col>
                      </Row>
                    </form>
                  )}

                  <Row>
                    {payload && payload.purpose == "Travel" && (
                      <>
                        <Col md={12} style={{ marginTop: "20px" }}>
                          <hr></hr>
                          <Card.Title className="input-label">
                            Sample Collection State
                          </Card.Title>
                          <Form.Control
                            type="text"
                            name="state"
                            onChange={this.handleChange}
                            value={selectedAiport && selectedAiportState}
                            placeholder=""
                          />
                        </Col>

                        <Col md={12} style={{ marginBottom: "40px" }}>
                          <Card.Title
                            style={{ marginTop: "50px" }}
                            className="input-label"
                          >
                            Sample Collection Location
                          </Card.Title>
                          <Form.Control
                            as="select"
                            name="collection_center"
                            onChange={this.handleChange}
                            className={
                              "form-group" +
                              (isSubmitted && !data.collection_center
                                ? " has-bug"
                                : "")
                            }
                          >
                            <option disabled selected>
                              Choose a collection center nearest to you
                            </option>
                            {centers &&
                              centersInState &&
                              centersInState.map((center) => {
                                return (
                                  <option key={center.id} value={center.id}>
                                    {center.name}
                                  </option>
                                );
                              })}
                          </Form.Control>
                          {isSubmitted && !data.collection_center && (
                            <div className="help-block">
                              This field is required
                            </div>
                          )}
                        </Col>
                      </>
                    )}

                    {payload && payload.purpose == "Personal" && (
                      <>
                        <Col md={12} style={{ marginTop: "20px" }}>
                          <hr></hr>
                          <Card.Title className="input-label">
                            Sample Collection State
                          </Card.Title>
                          <Form.Control
                            as="select"
                            name="state"
                            onChange={this.handleChange}
                            className={"form-group"}
                          >
                            <option disabled selected>
                              Choose the state you want your sample to be
                              collected
                            </option>
                            <option value="Lagos">Lagos</option>
                            <option value="FCT">Abuja</option>
                          </Form.Control>
                        </Col>

                        <Col md={12} style={{ marginBottom: "40px" }}>
                          <Card.Title
                            style={{ marginTop: "50px" }}
                            className="input-label"
                          >
                            Sample Collection Location
                          </Card.Title>
                          <Form.Control
                            as="select"
                            name="collection_center"
                            onChange={this.handleChange}
                            className={
                              "form-group" +
                              (isSubmitted && !data.collection_center
                                ? " has-bug"
                                : "")
                            }
                          >
                            <option disabled selected>
                              Choose a collection center nearest to you
                            </option>
                            {response && response.state === "FCT" && (
                              <>
                                <option value="f298d8bc-ae0e-4899-9e88-dd2371cdb072">
                                  M and M Event Centre - M and M event centre,11
                                  Tafawa Balawa way, besides Nicon luxury hotel,
                                  after ICC, Abuja.
                                </option>
                                <option value="e8489531-4cce-4a0e-9e6d-b55d9d811055">
                                  Maitama Gardens - 3645 Ibrahim Babangida Way,
                                  Maitama, Abuja
                                </option>
                              </>
                            )}
                            {response && response.state === "Lagos" && (
                              <>
                                <option value="ad92eb16-edd5-4291-bc84-d8488799129f">
                                  GRANDEUR EVENT CENTER - 17 BILLINGWAYS,
                                  OREGUN, IKEJA, LAGOS (BESIDE CHRIST EMBASSY
                                  HEADQUARTERS)
                                </option>
                                <option value="bb94b99c-bb3a-474a-bced-c9bfeed06424">
                                  54gene Collection Center(Oniru) - 3, SIMEON
                                  AKINOLONU CRESCENT BY TECHNO OIL, BEHIND FOUR
                                  POINTS HOTEL, ONIRU, V.I. LAGOS
                                </option>
                              </>
                            )}
                          </Form.Control>
                          {isSubmitted && !data.collection_center && (
                            <div className="help-block">
                              This field is required
                            </div>
                          )}
                        </Col>
                      </>
                    )}

                    <Col md={12} style={{ marginBottom: "40px" }}>
                      <Card.Title className="input-label">
                        Please note yourself and your dependent(s) will need to
                        go to the sample collection location together
                      </Card.Title>
                    </Col>
                  </Row>
                </Card>
              </Card.Body>
              <Col md={12} style={{ display: "flex" }}>
                <Button
                  className="btn btn-primary order-next"
                  style={{ marginLeft: "auto" }}
                  onClick={(e) => this.handleReviewOrder(e)}
                >
                  Proceed
                </Button>
              </Col>
              {/* <Col md={12} style={{ display: "flex" }}>
                
                <Link
                  to="/order/review"
                  className="landing-cta"
                  style={{ marginLeft: "auto" }}
                  onClick={this.handleReviewOrder}
                >
                  Proceed
                </Link>
              </Col> */}
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  getDependents,
  getCollectionCenters,
  addDependent,
  updatePayload,
  getAirports,
})(OrderDetails);
