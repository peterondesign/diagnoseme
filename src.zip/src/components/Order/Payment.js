import React, { Component } from "react";
import Cookies from "universal-cookie";
import { NavLink as Link } from "react-router-dom";
import axios from "axios";
import postscribe from "postscribe";
import { connect } from "react-redux";
import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";
import diagnosemeApi from "../../apis/diagnosemeApi";

import "react-toastify/dist/ReactToastify.css";
import { makePayment } from "../../actions/payment";
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Form,
  ProgressBar,
} from "react-bootstrap";
import RigthBar from "./RightBar";
import Toggle from "./../Modal/Toggle";
import { emptyCart } from "../../actions/cart";
import "./../../css/Checkout.css";
import paymentoptions from "./../../assets/images/paymentoptions.svg";
import { API_URL } from "../../apis/diagnosemeApi";
import DebugSentry from "../../apis/DebugSentry";

const MonnifySDK = window.MonnifySDK;

class Payment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isSubmitted: false,
    };
    if (localStorage.getItem("user") == null) {
      window.location.href = "/";
    }
    console.log("add", this.props);
    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  emptyCart = () => {
    this.props.emptyCart();
  };

  payWithMonnify = (props, emptyCart) => {
    const user = localStorage.getItem("user");
    const delivery_address = this.props.address.address;
    const delivery_time = this.props.address.delivery_time;
    const delivery_date = this.props.address.delivery_date;
    const delivery_method = this.props.address.delivery_method;
    const tests = this.props.cart;

    emptyCart = () => {
      this.props.emptyCart();
    };

    let total = 0;
    // this.props.emptyCart();
    this.props.cart.map((row) => {
      total += parseInt(row.price);
    });

    console.log("Carts", this.props.cart);
    MonnifySDK.initialize({
      amount: total,
      currency: "NGN",
      reference: "" + Math.floor(Math.random() * 1000000000 + 1),
      customerFullName: JSON.parse(user).name,
      customerEmail: JSON.parse(user).email,
      customerMobileNumber: JSON.parse(user).phone,
      apiKey: "MK_TEST_KC8DCS7Y94",
      contractCode: "2849546487",
      paymentDescription: "Test Payment",
      isTestMode: true,

      onComplete: function (response, props) {
        //Implement what happens when transaction is completed.
        if (response.status == "SUCCESS") {
          const cookies = new Cookies();
          const headers = {
            "Content-Type": "application/json",
            authorization: cookies.get("authorization"),
          };

          const data = {
            delivery_address: delivery_address,
            delivery_time: delivery_time,
            delivery_date: delivery_date,
            delivery_method: delivery_method,
            salesNote: "",
            payment_status: 1,
            tests: tests,
          };
          console.log("Data:", data);
          // this.emptyCart();
          axios
            .post(`${API_URL}consumer/order/test/create`, data, {
              headers: headers,
            })

            .then(
              (response) => {
                localStorage.removeItem("checkout");
                toast.success(response.data.message);
                // console.log('order',response)
                emptyCart();
                window.location.href = "/account/dashboard";
              },
              (error) => {
                toast.success(error);
              }
            );
        }

        console.log(response);
      },
      onClose: function (data) {
        //Implement what should happen when the modal is closed here
        window.location.href = "/order/payment";
        // console.log(data);
      },
    });
  };

  render() {
    let tests = this.props.cart;
    console.log(this.props.cart);

    return (
      <Container className="main-container">
        <Row>
          <Col md={8}>
            <div className="checkout">
              <Row className="auth-links-card" id="checkout-row">
                <div
                  class="nav col-md-12 auth-card-nav"
                  id="myTab"
                  role="tablist"
                >
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <a className="order-line">Order Summary</a>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <a className="order-line">Address</a>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <a className="order-line" onClick="payWithMonnify()">
                      Payment
                    </a>
                  </div>
                </div>
              </Row>
              <ProgressBar now={85} />

              <div className="information-holder">
                <Card style={{ width: "100%" }}>
                  <Card.Header>Payment</Card.Header>

                  <Card.Body className="text-center">
                    <div className="payment-options-card">
                      <p className="body-text">We accept:</p>
                      <img src={paymentoptions} id="paymentoptions"></img>
                    </div>
                  </Card.Body>
                </Card>

                <Row className="">
                  <Col md={6}>
                    <div className="btn-holder">
                      <Link
                        className="btn btn-primary order-previous"
                        to="/order/address"
                      >
                        Previous
                      </Link>
                    </div>
                  </Col>
                  <Col md={6}>
                    <div className="btn-holder right-on-desktop">
                      {this.state.isSubmitted ? (
                        <button className="btn btn-primary paynow" disabled>
                          Submitting...
                        </button>
                      ) : (
                        <button
                          className="btn btn-primary paynow"
                          onClick={this.payWithMonnify}
                        >
                          Proceed to payment
                        </button>
                      )}
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Col>

          <Col md={4}>
            <RigthBar />
          </Col>
        </Row>
        <ToastContainer autoClose={2000} />
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isCart: state.cart.isCart,
    cart: state.cart.cart,
    address: state.address.address,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    emptyCart: () => {
      dispatch(emptyCart());
    },
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Payment);
