import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar , Button } from 'react-bootstrap';
import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from 'react-bootstrap/Card';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import { add_cif3 } from "../../actions/cif";
import CIF4 from '../../components/Order/CIF4';
import history from './../../history';

class CIF3 extends Component
{
    constructor(props)
    {
        super(props);

        this.state = {
            isSubmitted: false,
            user: {},
            cifStep: 3
        }
 
        DebugSentry.instantiate();
    }


    componentDidCatch(error, errorInfo)
    {
        DebugSentry.catchException(error, errorInfo);
    }

    onChangeValue(event)
    {
        console.log(event.target.value);
    }

    componentDidMount(){
        const cif_user = this.props.order.order_user;
        if(cif_user === undefined){
            history.push('/');
        }
    }

    handleChange = event => {
        const { name, value } = event.target;
        const { user } = this.state;
    
        this.setState({
          user: {
            ...user,
            [name]: value
          },
        });
    };

    handleSubmit = (event) => {
        console.log('cif3 data: ',this.state.user)
        this.props.add_cif3(this.state.user);
        event.preventDefault();

        this.setState({
            isSubmitted: true,
            cifStep: 4
        })
    }
    

    render()
    {
        const cif_user = this.props.order.order_user;
        const {
            user,
            isSubmitted,
            cifStep
        } = this.state;

        return (

            <Container className="main-container" >
                {
                    cifStep === 3 ? (<Row>
                        {/* <Col md={12} className="" >
                            <Card style={{ margin: '10px' }}>
                                <Card.Body>
    
                                    <p>Pending Case Information Forms</p>
    
                                    <Row className="mx-auto">
                                        <Col md={4}>
                                        <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }} className="btn btn-lg btn-outline-default">John Smith</Button>
                                        </Col>
    
                                        <Col md={4}>
                                        <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }}  className="btn btn-lg btn-outline-default">John Smith</Button>
    
                                        </Col>
    
                                        <Col md={4}>
    
                                        <Button style={{ backgroundColor: '#BBBBBB' ,  border: '0px' , borderRadius: '5px'}}  className="btn btn-lg btn-outline-default">John Smith</Button>
    
                                        </Col>
                                    </Row>
    
                                </Card.Body>
                            </Card>
                        </Col> */}
    
                        <form onSubmit={this.handleSubmit}>
    
                        <Col md={12} className="" >
                            <Card style={{ margin: '10px' }} className="cif-card">
                                <Card.Body>
                                    <p className="header-description">Case Information Form [{cif_user && cif_user.data.name}]</p>
    
    
                                    <Form.Check style={{ width: '150px' }}  inline label="1" type="radio" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="2" type="radio" />

                                    <Form.Check style={{ width: '150px' }}  inline label="3" defaultChecked="true" type="radio" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="4" type="radio" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="5" type="radio" />
        
    
                                    <p className="section-header">Section 3/5</p>
                                    <Row md={12}>
                                        {/* <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Locations visited in the last one month</Card.Title>
                                            <Form.Control type="text" placeholder="" name="location_of_exposure" onChange={this.handleChange} />
                                        </Col> */}
    
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Have you attended any mass gathering in the past one month? (wedding,funeral, market, mosque/church/ football game/other gathering)<span className="red-asterisk">*</span></Card.Title>
                                            <Form.Control as="select" name="attended_mass_gatherings" onChange={this.handleChange}>
                                            <option value="">Select option</option>
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </Form.Control>
                                        </Col>

                                        {
                                            user.attended_mass_gatherings === "Yes" ? (<Col md={6} style={{ marginBottom: '40px' }}>
                                                <Card.Title className="input-label">If Yes, which of the following</Card.Title>
                                                <Form.Control as="select" name="contact_with_confirmed_or_suspected_cases" onChange={this.handleChange}>
                                                <option value="">Select option</option>
                                                <option value="confirmed">Confirmed case</option>
                                                <option value="suspected">Suspected case</option>
                                                </Form.Control>
                                            </Col>) : null
                                        }
    
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Have you been in contact with a suspected or confirmed case of COVID-19 in the past one month?<span className="red-asterisk">*</span></Card.Title>
                                            <Form.Control as="select" name="status_of_suspected_or_confirmed_case_contact" onChange={this.handleChange} required>
                                            <option value="">Select option</option>
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </Form.Control>
                                        </Col>
    
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Are you a health worker?<span className="red-asterisk">*</span></Card.Title>
                                            <Form.Control as="select" name="health_worker" onChange={this.handleChange} required>
                                                <option value="">Select option</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </Form.Control>
                                        </Col>

                                        {
                                            user.health_worker === "Yes" ? (<Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">If Yes, please specify your designation</Card.Title>
                                            <Form.Control type="text" placeholder="" name="designation" onChange={this.handleChange}/>
                                        </Col>) : null
                                        }

                                            <Col md={6} style={{ marginBottom: '40px' }}>
                                                <Card.Title className="input-label">Did you visit an health facility in the past one month?</Card.Title>
                                                <Form.Control as="select" name="health_facility_visited" onChange={this.handleChange} required>
                                                    <option value="">Select option</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </Form.Control>
                                            </Col>
                                    </Row>
                                </Card.Body>
                                
                            </Card>
    
                            <Col md={12} style={{ display: 'flex' }}>
    
                                <Link to="/order/CIF2">
                                    <button type="button"  style={{ marginRight: 'auto' }}  className="btn btn-primary order-next">
                                        Previous
                                    </button>
                                </Link>
                                
    
                                <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                    Next
                                </button>
                                </Col>
    
                        </Col>
                    </form>
                    </Row>) : (<CIF4 />)
                }
            </Container>
        )

    }

}

const mapDispatchToProps = (dispatch) => {
    return {
        add_cif3: (user) => { dispatch(add_cif3(user)) }
    }
}
  
const mapStateToProps = (state) => {
    return {
      order: state.order,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {}
)(CIF3)

