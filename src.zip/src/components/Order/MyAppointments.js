import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar } from "react-bootstrap";
import Cookies from "universal-cookie";
import { BallPulseSync } from "react-pure-loaders";
import { API_URL } from "../../apis/diagnosemeApi";
import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from "react-bootstrap/Card";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import calendar_graphic from "./../../assets/images/calender_graphic.svg";
import emptybox from "./../../assets/images/empty-box.svg";

import proof_of_id from "./../../assets/images/passport_id.png";
import mask_wearer from "./../../assets/images/mask_wearer.svg";
import Button from "react-bootstrap/Button";
import Table from "react-bootstrap/Table";
import Carousel from "react-bootstrap/Carousel";

import Nav from "react-bootstrap/Nav";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import { getAllPendingBookings } from "./../../actions/order";
import history from "./../../history";

class BookAppointment extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
    this.state = {
      netError: false,
      reports: [],
      isProcessing: true,
      emptyOrder: false,
      collection_center_id: null,
      selectedOrder: [],
    };
  }

  componentDidMount() {
    this.promise = this.props.getAllPendingBookings();
    this.promise
      .catch(() => {})
      .then(() => {
        this.setState({
          isProcessing: false,
        });
      });
  }

  handleToAppointment = (event) => {
    event.preventDefault();
    const { selectedOrder, collection_center_id } = this.state;
    const payload = {
      orders: selectedOrder,
      collection_center_id,
    };
    localStorage.setItem("ordersPayload", JSON.stringify(payload));
    history.push("/order/bookmyappointments");
  };

  handleSelect = (event) => {
    const { selectedOrder } = this.state;
    const { name, value, id, checked } = event.target;
    let data = null;
    if (checked === false) {
      data = selectedOrder.filter((order) => order.order_id != value);
    } else if (checked) {
      const user = JSON.parse(localStorage.getItem("user"));
      const payload = {
        order_id: value,
        passport_number: null,
        name: id,
      };
      data = [...selectedOrder, payload];
    }

    this.setState({
      selectedOrder: data,
      collection_center_id: name,
    });
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  render() {
    const { isProcessing, selectedOrder, bookingDetails } = this.state;
    const { all_pending_bookings } = this.props.order;
    console.log(all_pending_bookings);
    const user = JSON.parse(localStorage.getItem("user"));
    return (
      <div>
        <div className="bluebackground">
          <Container>
            <Row>
              <Col md={12} className="landing_header_row">
                <div className="mt-5 landing_header_text">
                  <p>Hello {user.first_name},</p>
                  <p>
                    You have{" 0 "}
                    <b>
                      {all_pending_bookings && all_pending_bookings.data.length}{" "}
                      Pending Bookings
                    </b>
                  </p>
                </div>
                <div className="mt-1 landing_header_img">
                  <img
                    src={calendar_graphic}
                    alt="calendar_graphic"
                    id="calendar_graphic"
                  ></img>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
        <div className="appointment_section">
          <Container>
            <Row className="reverse_on_mobile landing_header_row">
              <div className="appointment_section_table">
                {/* <div className="text-center mx-auto">
                  <p className="text-center mx-auto mt-4 mb-4">
                    You currently have no pending bookings
                  </p>
                  <Link
                    to="/order/purpose"
                    className="homepage-text-primary-button mt-4"
                  >
                    Order Tests
                  </Link>
                </div> */}
                {!isProcessing && all_pending_bookings && (
                  <table className="table_updates">
                    <thead>
                      <th>Transaction ID</th>
                      <th>Ordered For</th>
                      <th>Action</th>
                    </thead>
                    <tbody class="responsive_row">
                      {/* 
                         {!isProcessing && (
                             <div className="text-center">
                               <BallPulseSync color={"#F05F87"} loading="true" />
                               <p className="loading-p">Loading pending appointments...</p>
                             </div>
                           )}
                    */}
                      <>
                        {Object.keys(all_pending_bookings.data).map(
                          (transaction, i) => {
                            return (
                              <tr>
                                <td
                                  data-column="Transaction ID"
                                  className="body-text-blue"
                                >
                                  {transaction}
                                </td>
                                <td data-column="Ordered For">
                                  {all_pending_bookings.data[transaction].map(
                                    (person, i) => {
                                      return (
                                        <label
                                          for="terms"
                                          className="terms-check"
                                        >
                                          <input
                                            className="checkbox-form"
                                            name={person.center.id}
                                            type="checkbox"
                                            id={person.ordered_for}
                                            value={person.receipt_id}
                                            onChange={this.handleSelect}
                                          />
                                          <p
                                            style={{
                                              paddingTop: "10px",
                                              paddingLeft: "10px",
                                            }}
                                          >
                                            {person.ordered_for}
                                          </p>
                                        </label>
                                      );
                                    }
                                  )}
                                </td>
                                <td data-column="Action">
                                  <Button
                                    onClick={this.handleToAppointment}
                                    type="submit"
                                    className="btn btn-primary order-next"
                                  >
                                    Book Appointment
                                  </Button>
                                </td>
                              </tr>
                            );
                          }
                        )}
                      </>
                    </tbody>
                  </table>
                )}
              </div>
              )}
              <div className="appointment_section_info">
                <p>Appointment Checklist</p>
                <Carousel className="appointment-carousel">
                  <Carousel.Item>
                    <div className="mt-5 appointment_info">
                      <div>
                        <i className="fa fa-check mr-2"></i>
                        <p style={{ width: "85%" }}>
                          Proof of identification (acceptable forms of ID
                          include: passports, National ID cards & Driver’s
                          license)
                        </p>
                      </div>
                      <div className="appointment_image">
                        <img
                          src={proof_of_id}
                          alt="proof_of_id"
                          id="mask_wearer"
                        ></img>
                      </div>
                    </div>
                  </Carousel.Item>
                  <Carousel.Item>
                    <div className="mt-5 appointment_info">
                      <div>
                        <i className="fa fa-check mr-2"></i>
                        <p style={{ width: "85%" }}>
                          A face mask worn over your nose and mouth
                        </p>
                      </div>
                      <div className="appointment_image">
                        <img
                          src={mask_wearer}
                          alt="mask_wearer"
                          id="mask_wearer"
                        ></img>
                      </div>
                    </div>
                  </Carousel.Item>
                </Carousel>
              </div>
            </Row>
          </Container>
          <ToastContainer autoClose={2000} />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  getAllPendingBookings,
})(BookAppointment);
