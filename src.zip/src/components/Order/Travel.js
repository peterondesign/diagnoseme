import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  ProgressBar,
  Button,
} from "react-bootstrap";

import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import history from "./../../history";

import { connect } from "react-redux";
import { updatePayload, getAirports } from "./../../actions/order";

class Travel extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    data: {},
    isSubmitted: false,
    selectedAirport: {},
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    this.props.getAirports();
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    const { data } = this.state;
    this.setState({
      data: {
        ...data,
        [name]: value,
      },
    });
  };

  handleTravel = (e) => {
    // e.preventDefault();
    this.setState({ isSubmitted: true });

    let { response } = this.props.order;
    const { data } = this.state;

    const payload = {
      ...response,
      returnee: data,
    };

    if (data.travel && data.airport && data.travel_date ) {
      this.promise = this.props.updatePayload(payload);
      this.promise
        .catch(() => {})
        .then(() => {
          let isUserLoggedIn = localStorage.getItem("user");
          let { response } = this.props.order;
          localStorage.setItem("payload", JSON.stringify(response));
          localStorage.setItem("covid_checkout", true);

          if (isUserLoggedIn !== null) {
            history.push("/order/details");
          }

          if (isUserLoggedIn === null) {
            history.push("/auth/login/checkout");
          }
        });
    }
  };

  render() {
    let { airport } = this.props.order;
    const { data, isSubmitted } = this.state;

    return (
      <Container className="main-container">
        <Row>
          <Col md={10} className="mx-auto">
            <Card.Header className="card-header">
              Your COVID-19 Order
            </Card.Header>

            <Card className="card-shadow" style={{ width: "100%" }}>
              <Link to="/order/purpose" className="return-anchor">
                <i
                  className="fa fa-arrow-left"
                  style={{ marginRight: "5px" }}
                />
                Back to Purpose of Order{" "}
              </Link>
              <Card.Body>
                <Card className="card-shadow-inside" style={{ width: "100%" }}>
                  <p className="header-description">For Travel </p>

                  <Row>
                    <Col md={6} style={{ marginBottom: "40px" }}>
                      <Card.Title className="input-label">
                        Departing or Arriving into Nigeria
                      </Card.Title>
                      <Form.Control
                        as="select"
                        type="text"
                        name="travel"
                        placeholder=""
                        onChange={this.handleChange}
                        className={
                          "form-group" +
                          (isSubmitted && !data.travel ? " has-bug" : "")
                        }
                      >
                        <option selected disabled>
                          Select an option
                        </option>
                        <option value="Arriving">Arriving</option>
                        <option value="Departing">Departing</option>
                      </Form.Control>
                      {isSubmitted && !data.travel && (
                        <div className="help-block">This field is required</div>
                      )}
                    </Col>

                    <Col md={6} style={{ marginBottom: "40px" }}>
                      <Card.Title className="input-label">
                        Arrival Airport
                      </Card.Title>
                      <Form.Control
                        as="select"
                        type="text"
                        name="airport"
                        placeholder=""
                        onChange={this.handleChange}
                        className={
                            "form-group" +
                            (isSubmitted && !data.airport ? " has-bug" : "")
                          }
                      >
                        <option selected disabled>
                          Select an option
                        </option>
                        {airport &&
                          airport.data.map((item) => {
                            return <option value={item.id}>{item.name}</option>;
                          })}
                      </Form.Control>
                      {isSubmitted && !data.airport && (
                        <div className="help-block">This field is required</div>
                      )}
                    </Col>

                    <Col md={12} style={{ marginBottom: "40px" }}>
                      <Card.Title className="input-label">
                        Departure/Arriving Date
                      </Card.Title>
                      <Form.Control
                        type="date"
                        name="travel_date"
                        placeholder=""
                        onChange={this.handleChange}
                        className={
                            "form-group" +
                            (isSubmitted && !data.travel_date ? " has-bug" : "")
                          }
                      />
                      {isSubmitted && !data.travel_date && (
                        <div className="help-block">This field is required</div>
                      )}
                    </Col>
                  </Row>
                </Card>
              </Card.Body>
              <Col md={12} style={{ display: "flex" }}>
                <Button
                  className="btn btn-primary order-next"
                  style={{ marginLeft: "auto" }}
                  onClick={(e) => this.handleTravel(e)}
                >
                  Proceed
                </Button>
              </Col>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, { updatePayload, getAirports })(Travel);
