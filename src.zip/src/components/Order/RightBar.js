import React, { Component } from "react";
import { connect } from "react-redux";

import { Table, Container, Row, Col } from "react-bootstrap";

class RightBar extends Component {
  state = {
    discount: 0
  };

  render() {
    let sumPrice = 0;
    const { cart, isCart } = this.props;

    return (
      <section className="order-right">
        <div class="text-center col-xs-12 col-md-12 order-nav2">
          Order Summary
        </div>

        <div className="order-right-section">
          <Container>
            <Row>
              <Col md={10} sm={10} xs={10}>
                <p className="order-right-title">Test</p>
              </Col>
              <Col md={2} sm={2} xs={2}>
                <p className="order-right-value">Qty</p>
              </Col>
            </Row>

            {isCart
              ? cart.map(item => {
                  sumPrice += parseInt(item.price);
                  return (
                    <Row key={item.id} className="item-row">
                      <Col md={10} sm={10} xs={10}>
                        <p className="order-right-test">{item.test}</p>
                      </Col>
                      <Col md={2} sm={2} xs={2}>
                        <p className="order-right-qty">1</p>
                      </Col>
                    </Row>
                  );
                })
              : "No test in cart"}

            {/* <Row className="order-right-discount">
              <Col className="order-right-col-dashed">
                <Row>
                  <Col md={7}>
                    <p className="order-right-offset">OFFSET</p>
                  </Col>
                  <Col md={5}>
                    <p className="order-right-discount">Discount Code</p>
                  </Col>
                </Row>
              </Col>
            </Row> */}

            <Row>
              <Col md={7} sm={7} xs={7}>
                <p className="order-right-total">Total amount</p>
              </Col>
              <Col md={5} sm={5} xs={5}>
                <p className="order-right-total-amount">
                  ₦
                  {parseInt(sumPrice).toLocaleString("us", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}
                </p>
              </Col>
            </Row>
          </Container>
        </div>
      </section>
    );
  }
}

const mapStateToProps = state => {
  return {
    isCart: state.cart.isCart,
    cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(RightBar);
