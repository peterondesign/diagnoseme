import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar , Button } from 'react-bootstrap';
import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from 'react-bootstrap/Card';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import { add_cif2 } from "../../actions/cif";
import CIF3 from '../../components/Order/CIF3';
import history from './../../history';

class CIF2 extends Component
{
    constructor(props)
    {
        super(props);

        this.state = {
            isSubmitted: false,
            user: {},
            cifStep: 2
        }
        DebugSentry.instantiate();
    }


    componentDidCatch(error, errorInfo)
    {
        DebugSentry.catchException(error, errorInfo);
    }

    componentDidMount(){
        const cif_user = this.props.order.order_user;
        if(cif_user === undefined){
            history.push('/');
        }
      }

    handleChange = event => {
        const { name, value } = event.target;
        const { user } = this.state;
    
        this.setState({
          user: {
            ...user,
            [name]: value
          },
        });
    };

    handleSubmit = (event) => {
        console.log('cif2 data: ',this.state.user)
        this.props.add_cif2(this.state.user);
        event.preventDefault();

        this.setState({
            isSubmitted: true,
            cifStep: 3
        })
    }
    

    render()
    {
        const cif_user = this.props.order.order_user;
        const {
            user,
            isSubmitted,
            cifStep
        } = this.state;

        return (

            <Container className="main-container" >
                {
                    cifStep === 2 ? (
                    <Row>
                    {/* <Col md={12} className="" >
                        <Card style={{ margin: '10px' }}>
                            <Card.Body>

                                <p>Pending Case Information Forms</p>

                                <Row className="mx-auto">
                                    <Col md={4}>
                                    <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }} className="btn btn-lg btn-outline-default">John Smith</Button>
                                    </Col>

                                    <Col md={4}>
                                    <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }}  className="btn btn-lg btn-outline-default">John Smith</Button>

                                    </Col>

                                    <Col md={4}>

                                    <Button style={{ backgroundColor: '#BBBBBB' ,  border: '0px' , borderRadius: '5px'}}  className="btn btn-lg btn-outline-default">John Smith</Button>

                                    </Col>
                                </Row>

                            </Card.Body>
                        </Card>
                    </Col> */}
                    <form onSubmit={this.handleSubmit}>

                    <Col md={12} className="" >
                        <Card style={{ margin: '10px' }} className="cif-card">
                            <Card.Body>
                                <p className="header-description">Case Information Form [{cif_user && cif_user.data.name}]</p>


                                <Form.Check style={{ width: '150px' }}  inline label="1" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="2" type="radio" defaultChecked="true" />

                                <Form.Check style={{ width: '150px' }}  inline label="3" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="4" type="radio" />

                                <Form.Check style={{ width: '150px' }}  inline label="5" type="radio" />


                                <p className="section-header">Section 2/5</p>
                                <Row md={12}>
                    
                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Is this the first time you are getting tested for COVID-19<span className="red-asterisk">*</span></Card.Title>
                                        <Form.Control as="select" name="initial_or_followup" onChange={this.handleChange} required>
                                            <option>Select option</option>
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </Form.Control>
                                    </Col>

                                    {
                                        user.initial_or_followup === 'No' ? (<Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">If No, please give the date of your last test</Card.Title>
                                        <Form.Control type="date" placeholder="" name="date_respiratory_sample_collected" onChange={this.handleChange} defaultValue={user.date_respiratory_sample_collected}/>
                                    </Col>) : null
                                    }

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Location of lab test (Laboratory, Health facility, home etc)</Card.Title>
                                        <Form.Control type="text" placeholder="" name="location_sample_collected" onChange={this.handleChange} defaultValue={user.lab_tested}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">ORGANISATION/FACILITY</Card.Title>
                                        <Form.Control type="text" placeholder="" name="organization_and_office_address" onChange={this.handleChange} defaultValue={user.facility}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Why are you getting tested</Card.Title>
                                        <Form.Control type="text" placeholder="" name="why_are_you_getting_tested" onChange={this.handleChange} defaultValue={user.why_tested}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Port of Entry into Nigeria</Card.Title>
                                        <Form.Control type="text" placeholder="" name="point_of_entry" onChange={this.handleChange}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Passport Number<span className="red-asterisk">*</span></Card.Title>
                                        <Form.Control type="text" placeholder="" name="passport_number" onChange={this.handleChange} defaultValue={user.passport_number} required/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Country of residence</Card.Title>
                                        <Form.Control type="text" placeholder="" name="country_of_residence" onChange={this.handleChange}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Residential address in country of residence<span className="red-asterisk">*</span></Card.Title>
                                        <Form.Control type="text" placeholder="" name="address" onChange={this.handleChange} defaultValue={user.address} required/>
                                    </Col>
                                    
                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Phone number in country of residence</Card.Title>
                                        <Form.Control type="text" placeholder="" defaultValue={user.phone} name="phone" onChange={this.handleChange}/>
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Employment Status</Card.Title>
                                        <Form.Control type="text" placeholder="" defaultValue={user.employment_status} name="employment_status" onChange={this.handleChange}/>
                                    </Col>
                                </Row>
                                
                            </Card.Body>
                            
                        </Card>

                        <Col md={12} style={{ display: 'flex' }}>

                            <Link to="/order/CIF1">
                                <button type="button"  style={{ marginRight: 'auto' }}  className="btn btn-primary order-next">
                                    Previous
                                </button>
                            </Link>

                            <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                Next
                            </button>
                            </Col>

                    </Col>
                    </form>
                </Row>
                    ): (<CIF3 />)
                }
                
            </Container>
        )

    }

}
  
const mapDispatchToProps = (dispatch) => {
    return {
        add_cif2: (user) => { dispatch(add_cif2(user)) }
    }
}
  
const mapStateToProps = (state) => {
    return {
      order: state.order,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {}
)(CIF2)


