import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar } from 'react-bootstrap';
import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from 'react-bootstrap/Card';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";


export default class BookAppointment extends Component
{
    constructor(props)
    {
        super(props);

        DebugSentry.instantiate();
    }


    componentDidCatch(error, errorInfo)
    {
        DebugSentry.catchException(error, errorInfo);
    }

    onChangeValue(event)
    {
        console.log(event.target.value);
    }

    render()
    {
        return (

            <Container className="main-container" >
                <Row>
                    <Col md={9} className="" >
                        <Card style={{ margin: '10px' }}>
                            <Card.Body>
                                <p className="header-description">Book an Appointment </p>

                                <p>You have 2 pending Case Information Form(s) to complete</p>

                                <Col md={12} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Who are you booking for</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                </Col>

                                <Col md={12} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Sample Collection Location</Card.Title>

                                    <Form.Control as="select">
                                        <option>No 11, Wole Ariyo Street, Lekki Phase 1, Lagos State </option>
                                    </Form.Control>

                                </Col>

                                <Col md={12}>
                                <Calendar/>
                                </Col>

                                <br></br>
                                <Col md={12} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Available Time</Card.Title>

                                    <Form.Control as="select">
                                        <option>9 am </option>
                                        <option>10 am </option>
                                        <option>11 am </option>
                                    </Form.Control>

                                </Col>

                            </Card.Body>
                        </Card>
                    </Col>


                    <Col md={3} className="mx-auto">

                        <Card style={{ margin: '10px' }}>
                            <Card.Body>

                                <p>Appointment Information</p>

                                <Row style={{ marginBotom: '20px' }}>
                                    
                                    <Col md={12}><i className="fa fa-check" style={{ marginRight: '20px' }}></i>  Wear a face mask</Col>


                                    <Col md={12}><i className="fa fa-check" style={{ marginRight: '20px' }}></i>  Bring proof of identification with same details inputted in your booking.</Col>

                                </Row>
                                <hr></hr>

                                <p>Pending Bookings</p>

                                <Row>

                                    <Col md={5}>

                                    <b><p>John Smith </p></b>

                                    <b><p>Jane Smith</p></b>

                                    </Col>

                                    <Col md={7}>

                                    <ul>
                                        hfjbdj<br></br>
                                        Order ID
                                    </ul>

                                    <ul>
                                    hfjbdj<br></br>
                                        Order ID
                                    </ul>

                                    </Col>

                                </Row>
                                

                               


                            </Card.Body>
                        </Card>

                    </Col>


                    {/* <Col md={12} className="" >
                        <Card style={{ margin: '10px' }}>
                            <Card.Body>
                                <p className="">Case Information Form [John Smith]</p>

                                <p>Section 1/7</p>
                                <Row md={12}>
                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Email Address</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Is this the first time you are getting tested for COVID-19</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">If No, please give the date of your last test</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Port of Arrival</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Location of lab test (Laboratory, Health facility, home etc)</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">ORGANISATION/FACILITY</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Why are you getting tested</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Port of Entry into Nigeria</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Passport Number</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Country of residence</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Residential address in country of residence</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>
                                    
                                    <Col md={6} style={{ marginBottom: '40px' }}>
                                        <Card.Title className="input-label">Phone number in country of residence</Card.Title>
                                        <Form.Control type="text" placeholder="" />
                                    </Col>

                                </Row>
                            </Card.Body>
                            
                        </Card>

                        <Col md={12} style={{ display: 'flex' }}>
                                <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                Next
                            </button>
                            </Col>

                    </Col> */}


                </Row>
            </Container>
        )

    }

}

