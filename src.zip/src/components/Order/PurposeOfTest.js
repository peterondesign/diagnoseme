import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar } from "react-bootstrap";

import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import plane from "./../../assets/images/plane.svg";
import heart from "./../../assets/images/heart.svg";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { connect } from "react-redux";
import { updatePayload } from "./../../actions/order";
import history from "./../../history";

class PurposeOfTest extends Component {

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleOrderPurpose = (e, purpose) => {

    // e.preventDefault();
      
    if (purpose) {
        const payload = {
            purpose
        }
        this.promise = this.props.updatePayload(payload);
        this.promise.catch(() => {}).then(() => {  
          let isUserLoggedIn = localStorage.getItem("user");    
          if(isUserLoggedIn === null) {
              localStorage.setItem("payload", JSON.stringify(payload));
              localStorage.setItem("covid_checkout", true);
              // window.location.href = "/auth/login/checkout";
          }
          if(purpose === "Travel"){
            history.push("/order/travel");
          }
          if(purpose === "Personal"){
            history.push("/order/details");
          }
        });
    }
  }

  render() {
    return (
      <Container className="main-container">
        <Row>
          <Col md={10} className="mx-auto">
            <Card.Header className="card-header">
              Your COVID-19 Order
            </Card.Header>

            <Card className="card-shadow" style={{ width: "100%" }}>
              <p style={{ textAlign: "center" }}>
                {" "}
                Select the purpose of your order{" "}
              </p>

              <Card.Body>
                <Row>
                  <Col md={6} style={{ marginBottom: "40px" }}>
                    <div className="purpose-card" onClick={ e => this.handleOrderPurpose(e, 'Travel')}>
                      <Card
                        className="card-shadow travel"
                        style={{ width: "100%", minHeight: "200px" }}
                      >
                        <Row>
                          <Col>
                            <p className="header-description">For Travel</p>

                            <Card.Title className="input-label">
                              To present COVID-19<br></br>
                              information upon travel
                            </Card.Title>
                          </Col>

                          <Col>
                            <Card.Title className="input-label">
                              <img
                                src={plane}
                                style={{ width: "149px" }}
                                alt=""
                              ></img>
                            </Card.Title>
                          </Col>
                        </Row>
                      </Card>
                    </div>
                  </Col>

                  <Col style={{ marginBottom: "40px" }}>
                    <div className="purpose-card" onClick={ e => this.handleOrderPurpose(e, 'Personal')}>
                      <Card
                        className="card-shadow personal"
                        style={{ width: "100%", minHeight: "200px" }}
                      >
                        <Row>
                          <Col>
                            <p className="header-description">
                              For Personal use
                            </p>

                            <Card.Title className="input-label">
                              To know COVID-19 status
                            </Card.Title>
                          </Col>

                          <Col>
                            <Card.Title className="input-label">
                              <img src={heart} style={{ width: "120px" }} alt=""></img>
                            </Card.Title>
                          </Col>
                        </Row>
                      </Card>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = state => {  
    return { 
      order: state.order,
    };
  };
  
export default connect(mapStateToProps, { updatePayload })(PurposeOfTest);
  