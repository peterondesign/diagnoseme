import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar } from "react-bootstrap";

import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import SuccessImage from "./../../assets/images/verification/VerificationSuccess.svg";
import InfoIcon from "./../../assets/images/information_icon.svg";
import { BallPulseSync } from "react-pure-loaders";
import { connect } from "react-redux";
import { getPendingBookings } from "./../../actions/order";
import history from './../../history';

import DebugSentry from "../../apis/DebugSentry";

class PaymentSuccess extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    loading: false,
    transaction: {},
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    const transaction = JSON.parse(localStorage.getItem("transaction"));
    this.setState({
      loading: true,
      transaction,
    });
  }

  handleToAppointment = () => {
      history.push('/order/myappointments');
  }

  render() {
    const { transaction, loading } = this.state;
    const user = JSON.parse(localStorage.getItem("user"));
    console.log(transaction);
    return (
      <Container className="main-container">
        <Row>
          <Col md={11} className="mx-auto">
            {/* <Card.Header className="card-header">
              Your COVID-19 Order
            </Card.Header> */}

            <Card className="card-shadow" style={{ width: "100%" }}>
              <Card.Body>
                <Col md={12} style={{ marginBottom: "40px" }}>
                  <Card
                    className="card-shadow-inside"
                    style={{ width: "100%", minHeight: "150px" }}
                  >
                    <Col>
                      {!loading && (
                        <div className="text-center">
                          <BallPulseSync color={"#F05F87"} loading="true" />
                          <p className="loading-p">
                            We are confirming your payment...
                          </p>
                        </div>
                      )}
                    </Col>

                    <Col>
                      {loading && transaction && (
                        <>
                          <Row style={{ textAlign: "center" }}>
                          <Col md={12}>
                            <p
                              className="header-description"
                              style={{ textAlign: "center" }}
                            >
                              Order Successful
                            </p>
                          </Col>

                         <Col md={12} style={{ textAlign: "center" }}>
                         <img
                            src={SuccessImage}
                            className="img-responsive"
                            alt="Sucess"
                          />
                         </Col>
                          <br></br>

                          <Col md={12} style={{ textAlign: "center", marginTop: "20px" }}>
                          <p>
                            Your order with transaction ID: <b>{transaction.transaction_id}</b>  has been completed and an email has been
                            sent
                            to {user && user.email} with your order details
                          </p>
                         </Col>
                          </Row>

                          

                          <div md={8} className="mt-2">
                            <Card.Body>
                              <div className="information_box">
                                <Row>
                                  <Col md={2}>
                                    <img
                                      src={InfoIcon}
                                      className="img-responsive info_icon"
                                      alt="Sucess"
                                    />
                                  </Col>
                                  <Col md={10} className="my-auto">
                                    <p className="my-0">
                                      You are required to complete your{" "}
                                      <u>case information form</u> and{" "}
                                      <u>
                                        select your appointment date and time
                                      </u>{" "}
                                    </p>
                                  </Col>
                                </Row>
                              </div>
                            </Card.Body>
                          </div>
                        </>
                      )}
                    </Col>
                  </Card>

                  <div md={12} className="mt-5" style={{ display: "flex" }}>
                    <button
                      type="submit"
                      style={{ marginLeft: "auto" }}
                      className="btn btn-primary order-next"
                      onClick={this.handleToAppointment}
                    >
                      Proceed to book appointment
                    </button>
                  </div>
                </Col>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  getPendingBookings,
})(PaymentSuccess);
