import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container , Row , Col, Card, Form, ProgressBar } from 'react-bootstrap';

import RigthBar from './RightBar';
import './../../css/Checkout.css';
import DebugSentry from "../../apis/DebugSentry";

export default class Information extends Component {
    constructor(props) {
        super(props);
    
        DebugSentry.instantiate();
      }
    
      componentDidCatch(error, errorInfo) {
        DebugSentry.catchException(error, errorInfo);
      }

    render() {
        return (

            <Container className="main-container">
                <Row>

                    <Col md={9}>

                        <div className="checkout">
                
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item order-line" id="first-th">
                                    <Link to="/order/summary">1. Order Summary </Link>
                                </li>
                                <li className="nav-item li-arrow order-line"></li>
                                <li class="nav-item order-active order-line">
                                    <Link to="/order/information">2. Additional Information</Link>
                                </li>
                                <li className="nav-item li-arrow"></li>
                                <li class="nav-item">
                                    <Link to="/order/address">3. Address</Link>
                                </li>
                                <li className="nav-item li-arrow"></li>
                                <li class="nav-item">
                                    <Link to="/order/payment">4. Payment</Link>
                                </li>
                            </ul>
                            <ProgressBar now={40} />

                            <div className="information-holder">

                            <Card style={{ width: '100%' }}>
                                <Card.Header>Delivery Location</Card.Header>

                                <Card.Body>
                                    <Card.Title>Select Address</Card.Title>

                                    <Form.Control as="select">
                                        <option>No 11, Wole Ariyo Street, Lekki Phase 1, Lagos State </option>
                                    </Form.Control>
                    
                                </Card.Body>
                            </Card>

                            <Card style={{ width: '100%' }}>
                                <Card.Header>Delivery Time</Card.Header>

                                <Card.Body>

                                    <Row>
                                        <Col md={6}>
                                            <Card.Title>Delivery Date</Card.Title>
                                            <Form.Control type="text" placeholder="19 - 04 - 2020" />
                                        </Col>

                                        <Col md={6}>
                                            <Card.Title>Delivery Time</Card.Title>
                                            <Form.Control type="text" placeholder="8 am - 11 am" />
                                        </Col>
                                    </Row>

                                </Card.Body>
                            </Card>

                            <Card style={{ width: '100%' }}>
                                <Card.Header>Delivery Method</Card.Header>

                                <Card.Body>
                                    <Card.Title>Select Address</Card.Title>

                                    <Form.Control as="select">
                                        <option>No 11, Wole Ariyo Street, Lekki Phase 1, Lagos State </option>
                                    </Form.Control>
                    
                                </Card.Body>
                            </Card>

                            </div>

                        </div>

                    </Col>

                    <Col md={3}>

                        <RigthBar />

                    </Col>
                    
                </Row>
            </Container>
        )
    }
}
