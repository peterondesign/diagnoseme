import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar } from "react-bootstrap";

import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import SuccessImage from "./../../assets/images/verification/VerificationSuccess.svg";
import InfoIcon from "./../../assets/images/information_icon.svg";
import { BallPulseSync } from "react-pure-loaders";
import { connect } from "react-redux";
import { getPendingBookings } from "./../../actions/order";
import history from "./../../history";

import DebugSentry from "../../apis/DebugSentry";

class BookingSuccess extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    loading: false,
    transaction: {},
  };

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleToDashboard = () => {
    history.push("/account/dashboard");
  };

  render() {
    return (
      <Container className="main-container">
        <Row>
          <Col md={11} className="mx-auto">
            <Card.Header className="card-header">
              Your COVID-19 Order
            </Card.Header>

            <Card className="card-shadow" style={{ width: "100%" }}>
              <Card.Body>
                <Col md={12} style={{ marginBottom: "40px" }}>
                  <Card
                    className="card-shadow-inside"
                    style={{ width: "100%", minHeight: "150px" }}
                  >
                    <Col>
                      <p
                        className="header-description"
                        style={{ textAlign: "center" }}
                      >
                        Appointment Booked Successfully
                      </p>

                      <img
                        src={SuccessImage}
                        className="img-responsive"
                        alt="Sucess"
                      />
                      <br></br>

                      <p style={{ textAlign: "center" }}>
                        Appointment for your Covid-19 test has been booked successfully.
                      </p>

                      <div md={8} className="mt-2">
                        <Card.Body>
                          <div className="information_box">
                            <Row>
                              <Col md={2}>
                                <img
                                  src={InfoIcon}
                                  className="img-responsive info_icon"
                                  alt="Sucess"
                                />
                              </Col>
                              <Col md={10} className="my-auto">
                                <p className="my-0">
                                  You are required to complete your{" "}
                                  <u>case information form</u> and{" "}
                                  <u>select your appointment date and time</u>{" "}
                                </p>
                              </Col>
                            </Row>
                          </div>
                        </Card.Body>
                      </div>
                    </Col>
                  </Card>

                  <div md={12} className="mt-5" style={{ display: "flex" }}>
                    <button
                      type="submit"
                      style={{ marginLeft: "auto" }}
                      className="btn btn-primary order-next"
                      onClick={this.handleToAppointment}
                    >
                      Go to Dashboard
                    </button>
                  </div>
                </Col>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  getPendingBookings,
})(BookingSuccess);
