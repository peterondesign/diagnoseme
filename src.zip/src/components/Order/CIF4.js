import React, { Component } from 'react';
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar , Button } from 'react-bootstrap';
import RigthBar from './RightBar';
import './../../css/Checkout.css';
import './../../css/Travel.css';
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from 'react-bootstrap/Card';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import { add_cif4 } from "../../actions/cif";
import CIF5 from '../../components/Order/CIF5';
import history from './../../history';

class CIF4 extends Component
{
    constructor(props)
    {
        super(props);
 
        this.state = {
            isSubmitted: false,
            user: {},
            cifStep: 4
        }

        DebugSentry.instantiate();
    }


    componentDidCatch(error, errorInfo)
    {
        DebugSentry.catchException(error, errorInfo);
    }

    onChangeValue(event)
    {
        console.log(event.target.value);
    }

    handleChange = event => {
        const { name, value } = event.target;
        const { user } = this.state;
    
        this.setState({
          user: {
            ...user,
            [name]: value
          },
        });
    };

    componentDidMount(){
        const cif_user = this.props.order.order_user;
        if(cif_user === undefined){
            history.push('/');
        }
      }

    handleSubmit = (event) => {
        console.log('cif4 data: ',this.state.user)
        this.props.add_cif4(this.state.user);
        event.preventDefault();

        this.setState({
            isSubmitted: true,
            cifStep: 5
        })
    }

    render()
    {
        const cif_user = this.props.order.order_user;
        const {
            user,
            isSubmitted,
            cifStep
        } = this.state;
        
        return (

            <Container className="main-container" >
                {
                    cifStep === 4 ? (<Row>
                        {/* <Col md={12} className="" >
                            <Card style={{ margin: '10px' }}>
                                <Card.Body>
    
                                    <p>Pending Case Information Forms</p>
    
                                    <Row className="mx-auto">
                                        <Col md={4}>
                                        <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }} className="btn btn-lg btn-outline-default">John Smith</Button>
                                        </Col>
    
                                        <Col md={4}>
                                        <Button style={{ backgroundColor: '#BBBBBB' , border: '0px' , borderRadius: '5px' }}  className="btn btn-lg btn-outline-default">John Smith</Button>
    
                                        </Col>
    
                                        <Col md={4}>
    
                                        <Button style={{ backgroundColor: '#BBBBBB' ,  border: '0px' , borderRadius: '5px'}}  className="btn btn-lg btn-outline-default">John Smith</Button>
    
                                        </Col>
                                    </Row>
    
                                </Card.Body>
                            </Card>
                        </Col> */}
                        <form onSubmit={this.handleSubmit}>
                        <Col md={12} className="" >
                            <Card style={{ margin: '10px' }} className="cif-card">
                                <Card.Body>
                                    <p className="header-description">Case Information Form [{cif_user && cif_user.data.name}]</p>
    
    
                                    <Form.Check style={{ width: '150px' }}  inline label="1" type="radio" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="2" type="radio" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="3" type="radio"/>
    
                                    <Form.Check style={{ width: '150px' }}  inline label="4" type="radio"  defaultChecked="true" />
    
                                    <Form.Check style={{ width: '150px' }}  inline label="5" type="radio" />
        
    
                                    <p className="section-header">Section 4/5</p>
                                    <Row md={12}>
                                        
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Have you traveled internationally within the last 14 days<span className="red-asterisk">*</span></Card.Title>
                                            <Form.Control as="select" name="international_travel" onChange={this.handleChange} required>
                                            <option value="">Select option</option>
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </Form.Control>
                                        </Col>

                                        {
                                            user.international_travel === "Yes" ? (<Container><Row>
                                                <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Traveled Country (Country, State)</Card.Title>
                                            <Form.Control type="text" placeholder="" name="countries_visited" onChange={this.handleChange}/>
                                        </Col>
    
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Point of Entry</Card.Title>
                                            <Form.Control as="select" name="point_of_entry" onChange={this.handleChange} required>
                                            <option value="">Select option</option>
                                            <option value="air">Air</option>
                                            <option value="land">Land</option>
                                            <option value="sea">Sea</option>
    
                                        </Form.Control>
                                        </Col>
    
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Port Name</Card.Title>
                                            <Form.Control type="text" placeholder="Port of entry name" name="port_name" onChange={this.handleChange}/>
                                        </Col>
                                        </Row></Container>) : null
                                        }

                                        
                                        <Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">Have you traveled domestically within the last 14 days</Card.Title>
                                            <Form.Control as="select" required name="domestic_travel" onChange={this.handleChange}> 
                                                <option value="">Select option</option>
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </Form.Control>
                                        </Col>
                                        {
                                            user.domestic_travel === "Yes" ? (<Col md={6} style={{ marginBottom: '40px' }}>
                                            <Card.Title className="input-label">States and cities visited</Card.Title>
                                            <Form.Control type="text" placeholder="" name="domestic_cities_visited" onChange={this.handleChange}/>
                                        </Col>) : null
                                        }
                                    </Row>
                                </Card.Body>
                                
                            </Card>
    
                            <Col md={12} style={{ display: 'flex' }}>
    
                                <Link to="/order/CIF3">
                                    <button type="button"  style={{ marginRight: 'auto' }}  className="btn btn-primary order-next">
                                        Previous
                                    </button>
                                </Link>
    
                                <button type="submit" style={{ marginLeft: 'auto' }}  className="btn btn-primary order-next">
                                    Next
                                </button>
                                </Col>
    
                        </Col>
    
                        </form>
                    </Row>) : (<CIF5/>)
                }
                    
            </Container>
        )

    }

}

const mapDispatchToProps = (dispatch) => {
    return {
        add_cif4: (user) => { dispatch(add_cif4(user)) }
    }
}
  
const mapStateToProps = (state) => {
    return {
      order: state.order,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {}
)(CIF4)

