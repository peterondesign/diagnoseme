import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { connect } from "react-redux";
import { PropTypes } from "prop-types";
import { toast } from "react-toastify";
import axios from 'axios'
import { ToastContainer } from "react-toastify";
import { Container, Row, Col, ProgressBar } from "react-bootstrap";
import Table from 'react-bootstrap/Table'
import { API_URL } from '../../apis/diagnosemeApi'
import Cookies from 'universal-cookie';
import RigthBar from "./RightBar";

import "./../../css/Checkout.css";
import DebugSentry from "../../apis/DebugSentry";

class Summary extends Component {
  state = {
    discount: null
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    if(localStorage.getItem('user')== null) {
      window.location.href="/"
    }
    console.log(this.props.location.state);
    localStorage.removeItem('checkout')
  }

  handleDiscount = (e) => {
    let value = e.target.value
    if(value.length > 5) {
      this.setState({discount:value})
    }
    
  }

  applyDiscount = (e) => {
    e.preventDefault()
    const code = e.target.value;
    const data = { 'code': this.state.discount}
    const cookies = new Cookies();
    const headers = {
      'Content-Type': 'application/json',
      'authorization': cookies.get("authorization")
    }
    axios.post(`${API_URL}discount/find/`,data, {
      headers: headers
    })

      .then(response => this.discountApplied(response.data))
   
   
    
  }

  discountApplied = (result) => {
    // console.log(result)
    console.log(result.data.applies_to)
    if(result.success == true) {
      const applies_to = result.data.applies_to
      const discount_type = result.data.discount_type
      let value=0
      // let percent=0
      if(discount_type == 1 ) {
        value = result.data.percentage_discount
        this.props.cart.filter(row => {
          if(row.testId == applies_to) {
            const percent = value*row.price/100
            row.price = row.price - percent
            this.props.history.push('/order/address')
            return row
  
          } else {
            alert('This code is not for this order or test in your cart')
          }
        })
      } else {
        value = result.data.percentage_discount
      this.props.cart.filter(row => {
        if(row.testId == applies_to) {
          row.price = row.price - value
          this.props.history.push('/order/address')
          return row

        } else {
          alert('This code is not for this order or test in your cart')
        }
      })
    }
  } else {
    alert('Invalid or expired code')
  }

    
  }

  componentDidUpdate(prev) {
    if(this.props.cart == prev.cart) {
      console.log('updated', prev.cart)
    }
  }

  render() {
    let sumPrice = 0;
    const { cart, isCart } = this.props;

    return (
      <Container className="main-container">
        <Row>
          <Col md={8}>
            <div className="checkout-holder-main">
              <Row className="auth-links-card" id="checkout-row">
                <div
                  class="nav col-md-12 auth-card-nav"
                  id="myTab"
                  role="tablist"
                >
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <p className="order-line my-auto">
                      Order Summary
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 disabled-nav">
                    <p className="order-line my-auto" >
                      Address
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 disabled-nav">
                    <p className="order-line my-auto">
                      Payment
                    </p>
                  </div>
                </div>
              </Row>

              <ProgressBar now={15} />

              

              <div className="order-summary-inner">
                <div className="order-summary-inner-main">
              
                <Table responsive borderless hover className="fixed-height-on-mobile">
                <thead>
                  <tr>

                    <th className="width-table-test">Test</th>
                    <th className="width-table-quantity">Quantity</th>
                    <th className="width-table-price">Price</th>
                  </tr>
                </thead>

                {isCart
                  ? cart.map(item => {
                    sumPrice += parseInt(item.price);
                    return (
                      <>
                        <tbody>
                          <tr>
                            <td className="width-table-test">{item.test}</td>
                            <td className="width-table-quantity">1</td>
                            <td className="width-table-price">₦{parseInt(item.price).toLocaleString("us", {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2
                            })}</td>
                          </tr>
                      </tbody>
                      </>
                      );
                    })
                    : "No test in cart"}
              </Table>
              <form onSubmit={this.applyDiscount}>
                  <Row>
                  <Table responsive borderless hover className="fixed-height-on-mobile">
                    <tbody>
                      <tr>
                        <td>Discount Code</td>
                        <td>
                          <input type="text" name="discount" className="form-control" style={{width:'200px', height:'40'}} onChange={this.handleDiscount} required/>
                        </td>
                        <td>
                        <button type="submit" className="btn btn-primary order-next">
                          Apply
                      </button>
                        </td>
                      </tr>
                    </tbody>
                  </Table>
                  </Row>
                  </form>
                  <Row className="">
                    <Col md={12}>
                      <div className="btn-holder right-on-desktop">
                        <Link className="btn btn-primary pull-right order-next" to="/order/address">
                          Next
                          </Link>
                      </div>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </Col>

          <Col md={4}>
            <RigthBar state={this.props.cart} />
          </Col>
        </Row>
        <ToastContainer autoClose={10000} />
      </Container>
    );
  }
}

Summary.propTypes = {
  allCart: PropTypes.array
};

const mapStateToProps = state => {
  return {
    isCart: state.cart.isCart,
    cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(Summary);
