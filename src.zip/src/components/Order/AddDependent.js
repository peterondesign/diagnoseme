import React, { Component } from "react";
import {
    Row,
    Col,
    Card,
    Form,
  } from "react-bootstrap";
  import {
    addDependent,
  } from "./../../actions/order";
  import { connect } from "react-redux";

class AddDependent extends Component {
  state = {
    addDependent: null,
    dependentData: {},
    useDependentEmail: false,
  };

  handleAddDependent = (event) => {
    event.preventDefault();
    this.setState({ addDependent: true })
    const { useDependentEmail } = this.state;
    const user = JSON.parse(localStorage.getItem("user"));

    let first_name = event.target.dependent_first_name.value;
    let last_name = event.target.dependent_last_name.value;
    let name = first_name + " " + last_name;
    let dob = event.target.dependent_dob.value;
    let phone = event.target.dependent_phone.value;
    let gender = event.target.dependent_gender.value;
    let email = null;

    if (useDependentEmail) {
      email = event.target.dependent_email.value;

      if (!email || email ==  "") {
        email = user.email;
      }

    } else {
      email = user.email;
    }

    const dependent = {
      name,
      first_name,
      last_name,
      email,
      dob,
      phone,
      gender,
    };

    if (first_name && last_name && email && gender && dob && phone) {

      this.promise = this.props.addDependent(dependent);
      this.promise
        .catch(() => {})
        .then(() => {
          this.promise = this.props.getDependents();
          this.promise
            .catch(() => {})
            .then(() => {
              const { data } = this.props.order.dependents;
              this.setState({
                dependents: data,
                showForm: false,
              });
            });
        });
    }
  };

  render() {
    const { dependentData, addDependent, useDependentEmail } = this.state;

    return (
      <form onSubmit={this.handleAddDependent}>
        <hr></hr>
        <Row>
          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">First Name</Card.Title>
            <Form.Control
              type="text"
              name="dependent_first_name"
              placeholder=""
            />
          </Col>

          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">Last Name</Card.Title>
            <Form.Control
              type="text"
              name="dependent_last_name"
              placeholder=""
              onChange={this.handleDependentData}
            />
          </Col>

          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">Phone Number</Card.Title>
            <Form.Control
              type="number"
              name="dependent_phone"
              placeholder=""
              onChange={this.handleDependentData}
            />
          </Col>

          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">Date of Birth</Card.Title>
            <Form.Control
              type="date"
              name="dependent_dob"
              placeholder=""
              onChange={this.handleDependentData}
            />
          </Col>

          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">State of residence</Card.Title>
            <Form.Control
              type="text"
              name="dependent_state"
              placeholder=""
              onChange={this.handleDependentData}
            />
          </Col>

          <Col md={6} style={{ marginBottom: "10px" }}>
            <Card.Title className="input-label">Gender</Card.Title>
            <Form.Control
              as="select"
              name="dependent_gender"
              onChange={this.handleDependentData}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
            </Form.Control>
            {addDependent && !dependentData.dependent_gender && (
              <div className="help-block">This field is required</div>
            )}
          </Col>

          {useDependentEmail && (
            <Col md={6} style={{ marginBottom: "10px" }}>
              <Card.Title className="input-label">Email Address</Card.Title>
              <Form.Control
                type="email"
                name="dependent_email"
                placeholder=""
                onChange={this.handleDependentData}
              />
            </Col>
          )}

          <Col md={12}>
            {!useDependentEmail && (
              <p
                style={{
                  margin: "15px 0px",
                  fontSize: "12px",
                  cursor: "pointer",
                  color: "#507fd4",
                }}
                onClick={() =>
                  this.setState({
                    useDependentEmail: !useDependentEmail,
                  })
                }
              >
                Add email address for dependent to receive access to result
              </p>
            )}

            {useDependentEmail && (
              <p
                style={{
                  margin: "15px 0px",
                  fontSize: "12px",
                  cursor: "pointer",
                  color: "#507fd4",
                }}
                onClick={() =>
                  this.setState({
                    useDependentEmail: !useDependentEmail,
                  })
                }
              >
                Remove email address for you to have access to result
              </p>
            )}
          </Col>

          <Col md={12} style={{ display: "flex" }}>
            <button
              type="submit"
              style={{ marginLeft: "auto" }}
              className="btn btn-primary order-next"
            >
              Add Dependent
            </button>
          </Col>
        </Row>
      </form>
    );
  }
}

const mapStateToProps = (state) => {
    return {
      order: state.order,
    };
  };
  
  export default connect(mapStateToProps, {
    addDependent,
  })(AddDependent);
  