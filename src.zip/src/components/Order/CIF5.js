import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  ProgressBar,
  Button,
} from "react-bootstrap";
import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from "react-bootstrap/Card";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import { add_cif5 } from "../../actions/cif";
import axios from "axios";
import { API_URL } from "../../apis/diagnosemeApiV2";
import history from "./../../history";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import Cookies from "universal-cookie";

class CIF5 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isSubmitted: false,
      user: {},
      cifStep: 5,
      medicalCondition: [],
      symptoms: [],
      loading: false,
      caseSymptoms: {
        fever_above_38: "No",
        sore_throat: "No",
        runny_nose: "No",
        cough: "No",
        shortness_of_breath: "No",
        vomitting: "No",
        diarrhoea: "No",
        chest_pain: "No",
        abdominal_pain: "No",
        nausea: "No",
        confused_or_disoriented: "No",
        loss_of_taste: "No",
        headache: "No",
        malaise: "No",
        muscle_pain: "No",
        joint_pain_or_athritis: "No",
        fatique_and_general_weakness: "No",
        loss_of_sense_of_smell: "No",
        tuberculosis: "No",
        hiv: "No",
        chronic_bronchitis_or_other_long_diseases: "No",
        sickle_cell_disease: "No",
        cardiovascular_disease: "No",
        overweight: "No",
        asthma_requiring_medication: "No",
        diabetes: "No",
        high_blood_pressure: "No",
        no_underlying_condition: "No",
      },
    };

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    const cif_user = this.props.order.order_user;
    if (cif_user === undefined) {
      history.push("/");
    }
  }

  onChangeValue(event) {
    console.log(event.target.value);
  }

  handleSymptomsUpdate = (event) => {
    const { name, checked } = event.target;
    const { caseSymptoms } = this.state;
    let value = "No";

    if (checked) {
      value = "Yes";
    }

    this.setState({
      caseSymptoms: {
        ...caseSymptoms,
        [name]: value,
      },
    });
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value,
      },
    });
  };

  // handleMedicalConditionChange = (event) => {

  //     const selected=[];
  //     let selectedOption=(event.target.selectedOptions);

  //     for (let i = 0; i < selectedOption.length; i++){
  //         selected.push(selectedOption.item(i).value)
  //     }

  //     if (selected === undefined || selected.length == 0) {
  //         this.setState({ medicalCondition: [] });
  //     } else {
  //         this.setState({ medicalCondition: selected });
  //         console.log('selected options: ', selected)
  //     }
  // }

  // handleSymptomsChange = (event) => {
  //     const selected_symptoms=[];
  //     let selectedOption=(event.target.selectedOptions);

  //     for (let i = 0; i < selectedOption.length; i++){
  //         selected_symptoms.push(selectedOption.item(i).value)
  //     }

  //     if (selected_symptoms === undefined || selected_symptoms.length == 0) {
  //         this.setState({ symptoms: [] });
  //     } else {
  //         this.setState({ symptoms: selected_symptoms });
  //         console.log('selected options: ', selected_symptoms)
  //     }
  // }

  handleSubmit = (event) => {
    this.setState({
      loading: true,
    });
    const { caseSymptoms } = this.state;
    const cif_user = this.props.order.order_user;
    var today = new Date();
    var birthDate = new Date(cif_user.data.dob);
    var age = today.getFullYear() - birthDate.getFullYear();

    event.preventDefault();

    let user_details = {
      firstname: cif_user.data.first_name,
      lastname: cif_user.data.last_name,
      email: cif_user.data.email,
      dob: cif_user.data.dob,
      age: age,
      gender: cif_user.data.gender,
      nationality: this.props.cif1.nationality,
      lga: this.props.cif1.lga,
      address: this.props.cif1.address,
      order_id: cif_user.data.order_id,

      initial_or_followup: this.props.cif2.initial_or_followup,
      location_sample_collected: this.props.cif2.location_sample_collected,
      organization_and_office_address: this.props.cif2
        .organization_and_office_address,
      country_of_residence: this.props.cif2.country_of_residence,
      date_respiratory_sample_collected: this.props.cif2
        .date_respiratory_sample_collected,
      employment_status: this.props.cif2.employment_status,
      passport_number: this.props.cif2.passport_number,
      point_of_entry: this.props.cif2.point_of_entry,
      why_are_you_getting_tested: this.props.cif2.why_are_you_getting_tested,
      phone: this.props.cif2.phone,

      attended_mass_gatherings: this.props.cif3.attended_mass_gatherings,
      contact_with_confirmed_or_suspected_cases: this.props.cif3
        .contact_with_confirmed_or_suspected_cases,
      health_worker: this.props.cif3.health_worker,
      location_of_exposure: this.props.cif3.location_of_exposure,
      status_of_suspected_or_confirmed_case_contact: this.props.cif3
        .status_of_suspected_or_confirmed_case_contact,
      designation: this.props.cif3.designation,

      international_travel: this.props.cif4.international_travel,
      countries_visited: this.props.cif4.countries_visited,
      point_of_entry: this.props.cif4.point_of_entry,
      port_name: this.props.cif4.port_name,
      domestic_travel: this.props.cif4.domestic_travel,
      domestic_cities_visited: this.props.cif4.domestic_cities_visited,

      medical_condition: this.state.user.medical_condition,
      symptoms_past_2_weeks: this.state.user.symptoms_past_2_weeks,
      filling_this_form_yourself: this.state.user.filling_this_form_yourself,
      first_symptom: this.state.user.first_symptom,
      symptoms: this.state.user.symptoms,
      ...caseSymptoms,
    };
    const cookies = new Cookies();
    const token = cookies.get("authorization");

    const options = {
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
    };
    
    axios.post(`${API_URL}add-caseinfo`, user_details, options)
     .then((res) => {
      toast.success("CIF data submitted successfully");
      setTimeout(function () {
        history.push("/account/dashboard");
      }, 2000);
     })
     .catch((err) => {
      toast.error("Sorry! There was an error. Please try again");
     })

    this.setState({
      loading: false,
      isSubmitted: true,
    });
  };

  render() {
    const cif_user = this.props.order.order_user;
    const { user, isSubmitted, loading, cifStep, caseSymptoms } = this.state;
    console.log(caseSymptoms);
    return (
      <Container className="main-container">
        {cifStep === 5 ? (
          <Row>
            <Col md={12} className="">
              <Card style={{ margin: "10px" }}>
                <Card.Body>
                  <p>Pending Case Information Forms</p>

                  <Row className="mx-auto">
                    <Col md={4}>
                      <Button
                        style={{
                          backgroundColor: "#BBBBBB",
                          border: "0px",
                          borderRadius: "5px",
                        }}
                        className="btn btn-lg btn-outline-default"
                      >
                        John Smith
                      </Button>
                    </Col>

                    <Col md={4}>
                      <Button
                        style={{
                          backgroundColor: "#BBBBBB",
                          border: "0px",
                          borderRadius: "5px",
                        }}
                        className="btn btn-lg btn-outline-default"
                      >
                        John Smith
                      </Button>
                    </Col>

                    <Col md={4}>
                      <Button
                        style={{
                          backgroundColor: "#BBBBBB",
                          border: "0px",
                          borderRadius: "5px",
                        }}
                        className="btn btn-lg btn-outline-default"
                      >
                        John Smith
                      </Button>
                    </Col>
                  </Row>
                </Card.Body>
              </Card>
            </Col>

            <form onSubmit={this.handleSubmit}>
              <Col md={12} className="">
                <Card style={{ margin: "10px" }} className="cif-card">
                  <Card.Body>
                    <p className="header-description">
                      Case Information Form [{cif_user && cif_user.data.name}]
                    </p>

                    <Form.Check
                      style={{ width: "150px" }}
                      inline
                      label="1"
                      type="radio"
                    />

                    <Form.Check
                      style={{ width: "150px" }}
                      inline
                      label="2"
                      type="radio"
                    />

                    <Form.Check
                      style={{ width: "150px" }}
                      inline
                      label="3"
                      type="radio"
                    />

                    <Form.Check
                      style={{ width: "150px" }}
                      inline
                      label="4"
                      type="radio"
                    />

                    <Form.Check
                      style={{ width: "150px" }}
                      inline
                      label="5"
                      type="radio"
                      defaultChecked="true"
                    />

                    <p className="section-header">Section 5/5</p>
                    <Row md={12}>
                      <Col md={12} style={{ marginBottom: "40px" }}>
                        <Card.Title className="input-label">
                          Do you have any underlying medical conditions?
                        </Card.Title>
                        {/* <Form.Control as="select" multiple name="medical_condition" onChange={this.handleMedicalConditionChange}>
                                            <option value="High blood Pressure">High blood Pressure</option>
                                            <option value="Diabetes">Diabetes</option>
                                            <option value="Asthma requiring medication">Asthma requiring medication</option>
                                            <option value="Overweight">Overweight</option>
                                            <option value="Cardiovascular disease">Cardiovascular disease</option>
                                            <option value="Sickle cell disease">Sickle cell disease</option>
                                            <option value="Chronic bronchitis or other chronic lung disease (NOT ASTHMA)">Chronic bronchitis or other chronic lung disease (NOT ASTHMA)</option>
                                            <option value="HIV">HIV</option>
                                            <option value="no underlying medical condition">no underlying medical condition</option>
                                            <option value="Tuberculosis (past or active)">Tuberculosis (past or active)</option>
                                        </Form.Control> */}
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="high_blood_pressure"
                              value="High blood Pressure"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            High blood Pressure
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="diabetes"
                              value="Diabetes"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Diabetes
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="asthma_requiring_medication"
                              value="Asthma requiring medication"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Asthma requiring medication
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="overweight"
                              value="Overweight"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Overweight
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="cardiovascular_disease"
                              value="Cardiovascular disease"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Cardiovascular disease
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="sickle_cell_disease"
                              value="Sickle cell disease"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Sickle cell disease
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="chronic_bronchitis_or_other_long_diseases"
                              value="Chronic bronchitis or other chronic lung disease (NOT ASTHMA)"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Chronic bronchitis or other chronic lung disease
                            (NOT ASTHMA)
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="hiv"
                              value="HIV"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            HIV
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="no_underlying_condition"
                              value="No underlying medical condition"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            No underlying medical condition
                          </label>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input
                              type="checkbox"
                              name="tuberculosis"
                              value="Tuberculosis (past or active)"
                              onChange={this.handleSymptomsUpdate}
                            />{" "}
                            Tuberculosis (past or active)
                          </label>
                        </div>
                      </Col>

                      <Col md={12} style={{ marginBottom: "40px" }}>
                        <Card.Title className="input-label">
                          Have you had any symptoms in the past two weeks?
                        </Card.Title>
                        <Form.Control
                          as="select"
                          name="symptoms_past_2_weeks"
                          onChange={this.handleChange}
                          required
                        >
                          <option value="">Select option</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </Form.Control>
                      </Col>

                      {user.symptoms_past_2_weeks === "Yes" ? (
                        <Container>
                          <Row>
                            <Col md={6} style={{ marginBottom: "40px" }}>
                              <Card.Title className="input-label">
                                First symptom (If none, please indicate)
                              </Card.Title>
                              <Form.Control
                                type="text"
                                name="first_symptom"
                                onChange={this.handleChange}
                                placeholder=""
                              />
                            </Col>

                            <Col md={6} style={{ marginBottom: "40px" }}>
                              <Card.Title className="input-label">
                                Date of Symptoms onset.
                              </Card.Title>
                              <Form.Control
                                type="date"
                                name="first_symptom_date"
                                onChange={this.handleChange}
                                placeholder=""
                              />
                            </Col>
                            <Col md={6} style={{ marginBottom: "40px" }}>
                              <Card.Title className="input-label">
                                Symptoms
                              </Card.Title>
                              {/* <Form.Control as="select" multiple name="symptoms" onChange={this.handleSymptomsChange}>
                                            <option value="Fever">Fever</option>
                                            <option value="Cough">Cough</option>
                                            <option value="Chest pain">Chest pain</option>
                                            <option value="Sore throat">Sore throat</option>
                                            <option value="Runny nose">Runny nose</option>
                                            <option value="Difficulty breathing/Dyspnea">Difficulty breathing/Dyspnea</option>
                                            <option value="Confused or disoriented">Confused or disoriented</option>
                                            <option value="Abdominal pain">Abdominal pain</option>
                                            <option value="Nausea">Nausea</option>
                                            <option value="Vomiting">Vomiting</option>
                                            <option value="Diarrhea">Diarrhea</option>
                                            <option value="Loss of sense of smell">Loss of sense of smell</option>
                                            <option value="Loss of taste">Loss of taste</option>
                                            <option value="Fatigue/general weakness">Fatigue/general weakness</option>
                                            <option value="Malaise">Malaise</option>
                                            <option value="Joint pain or arthritis">Joint pain or arthritis</option>
                                            <option value="Muscle pain">Muscle pain</option>
                                            <option value="Headache">Headache</option>
                                        </Form.Control> */}
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="fever_above_38"
                                    value="Fever"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Fever
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="cough"
                                    value="Cough"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Cough
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="chest_pain"
                                    value="Chest pain"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Chest pain
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="sore_throat"
                                    value="Sore throat"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Sore throat
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="runny_nose"
                                    value="Runny nose"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Runny nose
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="shortness_of_breath"
                                    value="Difficulty breathing/Dyspnea"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Difficulty breathing/Dyspnea
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="confused_or_disoriented"
                                    value="Confused or disoriented"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Confused or disoriented
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="abdominal_pain"
                                    value="Abdominal pain"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Abdominal pain
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="nausea"
                                    value="Nausea"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Nausea
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="vomitting"
                                    value="Vomiting"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Vomiting
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="diarrhoea"
                                    value="Diarrhea"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Diarrhea
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="loss_of_sense_of_smell"
                                    value="Loss of sense of smell"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Loss of sense of smell
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="loss_of_taste"
                                    value="Loss of taste"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Loss of taste
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="fatique_and_general_weakness"
                                    value="Fatigue/general weakness"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Fatigue/general weakness
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="malaise"
                                    value="Malaise"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Malaise
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="joint_pain_or_athritis"
                                    value="Joint pain or arthritis"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Joint pain or arthritis
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="muscle_pain"
                                    value="Muscle pain"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Muscle pain
                                </label>
                              </div>
                              <div class="checkbox">
                                <label>
                                  <input
                                    type="checkbox"
                                    name="headache"
                                    value="Headache"
                                    onChange={this.handleSymptomsUpdate}
                                  />{" "}
                                  Headache
                                </label>
                              </div>
                            </Col>
                          </Row>
                        </Container>
                      ) : null}
                    </Row>
                  </Card.Body>
                </Card>

                <Col md={12} style={{ display: "flex" }}>
                  <Link to="/order/CIF4">
                    <button
                      type="button"
                      style={{ marginRight: "auto" }}
                      className="btn btn-primary order-next"
                    >
                      Previous
                    </button>
                  </Link>

                  <button
                    type="submit"
                    style={{ marginLeft: "auto" }}
                    className="btn btn-primary order-next"
                    disabled={loading}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing</span>}
                    {!loading && <span>Submit</span>}
                  </button>
                </Col>
              </Col>
            </form>
          </Row>
        ) : null}
        <ToastContainer autoClose={2000} />
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    cif1: state.cif.cif_1,
    cif2: state.cif.cif_2,
    cif3: state.cif.cif_3,
    cif4: state.cif.cif_4,
    cif5: state.cif.cif_5,
    order: state.order,
  };
};

export default connect(mapStateToProps, null)(CIF5);
