import React, { useState, Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Card, Form, ProgressBar, Button } from "react-bootstrap";
import { connect } from "react-redux";
import { addAddress } from "../../actions/address";
import { API_URL } from '../../apis/diagnosemeApi'
import DatePicker from 'react-datepicker'
import "react-datepicker/dist/react-datepicker.css";
import { addDays } from 'date-fns';



import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import DebugSentry from "../../apis/DebugSentry";

class Address extends Component {

  constructor(props) {
    super(props);
    if (localStorage.getItem('user') == null) {
      window.location.href = "/"
    }
    const user = localStorage.getItem('user')
    const userAddress = JSON.parse(user).address
    this.state = {
      user: {
        address: userAddress,
        delivery_date: '',
        delivery_time: '',
        delivery_method: '',
        delivery_state: '',
        lga: ''
      },
      isSubmitted: false,
      success: false,
      buttonDisabled: false,
      states: [],
      stateLg: [],
      centers: []
    };
    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }
  
  componentDidMount() {
    if (localStorage.getItem('user') == null) {
      window.location.href = "/"
    }
    this.getStates();
  }



  getStates = async () => {
    fetch(`${API_URL}states/active`)
      .then(response => response.json())
      .then(response => (this.setState({ states: response.data })))
      .catch(error => console.log('network error message: ', error))
  }

  getUniqueList = array => {
    let uniqueArray = [];

    // Loop through array values
    let c = 0;
    for (let i = 0; i < array.length; i++) {
      if (uniqueArray.indexOf(array[i]) === -1) {
        uniqueArray.push(array[i]);
      }
    }
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });

  };

  handleDate = (date) => {
    // const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        delivery_date: date
      }
    });

  }


  handleCollectionCentres = event => {
    const { name, value } = event.target;
    const { user } = this.state;
    console.log('id', value)
    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });

    fetch(`${API_URL}collection_center/in/${value}/lga`)
      .then(response => response.json())
      .then(response => (this.setState({ centers: response.data })))
      .catch(error => console.log('network error message: ', error))

  };


  handleLgaChange = (event) => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
    //filter lga through state
    const lgaFound = this.state.states.filter(selectedState => {
      if (value === selectedState.name) {
        return selectedState
      }
    })

    this.setState({ stateLg: lgaFound })
  }

  handleDateChange = (event) => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        delivery_date: value
      }
    });

  }

  handleSubmit = event => {
    this.setState({
      isSubmitted: true
    });

    let current_datetime = new Date()
    const todays_date = `${current_datetime.getFullYear()}-0${(current_datetime.getMonth() + 1)}-${current_datetime.getDate()}`
    console.log('datess', todays_date, this.state.user.delivery_date)

    event.preventDefault();

    let address = this.state.user.address;
    let delivery_method = this.state.user.delivery_method;
    let delivery_date = this.state.user.delivery_date;
    let delivery_time = this.state.user.delivery_time;
    let delivery_state = this.state.user.delivery_state;
    let lga = this.state.user.lga;
    console.log('addfrss', address)
    const user = {
      address,
      delivery_date,
      delivery_time,
      delivery_method,
      delivery_state,
      lga
    };

    this.props.addAddress(user);
    console.log('addfrss', user)

    this.setState = ({
      user: {
        address: '',
        // delivery_date: '',
        delivery_time: '',
        delivery_method: '',
        delivery_state: '',
        lga: ''
      }
    });

    if (this.state.user.delivery_method === '1') {
      if (this.state.user.delivery_state === '' && this.state.user.lga === '' && this.state.user.address === '' && this.state.user.delivery_date === '' && this.state.user.delivery_time === '') {
        this.setState({
          buttonDisabled: true
        })
      }
    }

    if (this.state.user.delivery_method === '2') {
      if (this.state.user.delivery_state == '' && this.state.user.lga == '') {
        this.setState({
          buttonDisabled: true
        })
      }
    }

    this.props.history.push('/order/payment')


  };

  clearDateField = () => {
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        delivery_date: ''
      }
    });
  }

  render() {
    const myState = []
    const newState = this.state.states.map(row => {
      myState.push(row.name)
    })
    const distinct = (value, index, self) => { return self.indexOf(value) === index }
    const allState = myState.filter(distinct)
    let count = 1;

    return (
      <Container className="main-container">
        <Row>
          <Col md={8}>
            <div className="checkout">
              <Row className="auth-links-card" id="checkout-row">
                <div
                  class="nav col-md-12 auth-card-nav"
                  id="myTab"
                  role="tablist"
                >
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <p className="order-line my-auto">
                      Order Summary
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <p className="order-line my-auto" >
                      Address
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 disabled-nav">
                    <p className="order-line my-auto">
                      Payment
                    </p>
                  </div>
                </div>
              </Row>

              <ProgressBar now={50} />
              <form method="post">
                <div className="information-holder">
                  <Card style={{ width: "100%" }}>
                    <Card.Header>Delivery Method</Card.Header>

                    <Card.Body>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="delivery_method"
                          id="delivery_method"
                          value='1'
                          onChange={this.handleChange}
                          required
                        />
                        <p className="address-form-check">
                          At-home service <br />A member of our health squad will
                          come to you on{" "}
                          <span>Thursday 14th April between 8am to 11am</span>
                        </p>
                      </div>

                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="delivery_method"
                          id="delivery_method"
                          value='2'
                          onChange={this.handleChange}
                          required
                        />
                        <p className="address-form-check">
                          Collection center <br />
                          Visit one of our collection center to give your sample{" "}
                          <span>on Thursday 14th April</span>{" "}
                        </p>
                      </div>
                    </Card.Body>
                  </Card>

                  {
                    this.state.user.delivery_method === '1' ?
                      (<Card style={{ width: "100%" }}>
                        <Card.Header>Delivery Details</Card.Header>

                        <Card.Body>
                          <Row className="mb-3">
                            <Col md={6}>
                              <Card.Title>State</Card.Title>
                              <Form.Control as="select" name="delivery_state" value={this.state.user.delivery_state} onChange={this.handleLgaChange} required>
                                <option value="">Select State</option>
                                {
                                  allState.map(item => {
                                    return <option value={item}>{item}</option>
                                  })
                                }
                              </Form.Control>
                            </Col>

                            <Col md={6}>
                              <Card.Title>LGA</Card.Title>
                              <Form.Control as="select" name="lga" onChange={this.handleChange} value={this.state.user.lga} required>
                                <option value="">Select LGA</option>
                                {
                                  this.state.stateLg.map(state => {

                                    return <option id={state.id}>{state.lga}</option>
                                  })
                                }
                              </Form.Control>
                            </Col>
                          </Row>


                          <Row className="mb-3">
                            <Col md={12}>
                              <Card.Title>Address</Card.Title>
                              <Form.Control
                                type="text"
                                placeholder="Enter delivery address"
                                name="address"
                                defaultValue={this.state.user.address}
                                onChange={this.handleChange}
                                required />
                            </Col>
                          </Row>

                          <Row>
                            <Col md={6}>
                              <Card.Title>Delivery Date</Card.Title>
                              {/* <input
                            type="date"
                            placeholder="19 - 04 - 2020"
                            name="delivery_date"
                            value={this.state.user.delivery_date}
                            onChange={this.handleChange}
                            required
                          /> */}
                              <DatePicker
                                selected={this.state.user.delivery_date}
                                onChange={date => this.handleDate(date)}
                                excludeDates={[new Date()]}
                                minDate={new Date() - 6}
                                maxDate={addDays(new Date(), 20)}
                                placeholderText="Select date"
                              />

                            </Col>

                            <Col md={6}>
                              <Card.Title>Delivery Time</Card.Title>
                              <Form.Control as="select" name="delivery_time" value={this.state.user.delivery_time} onChange={this.handleChange} required>
                                <option value="">Select Delivery Time</option>
                                <option>9A.M - 10A.M</option>
                                <option>10A.M - 11A.M</option>
                                <option>11A.M - 12P.M</option>
                                <option>12P.M - 1P.M</option>
                                <option>1P.M - 2P.M</option>
                              </Form.Control>
                            </Col>
                          </Row>
                        </Card.Body>
                      </Card>
                      )
                      : null
                  }

                  {
                    this.state.user.delivery_method === '2' ?
                      (
                        <Card style={{ width: "100%" }}>
                          <Card.Header>Delivery Details</Card.Header>

                          <Card.Body>

                            <Row className="mb-3">
                              <Col md={6}>
                                <Card.Title>State</Card.Title>
                                <Form.Control as="select" name="delivery_state" value={this.state.user.delivery_state} onChange={this.handleLgaChange} required>
                                  <option value="">Select State</option>
                                  {
                                    allState.map(item => {
                                      return <option value={item}>{item}</option>
                                    })
                                  }
                                </Form.Control>
                              </Col>

                              <Col md={6}>
                                <Card.Title>LGA</Card.Title>
                                <Form.Control as="select" name="lga" onChange={this.handleCollectionCentres} value={this.state.user.lga} required>
                                  <option value="">Select LGA</option>
                                  {
                                    this.state.stateLg.map(state => {

                                      return <option value={state.id}>{state.lga}</option>
                                    })
                                  }
                                </Form.Control>
                              </Col>
                            </Row>

                            <hr className="divider" />

                            <Row>
                              <Col md={12}>
                                <h6 className="modal-title-inner">Collection Centers near you</h6>
                              </Col>
                              {this.state.centers.length !== 0 ?
                                this.state.centers.map(row => {
                                  return (
                                    <Col md={12}>

                                      <Row>
                                        <Col md={1}>
                                          <div class="form-check">
                                            <input className="form-check-input" onChange={this.handleChange} type="radio" name="address" id="exampleRadios1" value={`${row.name} , ${row.address}`} />
                                          </div>
                                        </Col>
                                        <Col md={6} className="location-modal-container">
                                          <p className="location-modal-header">{row.name}</p>
                                          <p className="location-modal-p1">Address</p>
                                          <p className="location-modal-p2">{row.address}</p>
                                        </Col>
                                        <Col md={5} className="location-modal-container">
                                          <p className="location-modal-p1">Opening Hours</p>

                                          <p className="location-modal-p2 location-opening">Monday - Friday</p>
                                          <span className="pull-right float-none-on-mobile">{row.opening_hours}</span>
                                          {/* <p className="location-modal-p2 location-opening">Saturday - Sunday <span className="pull-right">11am - 12pm</span></p>  */}
                                        </Col>
                                      </Row>
                                    </Col>
                                  )
                                })


                                : 'We dont have collection centers in your area. Please check back'
                              }
                            </Row>
                          </Card.Body>
                        </Card>
                      ) : null
                  }

                  <Row className="">
                    <Col md={6}>
                      <div className="btn-holder">
                        <Link className="btn btn-primary order-previous" to="/checkout">
                          Previous
                          </Link>
                      </div>
                    </Col>
                    <Col md={6}>
                      <div className="btn-holder pull-right">
                        {
                          this.state.user.delivery_method === '' ?
                            <Button className="btn btn-primary pull-right order-next text-center" disabled>
                              Next
                            </Button>
                            :
                            <button className="btn btn-primary pull-right order-next text-center" type="submit" buttonDisabled={this.state.buttonDisabled} onClick={this.handleSubmit}>
                              Next
                            </button>
                        }
                      </div>
                    </Col>
                  </Row>

                </div>
              </form>
            </div>
          </Col>

          <Col md={4}>
            <RigthBar />
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    addAddress: (user) => { dispatch(addAddress(user)) }
  }
}

export default connect(null, mapDispatchToProps)(Address);

