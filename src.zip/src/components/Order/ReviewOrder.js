import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  ProgressBar,
  Modal,
  Table,
  Button,
} from "react-bootstrap";
import Cookies from "universal-cookie";
import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import InfoIcon from "./../../assets/images/information_icon.svg";
import { RaveProvider, RavePaymentButton } from "react-ravepayment";
import { connect } from "react-redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import LoadingOverlay from "react-loading-overlay";
import {
  createOrder,
  updatePayload,
  validateCoupon,
} from "./../../actions/order";
import history from "./../../history";

class ReviewOrder extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  state = {
    centers: [],
    orders: [],
    loading: false,
    price: 0,
    coupon: null,
    collection_center: null,
    showModal: false,
    submittedCoupon: false,
    showOverlay: false,
    processingState: "",
  };

  handleClose = () => this.setState({ showModal: false, loading: false });
  handleShow = () => this.setState({ showModal: true });

  payWithRave = {
    txref: "rave-123456",
    PBFPubKey: "FLWPUBK-3b9784a1175e2a289612149d9e483fa3-X",
    production: false,
    onSuccess: (response) => {
      if (response && response.tx && response.tx.status === "successful") {
        const transactionDetails = {
          amount: response.tx.charged_amount,
          merchant_tx_id: response.tx.flwRef,
        };
        this.makePayment(transactionDetails);
        window.location.href = "/order/payment/success";
      }
    },
    onError: () => {
      window.location.href = "/order/payment/failure";
    },
    onClose: () => {
      window.location.href = "/order/payment/success";
    },
  };

  payWithCoupon = () => {
    const { orders, price, coupon } = this.state;
    this.setState({
      showModal: false,
      loading: true,
      submittedCoupon: true,
      showOverlay: true,
      purpose: null,
      processingState: "Validating coupon code ...",
    });
    // Validate coupon

    const details = {
      coupon_code: coupon.coupon_code,
      count: Number(orders.length),
    };

    if (details.coupon_code) {
      this.promise = this.props.validateCoupon(details);
      this.promise
        .catch(() => {})
        .then(() => {
          const { coupon } = this.props.order;
          this.setState({ loading: false });

          if (!coupon.success) {
            this.setState({
              loading: false,
              submittedCoupon: false,
              showOverlay: false,
              processingState: "",
            });
            return false;
          }
          this.setState({
            processingState: "Please wait while we process your order ...",
          });
          console.log(coupon);
          const transactionDetails = {
            amount: price * Number(orders.length),
            merchant_tx_id: details.coupon_code,
          };
          this.makePayment(transactionDetails);
        });
    }
  };

  handleCoupon = (event) => {
    const { name, value } = event.target;
    const { coupon } = this.state;

    this.setState({
      coupon: {
        ...coupon,
        [name]: value,
      },
    });
  };

  // componentDidCatch(error, errorInfo) {
  //   DebugSentry.catchException(error, errorInfo);
  // }

  componentDidMount() {
    this.handleUpdatePayload();
    const orders = JSON.parse(localStorage.getItem("order"));
    const centers = JSON.parse(localStorage.getItem("centers"));
    const collection_center = localStorage.getItem("collection_center");
    const payload = JSON.parse(localStorage.getItem("payload"));
    const response = JSON.parse(localStorage.getItem("response"));

    let price = null;

    if (payload) {
      if (payload.purpose === "Travel") {
        const { airport } = payload.returnee;
        if (airport == 1) {
          price = 42750;
        }
        if (airport == 2) {
          price = 50400;
        }
      } else {
        if (response) {
          if (response.state === "FCT") {
            price = 42750;
          }
          if (response.state === "Lagos") {
            price = 50400;
          }
        }
      }
    }

    this.setState({
      centers,
      orders,
      collection_center,
      price,
      purpose: payload.purpose,
    });
  }

  handleUpdatePayload = () => {
    let { response } = this.props.order;
    let payload = JSON.parse(localStorage.getItem("payload"));
    response = {
      ...response,
      payload,
    };
    this.promise = this.props.updatePayload(response);
  };

  makePayment = (transactionDetails) => {
    const { orders } = this.state;
    const user = JSON.parse(localStorage.getItem("user"));
    const response = JSON.parse(localStorage.getItem("response"));
    const { collection_center } = this.state;

    const payload = {
      purpose: response.purpose,
      email: user.email,
      collection_center_id: collection_center,
      test_id: "6c34721e-528a-46a4-b549-e80a6d60e86d",
      total_amount: transactionDetails.amount,
      amount: transactionDetails.amount,
      qty: orders.length,
      state: localStorage.getItem("selectedAiportState"),
      orders,
      returnee: response.returnee,
      transaction: {
        type: response.purpose,
        status: true,
        merchant_tx_id: transactionDetails.merchant_tx_id,
      },
    };

    console.log(payload);

    this.promise = this.props.createOrder(payload);
    this.promise
      .catch(() => {})
      .then(() => {
        this.setState({ loading: false });
        history.push("/order/payment/success");
      });
  };

  handleRemove = (event, dependent_id) => {
    event.preventDefault();
    const { orders } = this.state;
    let filteredOrders = orders.filter(
      (order) => order.dependent_id !== dependent_id
    );
    this.setState({
      orders: filteredOrders,
    });
  };

  bootstrapConfig = (amount) => {
    const user = JSON.parse(localStorage.getItem("user"));
    this.payWithRave.customer_email = user.email;
    this.payWithRave.customer_phone = user.phone;
    this.payWithRave.amount = amount;
  };

  render() {
    const {
      orders,
      centers,
      collection_center,
      loading,
      price,
      showModal,
      submittedCoupon,
      coupon,
      showOverlay,
      processingState,
      purpose,
    } = this.state;
    const selectedCollectionCenter = centers.filter(
      (center) => center.id == collection_center
    );
    const amount = price * Number(orders.length);
    this.bootstrapConfig(amount);
    console.log(purpose);
    return (
      <>
        {showOverlay && (
          <LoadingOverlay
            active="true"
            spinner
            text={processingState}
          ></LoadingOverlay>
        )}

        <Container className="main-container">
          <Row>
            <Col md={10} className="mx-auto">
              <Card.Header className="card-header">
                Your COVID-19 Order
              </Card.Header>

              <Card className="card-shadow" style={{ width: "100%" }}>
                <Link to="/order/details" className="return-anchor">
                  <i
                    className="fa fa-arrow-left"
                    style={{ marginRight: "5px" }}
                  />{" "}
                  Back to Order details{" "}
                </Link>
                <Card.Body>
                  <Card
                    className="card-shadow-inside"
                    style={{ width: "100%" }}
                  >
                    <p className="header-description">Order Details </p>

                    <Table
                      responsive
                      borderless
                      hover
                      className="fixed-height-on-mobile"
                      borderless
                    >
                      <thead>
                        <th
                          colspan="1"
                          style={{ whiteSpace: "nowrap" }}
                          id="th-id"
                        >
                          #
                        </th>
                        <th
                          colspan="1"
                          style={{ whiteSpace: "nowrap" }}
                          id="th-test"
                        >
                          Test
                        </th>
                        {/* <th
                        colspan="1"
                        style={{ whiteSpace: "nowrap" }}
                        id="th-center"
                      >
                        Collection Center
                      </th> */}
                        <th
                          colspan="1"
                          style={{ whiteSpace: "nowrap" }}
                          id="th-for"
                        >
                          Ordered For
                        </th>
                        <th
                          colspan="1"
                          style={{ whiteSpace: "nowrap" }}
                          id="th-price"
                        >
                          Price (NGN)
                        </th>
                        <th
                          colspan="1"
                          style={{ whiteSpace: "nowrap" }}
                          id="th-price"
                        ></th>
                      </thead>
                      <tbody className="cart responsive_row">
                        {orders &&
                          orders.map((order, i) => {
                            return (
                              <tr>
                                <td>{i + 1}</td>
                                <td className="width-table-test">
                                  PCR for SARS-COV-2
                                </td>
                                {/* <td className="width-table-test">
                                {selectedCollectionCenter[0].name}
                              </td> */}
                                <td className="width-table-test">
                                  {order.name}
                                </td>
                                <td className="width-table-test">
                                  {Number(price.toFixed(1)).toLocaleString()}
                                </td>
                                <td className="width-table-test">
                                  <i
                                    class="fa fa-trash"
                                    aria-hidden="true"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    onClick={(event) =>
                                      this.handleRemove(
                                        event,
                                        order.dependent_id
                                      )
                                    }
                                    title={`Remove ${order.name} from this order`}
                                  ></i>
                                </td>
                              </tr>
                            );
                          })}
                        <tr>
                          <td className="width-table-test"></td>
                          <td></td>
                          <td>
                            <b>Total:</b>
                          </td>
                          <td className="width-table-price">
                            <b>{Number(amount.toFixed(1)).toLocaleString()}</b>
                          </td>
                          <td></td>
                        </tr>
                      </tbody>
                    </Table>

                    <div md={8} className="mt-2">
                      <Card.Body>
                        <div className="information_box">
                          <Row>
                            <Col md={2}>
                              <img
                                src={InfoIcon}
                                className="img-responsive info_icon"
                                alt="Sucess"
                              />
                            </Col>
                            <Col md={10} className="my-auto">
                              <p className="my-0">
                                You are required to complete your{" "}
                                <u>case information form</u> and{" "}
                                <u>select your appointment date and time</u>{" "}
                              </p>
                            </Col>
                          </Row>
                        </div>
                      </Card.Body>
                    </div>
                  </Card>

                  <div md={12} className="mt-5" style={{ display: "flex" }}>
                    {purpose && purpose === "Personal" && (
                      <RaveProvider {...this.payWithRave}>
                        <RavePaymentButton
                          className="btn btn-primary order-next"
                          style={{ marginLeft: "auto" }}
                        >
                          Proceed to payment
                        </RavePaymentButton>
                      </RaveProvider>
                    )}
                    {purpose && purpose === "Travel" && (
                      <button
                        onClick={this.handleShow}
                        type="submit"
                        style={{ marginLeft: "auto" }}
                        className="btn btn-primary order-next"
                      >
                        Proceed
                      </button>
                    )}
                  </div>
                </Card.Body>
              </Card>
            </Col>
            <Modal
              show={showModal}
              onHide={this.handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title>
                  <Container>
                    <Row>
                      <h6></h6>
                    </Row>
                  </Container>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Container>
                  <Row>
                    <Col md={12}>
                      <Card.Title className="input-label">
                        Enter your Coupon Code
                      </Card.Title>
                      <Form.Control
                        type="text"
                        name="coupon_code"
                        placeholder=""
                        onChange={this.handleCoupon}
                        className={
                          "form-group" +
                          (submittedCoupon && !coupon.coupon_code
                            ? " has-bug"
                            : "")
                        }
                      />
                      {submittedCoupon && !coupon.coupon_code && (
                        <div className="help-block">
                          You must provide a coupon code to continue
                        </div>
                      )}
                    </Col>
                  </Row>
                </Container>
              </Modal.Body>
              <Modal.Footer>
                <Row>
                  <Col md={3}></Col>
                  <Col
                    md={4}
                    className="mt-5"
                    style={{ marginTop: "5px !important" }}
                  >
                    <button
                      onClick={this.handleClose}
                      type="submit"
                      style={{ marginLeft: "auto" }}
                      className="btn btn-default order-next btn-block"
                    >
                      Close
                    </button>
                  </Col>
                  <Col
                    md={5}
                    className="mt-5"
                    style={{ marginTop: "5px !important" }}
                  >
                    <button
                      onClick={this.payWithCoupon}
                      type="submit"
                      style={{ marginRight: "0rem" }}
                      className="btn homepage-text-primary-button"
                      disabled={loading}
                    >
                      {loading && (
                        <i
                          className="fa fa-refresh fa-spin"
                          style={{ marginRight: "5px" }}
                        />
                      )}
                      {loading && <span>Processing...</span>}
                      {!loading && <span>Proceed</span>}
                    </button>
                  </Col>
                </Row>
              </Modal.Footer>
            </Modal>
          </Row>
          <ToastContainer autoClose={2000} />
        </Container>
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {
  createOrder,
  updatePayload,
  validateCoupon,
})(ReviewOrder);
