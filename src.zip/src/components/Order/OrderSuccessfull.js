import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { connect } from "react-redux";
import { PropTypes } from "prop-types";
import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";
import { Container, Row, Col, ProgressBar } from "react-bootstrap";

import RigthBar from "./RightBar";

import "./../../css/Checkout.css";
import DebugSentry from "../../apis/DebugSentry";

class Summary extends Component {
  state = {
    discount: 0
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    console.log(this.props.location.state);
    localStorage.removeItem('checkout')
    this.setState({ allCart: this.props.location.state });
  }

  render() {
    let sumPrice = 0;
    const { cart, isCart } = this.props;

    return (
      <Container className="main-container">
        <Row>
          <Col md={8}>
            <div className="checkout-holder-main">
              <Row className="auth-links-card" id="checkout-row">
                <div
                  class="nav col-md-12 auth-card-nav"
                  id="myTab"
                  role="tablist"
                >
                  <div class="text-center col-xs-4 col-md-4 register-nav2">
                    <p className="order-line">
                      Order Summary
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 login-nav2">
                    <p className="order-line" >
                      Address
                    </p>
                  </div>
                  <div class="text-center col-xs-4 col-md-4 login-nav2">
                    <p className="order-line">
                      Payment
                    </p>
                  </div>
                </div>
              </Row>

              <ProgressBar now={15} />

              <div className="order-summary-inner">
                <div className="order-summary-inner-main">
                  <Row className="order-header">
                    <Col md={6}>
                      <h6 className="order-summary-header">Test</h6>
                    </Col>
                    <Col md={3} className="text-right">
                      <h6 className="order-summary-header pull-right">
                        Quantity
                      </h6>
                    </Col>
                    <Col md={3} className="text-right">
                      <h6 className="order-summary-header pull-right">Price</h6>
                    </Col>
                  </Row>

                  {isCart
                    ? cart.map(item => {
                        sumPrice += parseInt(item.price);
                        return (
                          <>
                            <Row className="grey-border">
                              <Col md={6}>
                                <p className="order-summary-text">
                                  {item.test}
                                </p>
                              </Col>
                              <Col md={3} className="text-right">
                                <p className="order-summary-text">1</p>
                              </Col>
                              <Col md={3} className="text-right">
                                <p className="order-summary-text">
                                  ₦
                                  {parseInt(item.price).toLocaleString("us", {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                  })}
                                </p>
                              </Col>
                            </Row>
                          </>
                        );
                      })
                    : "No test in cart"}

                  <Row className="mt-5">
                    <Col md={6}></Col>
                    <Col md={3} className="text-right">
                      <p className="order-summary-text" style={{ marginTop:'-15px', fontWeight:'bold'}}>Sub-total amount:</p>
                    </Col>
                    <Col md={3} className="text-right">
                      <p className="order-discount">
                        ₦
                        {parseInt(sumPrice).toLocaleString("us", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })}
                      </p>
                    </Col>
                  </Row>

                  <Row className="">
                    <Col md={6}>
                      <div className="btn-holder">
                          <Link className="btn btn-primary order-previous" to="/buytests">
                            Previous
                          </Link>
                      </div>
                    </Col>
                    <Col md={6}>
                      <div className="btn-holder pull-right">
                          <Link className="btn btn-primary pull-right order-next" to="/order/address">
                            Next
                          </Link>
                      </div>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </Col>

          <Col md={4}>
            <RigthBar state={this.props.cart} />
          </Col>
        </Row>
        <ToastContainer autoClose={10000} />
      </Container>
    );
  }
}

Summary.propTypes = {
  allCart: PropTypes.array
};

const mapStateToProps = state => {
  return {
    isCart: state.cart.isCart,
    cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(Summary);
