import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Form,
  ProgressBar,
  Button,
} from "react-bootstrap";
import RigthBar from "./RightBar";
import "./../../css/Checkout.css";
import "./../../css/Travel.css";
import DebugSentry from "../../apis/DebugSentry";
import { CardBody } from "react-bootstrap/Card";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { connect } from "react-redux";
import history from './../../history';

class CIF extends Component {
  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount(){
    const cif_user = this.props.order.order_user;
    if(cif_user === undefined){
        history.push('/');
    }
  }

  onChangeValue(event) {
    console.log(event.target.value);
  }

  render() {
    const cif_user = this.props.order.order_user;
    return (
      <Container className="main-container">
        <Row>
          {/* <Col md={12} className="">
            <Card style={{ margin: "10px" }}>
              <Card.Body>
                <p>Pending Case Information Forms</p>

                <Row className="mx-auto">
                  <Col md={4}>
                    <Button
                      style={{
                        backgroundColor: "#BBBBBB",
                        border: "0px",
                        borderRadius: "5px",
                      }}
                      className="btn btn-lg btn-outline-default"
                    >
                      John Smith
                    </Button>
                  </Col>

                  <Col md={4}>
                    <Button
                      style={{
                        backgroundColor: "#BBBBBB",
                        border: "0px",
                        borderRadius: "5px",
                      }}
                      className="btn btn-lg btn-outline-default"
                    >
                      John Smith
                    </Button>
                  </Col>

                  <Col md={4}>
                    <Button
                      style={{
                        backgroundColor: "#BBBBBB",
                        border: "0px",
                        borderRadius: "5px",
                      }}
                      className="btn btn-lg btn-outline-default"
                    >
                      John Smith
                    </Button>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col> */}

          <Col md={12} className="">
            <Card style={{ margin: "10px" }}>
              <Card.Body>
                <p className="header-description">
                  Case Information Form [{cif_user && cif_user.data.name}]
                </p>

                <p>
                  Filling the CIF may look like a long task, do not worry, we
                  will be with you all the way.
                </p>

                <Row md={12}>
                  <Col style={{ lineHeight: "100px" }}>
                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>{" "}
                      Point of entry{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>

                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>
                      Case Investigation{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>

                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>
                      Travel Investigation{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>

                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>
                      Symptoms and Signs{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>

                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>
                      Pregnancy status{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>

                    <p>
                      {" "}
                      <i
                        style={{ marginRight: "50px" }}
                        class="far fa-check-circle"
                      ></i>
                      Confirmation{" "}
                      <span style={{ marginLeft: "100px" }}>
                        - 5 mins estimated time
                      </span>
                    </p>
                  </Col>
                </Row>
              </Card.Body>
            </Card>

            <Col md={12} style={{ display: "flex" }}>
              <button type="submit" style={{ marginRight: 'auto' }}  className="btn btn-primary order-next" disabled>
                Previous
              </button>

              <Link to="/order/CIF1">
                <button
                  type="button"
                  style={{ marginRight: "auto" }}
                  className="btn btn-primary order-next"
                >
                  Next
                </button>
              </Link>
            </Col>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    order: state.order,
  };
};

export default connect(mapStateToProps, {})(CIF);
