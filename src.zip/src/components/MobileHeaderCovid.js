import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import MenuLinks from './MenuLinks'
import Logo from '../assets/images/diagnoseme_logo.svg'
import '../css/MobileHeader.css';
// import Cart from './Cart'
import { Container } from 'react-bootstrap';
import DebugSentry from '../apis/DebugSentry';

class MobileHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false
    }
    this._menuToggle = this._menuToggle.bind(this);
    this._handleDocumentClick = this._handleDocumentClick.bind(this);
    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }
  
  componentDidMount() {
    document.addEventListener('click', this._handleDocumentClick, false);
  }
  componentWillUnmount() {
    document.removeEventListener('click', this._handleDocumentClick, false);
  }
  _handleDocumentClick(e) {
    if (!this.refs.root.contains(e.target) && this.state.isOpen === true) {
      this.setState({
        isOpen: false
      });
    };
  }
  _menuToggle(e) {
    e.stopPropagation();
    this.setState({
      isOpen: !this.state.isOpen
    });
  }

  state = {
    show: false
  }
  logout = () => {
    localStorage.removeItem('user')
    window.location.href = "/"
  }

  render() {
    let menuStatus = this.state.isOpen ? 'isopen' : '';
    const user = localStorage.getItem('user');


    return (

      <div ref="root" className="mobile-bg-dark-blue">

        <Container className="menubar">
          <div className="hambclicker" onClick={this._menuToggle}></div>
          <div id="hambmenu" className={menuStatus}><span></span><span></span><span></span><span></span>
          </div>
          <div className="title">
            <span>{this.props.title}</span>
          </div>
          <div className="mx-auto my-auto"><Link to="/"><img src={Logo} className="header-logo" alt="" /></Link></div>
          {/* <div className="menu-item-desktop my-auto"><Link to="/cart" className="menu-item-desktop">Cart <Badge variant="light">{this.props.cart.length}</Badge></Link></div> */}
          {
            user == null ? <>
              <div className="my-auto menu-item-desktop"><Link to="/auth/login" className="menu-item-desktop">Login</Link></div>
              {/* <div className="menu-item-desktop" onClick={() => this.setState({ show: !this.state.show })} style={{ cursor: 'pointer' }}>Cart <Badge variant="light">{this.props.cart.length}</Badge></div> */}
              {/* <div className="menu-item-desktop"><Link to="/auth/signup" className="menu-item-desktop">Sign up</Link></div> */}
            </> : <>
                <div className="my-auto menu-item-desktop"></div>
                <div className="dropdown-toggle my-auto" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span style={{ cursor: 'pointer' }} className="menu-item-desktop">{JSON.parse(user).first_name}</span>
                  <svg class="mr-0 ml-2"xmlns="http://www.w3.org/2000/svg" width="10.92" height="6.42" viewBox="0 0 16.026 9.425">
                    <path id="Path_73" data-name="Path 73" d="M10.378,14.815a1.362,1.362,0,0,0,0,1.92l6.729,6.708a1.356,1.356,0,0,0,1.87.042l6.63-6.609a1.355,1.355,0,1,0-1.912-1.92L18,20.566l-5.7-5.759A1.356,1.356,0,0,0,10.378,14.815Z" transform="translate(-9.983 -14.413)" fill="#fff" />
                  </svg>
                </div>
                <div class="dropdown-menu login-dropdown" aria-labelledby="dropdownMenuLink">
                  <Link to="/account/dashboard"><p class="dropdown-item" style={{ cursor: 'pointer' }}>Dashboard</p></Link>
                  <p class="dropdown-item" style={{ cursor: 'pointer' }} onClick={this.logout}>Logout</p>
                </div>
              </>
          }
        </Container>
        <MenuLinks menuStatus={menuStatus} />
      </div>
    )
  }
}


const mapStateToProps = state => {
  return {
    cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(MobileHeader);
