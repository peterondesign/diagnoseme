import React from "react";
import {withRouter} from 'react-router-dom'
import { Container, Row, Col, Card } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";
import "./../../css/Dashboard.css";
import bgelementsHomepage from "./../../assets/images/bgelementsHomepage.svg";
import emptybox from "./../../assets/images/empty-box.svg";
import Cookies from "universal-cookie";
import { API_URL } from "../../apis/diagnosemeApi";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import { BallPulseSync } from "react-pure-loaders";
import Modal from "react-bootstrap/Modal";
import Table from "react-bootstrap/Table";
import * as moment from "moment";
import DebugSentry from "../../apis/DebugSentry";
import history from './../../history';
import { connect } from "react-redux";
import BookingCalendar from "../../Calendar";

import { findPassport } from "../../actions/booking";
import { getOrderUserDetails } from "../../actions/order";


const cookies = new Cookies();

class Dashboard extends React.Component {
  state = {
    reports: [],
    isProcessing: true,
    netError: false,
    emptyOrder: false,
    show: false,
    order: [],
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleLoadCIF = (order_id) => {
    this.promise = this.props.getOrderUserDetails(order_id)
    this.promise.catch(() => {}).then(() => {  
      history.push('/order/CIF');
   });
    
  }

  componentDidMount() {
    const token = cookies.get("authorization");
    if (localStorage.getItem("user") != null) {
      const user = localStorage.getItem("user");
      const userid = JSON.parse(user).id;

      fetch(`${API_URL}consumer/user/dashboard/`, {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      })
        .then((response) => response.json())
        .then((result) => this.getReports(result))
        .catch((error) => this.setState({ netError: true }));
    }
  }

  getReports = (result) => {
    console.log('result',result)
    if (result.data.orders.length > 0) {
      this.setState({ isProcessing: false });
    } else {
      this.setState({ isProcessing: false, emptyOrder: true });
    }
    this.setState({ reports: result.data.orders });
  };

  openModal = (orderId) => {
    const getOrder = Object.values(this.state.reports).filter((order) => {
      if (orderId == order.receipt_id) {
        return order;
      }
    });
    this.setState({ show: true, order: getOrder });
  };

  ViewAllOrders() {
    window.location.href = "/account/reports";
  }

  handleBooking = (orderid,response) => {
    alert(orderid)
    let booking = {
      booking_type: 2,
      order_id: orderid,
      passport_number: null
    };

    localStorage.setItem('booking', JSON.stringify(booking));
     this.promise =  this.props.findPassport(booking);
     this.promise
          .catch(() => {})
          .then(() => {
            if(response &&
              (response.response === null ||
                response.response.data === "Resource not found") ) {
                  // alert("Order ID not found")
                } else if(response &&
                  response.response !== null &&
                    response.response.message ===
                      "Appointment already booked") {
                        // alert("Appointment already booked")
                      }
                      else {
                      this.props.history.push('/booking/calendar');
                      }
          });
    
  }

  render() {
    console.log(this.state.reports);
    const response = this.props.center
    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsHomepage" alt=""></img>
          <Container>
            <div className="dashboard-block">
              <Row className="sidebar-row">
                <Col md={2} className="sidebar-dashboard">
                  <div className="left-pane">
                    <Sidebar />
                  </div>
                </Col>
                <Col md={10} className="right-dashboard">
                  <Container className="reverse_on_mobile">
                    <Row className="row-no-margin report-header-row">
                      <Col md={10} className="col-no-padding">
                        <h5 className="dashboard-title col-no-padding">
                          Dashboard
                        </h5>
                      </Col>
                    </Row>

                    <div className="pt-1 pb-1">
                      <Row className="row-no-margin report-header-row">
                            <Col
                              md={4}
                              className="dashboard-component-border text-left"
                            >
                              <p>Tests Ordered</p>
                              <p className="test-count-dashboard ">
                                {this.state.reports.length}
                              </p>
                            </Col>

                            <Col
                              md={4}
                              className="dashboard-component-border dashboard-ad vcenter"
                            >
                              <Link to="/account/Settings">
                                <p
                                  style={{ color: "#fff", cursor: "pointer" }}
                                  className="mt-3"
                                >
                                  View Result Password
                                </p>
                              </Link>
                            </Col>

                            <Col
                              md={4}
                              className="dashboard-component-border dashboard-ad vcenter"
                              style={{ backgroundColor: "#F05F87" }}
                            >
                              <Link to="/order/purpose">
                                <p
                                  style={{ color: "#fff", cursor: "pointer" }}
                                  className="mt-3"
                                >
                                  Order COVID-19 Test
                                </p>
                              </Link>
                            </Col>
                      </Row>
                    </div>

                    <Row className="row-no-margin report-header-row">
                      <Col md={10} className="col-no-padding">
                        <h5 className="dashboard-title">Recent Orders</h5>
                      </Col>
                      <Col md={2} className="col-no-padding"></Col>
                    </Row>
                    {this.state.netError ? (
                      // alert(
                      //   "It seems you are offline. Please check your internet connection"
                      // )
                      console.log("")
                    ) : this.state.isProcessing ? (
                      <div className="text-center">
                        <BallPulseSync color={"#F05F87"} loading="true" />
                        <p className="loading-p">Loading...</p>
                      </div>
                    ) : this.state.reports.length > 0 ? (
                      Object.values(this.state.reports).slice(0, 5).map((row, i) =>
                      {
                        return (
                          <Row className="order-row-dashboard row-no-margin" key={i}>

                          <Table responsive borderless hover className="fixed-height-on-mobile">
                                        
                                <thead>

                                    <th colspan="1"  style={{whiteSpace: 'nowrap' }}>Order ID</th>
                                    <th colspan="1"  style={{whiteSpace: 'nowrap' , margin: '0px'}}>Ordered For</th>
                                    <th colspan="1" style={{whiteSpace: 'nowrap' }}>Order Date</th>
                                    <th colspan="1" style={{whiteSpace: 'nowrap' }}>Status</th>
                                    <th colspan="1" style={{whiteSpace: 'nowrap' }}>Action</th>
                                </thead>
                                <tbody className="responsive_row">
                                <tr>
                                    <td  className="width-table-test">{row.receipt_id}</td>
                                    <td  className="width-table-test">{row.ordered_for}</td>
                                    <td  className="width-table-test">{row.created_at}</td>
                                    <td  className="width-table-test">{row.order_status == null ? 'Pending' : row.order_status == 1 ? 'Sample Collected' : row.order_status == 2 ? 'In the Lab' : row.order_status == 3 ? 'Result is Ready' : 'Pending'}</td>
                                    <td >
                                    {row && row.test_id == "6c34721e-528a-46a4-b549-e80a6d60e86d" && row.covid_cif_completed == "0" && (
                                        <button class="btn btn-success cif-btn" onClick={() => this.handleLoadCIF(row.receipt_id)}
                                        style={{ fontSize: '10px' }} className="btn btn-warning btn-sm btn-round">
                                          Complete CIF
                                        </button>
                                    )}
                                    {row && row.test_id == "6c34721e-528a-46a4-b549-e80a6d60e86d" && row.covid_cif_completed == "1" && row.order_status != "3" && (
                                        <button class="btn btn-success barcode-btn"
                                        style={{ fontSize: '10px' }} className="btn btn-success btn-sm btn-round">
                                          View Barcode
                                        </button>
                                    )}
                                    {row && row.order_status == "3" && (
                                        <a className="btn btn-default report-button float-right-button" href={row.pdf_link} target="_blank">
                                          <button className="buy-test-button" style={{ width: '150px' }}>View Result</button>
                                        </a>
                                    )}
                                    </td> 
                                </tr>
                                </tbody>

                              </Table>

                            {/* <Col md={5} className="col-no-padding">
                              <p className="order-name-dashboard order-title">
                                {row.test_name}
                              </p>
                              <p className="order-label">
                                {row.is_bundle === 0 ? "Test" : "Bundle Test"}
                              </p>
                            </Col> 
                            {/* <Col md={2} className="col-no-padding">
                              <p className="order-name-dashboard order-title">
                                {row.order_status == null ? 'Pending' : row.order_status == 1 ? 'Sample Collected' : row.order_status == 2 ? 'In the Lab' : row.order_status == 3 ? 'Result is Ready' : 'Pending'}
                              </p>
                              <p className="order-label">Status</p>
                            </Col>
                            <Col md={2} className="col-no-padding">
                              <p className="order-name-dashboard order-id-dashboard order-title" onClick={() => this.openModal(row.receipt_id)} style={{ cursor: 'pointer' }}>
                                {row.receipt_id}
                              </p>
                              <p className="order-label">Order ID</p>
                            </Col>
                            <Col md={3} className="col-no-padding">
                              {
                                row.is_bundle == 1 ?
                                  <a className="btn btn-default report-button float-right-button" onClick={() => this.openModal(row.receipt_id)} style={{ cursor: 'pointer' }}>
                                    View Details
                              </a> : row.order_status == 3 ?
                                    <a className="btn btn-default report-button float-right-button" href={row.pdf_link} target="_blank"><button className="buy-test-button" style={{ width: '150px' }}>View Result</button></a> :
                                    <div className="btn btn-default report-button float-right-button">
                                      Report Pending
                                
                                      
                             </div>
                              }
                            </Col>

                             <div className="mx-auto text-center mt-3 mb-3">
                              <Button
                                onClick={this.ViewAllOrders}
                                className="d-block homepage-text-outline-button mx-auto"
                              >
                                View All Orders
                             </Button>
                            </div>   */}
                            {/* <div className="mx-auto text-center mt-3 mb-3">
                              <Button
                                onClick={this.ViewAllOrders}
                                className="d-block homepage-text-outline-button mx-auto"
                              >
                                View All Orders
                             </Button>
                            </div> */}
                            </Row>
                          );
                        })
                    ) : (
                      ""
                    )}
                    {this.state.emptyOrder ? (
                      <Row className="order-row-dashboard row-no-margin text-center">
                        <Col
                          md={12}
                          className="col-no-padding dashboard-empty-state"
                        >
                          <div className="dashboard-empty-state-item">
                            <img
                              src={emptybox}
                              alt="no-orders-yet"
                              className="emptybox"
                            ></img>
                          </div>
                          <div className="dashboard-empty-state-item">
                            <h6 className="dashboard-no-order-p">
                              You have no orders yet
                            </h6>
                          </div>
                          <div className="dashboard-empty-state-item">
                            <Link to="/" className="dashboard-buytest">
                              Buy Tests
                            </Link>
                          </div>
                        </Col>
                      </Row>
                    ) : (
                      ""
                    )}
                  </Container>
                </Col>
              </Row>
            </div>
          </Container>

          <Modal
            size="lg"
            centered
            show={this.state.show}
            onHide={() => this.setState({ show: false })}
          >
            {this.state.order.slice(0, 1).map((row, i) => {
              return (
                <Modal.Header closeButton>
                  <Modal.Title>
                    <p className="order-name-dashboard order-title">
                      {row.receipt_id}
                    </p>
                    <p className="order-label">Order ID</p>
                  </Modal.Title>
                </Modal.Header>
              );
            })}
            <Modal.Body>
              <div className="order-details-section">
                <Row className="padding-bottom-large">
                  {this.state.order.slice(0, 1).map((row, i) => {
                    return (
                      <Col md={4}>
                        <p className="order-name-dashboard order-title">
                          {row.created_at}
                          <p className="order-label">Order Date</p>
                        </p>
                      </Col>
                    );
                  })}
                </Row>
                <Row>
                  {this.state.order.slice(0, 1).map((row, i) => {
                    return (
                      <Col md={4}>
                        <p className="order-name-dashboard order-title">
                          {row.consumer_user_id}
                        </p>
                        <p className="order-label">Delivery Location</p>
                      </Col>
                    );
                  })}
                </Row>
              </div>

              <Table
                className="col-no-padding responsive_custom_table"
                borderless
              >
                <thead>
                  <th>Test</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th></th>
                </thead>
                {this.state.order.map((row, i) => {
                  return (
                    <>
                      {row.is_bundle == 0 ? (
                        <tbody className="responsive_row">
                          <tr>
                            <td data-column="Test">{row.test_name}</td>
                            <td data-column="Quantity">1</td>
                            <td data-column="Price">
                              ₦
                              {parseInt(row.price).toLocaleString("us", {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </td>
                            <td></td>
                          </tr>
                        </tbody>
                      ) : row.is_bundle == 1 ? (
                        row.bundle_tests.map((rw) => {
                          return (
                            <tbody>
                              <tr>
                                <td data-column="Price">{rw.test_name}</td>
                                <td data-column="Price">1</td>
                                <td data-column="Price">
                                  ₦
                                  {parseInt(rw.price).toLocaleString("us", {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                  })}
                                </td>
                                <td>
                                  {rw.order_status == 3 ? (
                                    <a
                                      className="btn btn-default report-button float-right-button"
                                      href={rw.pdf_link}
                                      target="_blank"
                                    >
                                      <button
                                        className="buy-test-button"
                                        style={{ width: "150px" }}
                                      >
                                        View Result
                                      </button>
                                    </a>
                                  ) : (
                                    <button className="btn btn-default report-button float-right-button">
                                      Report Pending
                                    </button>
                                  )}
                                </td>
                              </tr>
                            </tbody>
                          );
                        })
                      ) : (
                        ""
                      )}
                    </>
                  );
                })}
              </Table>
            </Modal.Body>
          </Modal>
        </div>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = state => {
  console.log('center',state)
  return { center: state.center };
};

export default connect(mapStateToProps, { findPassport, getOrderUserDetails })(withRouter(Dashboard));

