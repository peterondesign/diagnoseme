import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import "./../../css/Dashboard.css";
import bgelementsHomepage from "./../../assets/images/bgelementsHomepage.svg";
import PhoneInput from "react-phone-input-2";
import serializeForm from "form-serialize";
import Cookies from "universal-cookie";
import { API_URL } from "../../apis/diagnosemeApi";
import Sidebar from "./Sidebar";
import DebugSentry from "../../apis/DebugSentry";

const cookies = new Cookies();

class Profile extends React.Component {
  state = {
    ageCheck: {
      check: false,
      message: "",
      loading: false,
    },
    email: "",
    phone: "",
    first_name: "",
    last_name: "",
    dob: "",
    gender: "",
    address: "",
    state: "",
    isSubmitted: false,
    submitButtonDisabled: false,
    states: [],
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    const getUser = localStorage.getItem("user");
    const profile = JSON.parse(getUser);
    this.getStates();
    this.setState({
      email: profile.email,
      phone: profile.phone,
      first_name: profile.first_name,
      last_name: profile.last_name,
      dob: profile.dob,
      gender: profile.gender,
      address: profile.address,
    });
  }

  getStates = async () => {
    fetch(`${API_URL}states/all`)
      .then((response) => response.json())
      .then((response) => this.setState({ states: response.data }))
      .catch((error) => console.log("network error message: ", error));
  };

  handleChange = (event) => {
    this.setState({
      state: event.target.value,
    });
  };

  handleAgeCheck = (event) => {
    const { name, value } = event.target;

    if (value) {
      const dob = new Date(value).getFullYear();
      const year = new Date().getFullYear();
      const age = Number(year - dob);
      if (age >= 0 && age < 18) {
        this.setState({
          submitButtonDisabled: true,
          ageCheck: {
            check: false,
            message: "Your age must be greater than or equal to 18",
          },
        });
      } else if (age < 0) {
        this.setState({
          submitButtonDisabled: true,
          ageCheck: {
            check: false,
            message: `Provided Year cannot exceed ${new Date().getFullYear()}`,
          },
        });
      } else {
        this.setState({
          submitButtonDisabled: false,
          ageCheck: {
            check: true,
            message: "",
          },
        });
      }
    }
  };

  handleProfileUpdate = (e) => {
    e.preventDefault();
    this.setState({ loading: true });
    const token = cookies.get("authorization");
    const values = serializeForm(e.target, { hash: true });
    const name = `${values.first_name} ${values.last_name}`;
    values.phone = this.state.phone;
    values.name = name;
    values.state = this.state.state;

    fetch(`${API_URL}consumer/user/update`, {
      method: "POST",
      mode: "cors",
      cache: "no-cache",
      headers: {
        "Content-Type": "application/json",
        Authorization: token,
      },
      body: JSON.stringify(values),
    })
      .then((response) => response.json())
      .then((result) => this.getUpdatedProfile(result))
      .catch((error) => console.log("There was an error updating your details. Please try again"));
  };

  getUpdatedProfile = (result) => {
    localStorage.setItem("user", JSON.stringify(result.data));
    toast.success("Profile updated");
    this.setState({ loading: false });
  };

  render() {
    const getUser = localStorage.getItem("user");
    const profile = JSON.parse(getUser);
    const { ageCheck } = this.state;

    const { loading } = this.state;
    const myState = [];
    const newState = this.state.states.map((row) => {
      myState.push(row.name);
    });
    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    };
    const allState = myState.filter(distinct);

    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsHomepage" alt=""></img>
          <Container>
            <div className="dashboard-block">
              <Row className="sidebar-row">
                <Col md={2} className="sidebar-dashboard">
                  <div className="left-pane">
                    <Sidebar />
                  </div>
                </Col>
                <Col md={10} className="right-dashboard">
                  <Container>
                    <Row className="row-no-margin report-header-row">
                      <Col md={12} className="col-no-padding">
                        <h5 className="dashboard-title">Profile</h5>
                      </Col>
                    </Row>

                    <form onSubmit={this.handleProfileUpdate} className="form">
                      <Row className="order-row-dashboard row-no-margin">
                        <Col md={6}>
                          <div className="form-group">
                            <label>Email address</label>
                            <input
                              type="email"
                              name="email"
                              className="form-control"
                              onChange={(text) =>
                                this.setState({ email: text })
                              }
                              value={profile.email}
                              readOnly
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>Phone Number</label>
                            <PhoneInput
                              country="ng"
                              placeholder="Enter Phone Number"
                              enableSearch={true}
                              value={profile.phone}
                              onChange={(phone) =>
                                this.setState({ phone: phone })
                              }
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>First Name</label>
                            <input
                              type="text"
                              name="first_name"
                              className="form-control"
                              defaultValue={profile.first_name}
                              onChange={(text) =>
                                this.setState({ first_name: text })
                              }
                              required
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>Last Name</label>
                            <input
                              type="text"
                              name="last_name"
                              className="form-control"
                              defaultValue={this.state.last_name}
                              onChange={(text) =>
                                this.setState({ last_name: text })
                              }
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>Date of birth</label>
                            <input
                              type="date"
                              name="dob"
                              className="form-control"
                              defaultValue={profile.dob}
                              onChange={(text) => this.setState({ dob: text })}
                              onInput={this.handleAgeCheck}
                            />
                          </div>
                          {!ageCheck.check && (
                            <div className="help-block">{ageCheck.message}</div>
                          )}
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>Gender</label>
                            <input
                              type="text"
                              name="gender"
                              className="form-control"
                              onChange={(text) =>
                                this.setState({ gender: text })
                              }
                              value={profile.gender}
                              readOnly
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>Address</label>
                            <input
                              type="text"
                              name="address"
                              className="form-control"
                              defaultValue={profile.address}
                              onChange={(text) =>
                                this.setState({ address: text })
                              }
                            />
                          </div>
                        </Col>

                        <Col md={6}>
                          <div className="form-group">
                            <label>State of Residence</label>
                            <select
                              name="state"
                              onChange={this.handleChange}
                              className="form-control"
                            >
                              <option value={profile.state}>
                                {profile.state}
                              </option>
                              {allState.map((item) => {
                                return <option value={item}>{item}</option>;
                              })}
                            </select>
                          </div>
                        </Col>

                        <Col md={12} className="text-center">
                          <button
                            onClick={this.handleRegistration}
                            type="submit"
                            className="btn auth-button"
                            disabled={this.state.submitButtonDisabled}
                          >
                            {loading && (
                              <i
                                className="fa fa-refresh fa-spin"
                                style={{ marginRight: "5px" }}
                              />
                            )}
                            {loading && <span>Processing</span>}
                            {!loading && <span> Update Profile</span>}
                          </button>
                        </Col>
                      </Row>
                    </form>
                  </Container>
                </Col>
              </Row>
            </div>
          </Container>
          <ToastContainer autoClose={3000} />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return { user: state.user };
};

export default connect(mapStateToProps)(Profile);
