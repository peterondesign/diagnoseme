import React from "react";
import { Container, Row, Col, ThemeProvider, ToastHeader } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";
import "./../../css/Dashboard.css";
import bgelementsHomepage from "./../../assets/images/bgelementsHomepage.svg";
import emptybox from "./../../assets/images/empty-box.svg";
import Cookies from "universal-cookie";
import { API_URL } from "../../apis/diagnosemeApi";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import { BallPulseSync } from "react-pure-loaders";
import Modal from "react-bootstrap/Modal";
import Table from 'react-bootstrap/Table';
import DebugSentry from "../../apis/DebugSentry";


const cookies = new Cookies();

class Reports extends React.Component {
  state = {
    reports: [],
    isProcessing: true,
    netError: false,
    emptyOrder: false,
    show:false,
    order:[]
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }
  
  componentDidMount() {
    const token = cookies.get("authorization");
    if (localStorage.getItem("user") != null) {
      const user = localStorage.getItem("user");
      const userid = JSON.parse(user).id;

      fetch(`${API_URL}consumer/user/dashboard/`, {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        headers: {
          "Content-Type": "application/json",
          Authorization: token
        }
      })
        .then(response => response.json())
        .then(result => this.getReports(result))
        .catch(error => this.setState({ netError: true }));
    }
  }

  getReports = result => {
    if (result.data.orders.length > 0) {
      this.setState({ isProcessing: false });
    } else {
      this.setState({ isProcessing: false, emptyOrder: true });
    }
    this.setState({ reports: result.data.orders });
  };

  openModal = orderId => {
    const getOrder = Object.values(this.state.reports).filter(order => {
      if(orderId == order.receipt_id) {
        return order
      }
    })
    this.setState({show:true, order:getOrder})

    
  }

  render() {
    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsHomepage" alt=""></img>
          <Container>
            <div className="dashboard-block">
              <Row className="sidebar-row">
              <Col md={2} className="sidebar-dashboard">

                  <div className="left-pane">
                    <Sidebar />
                  </div>
                </Col>
                <Col md={10} className="right-dashboard">
                  <Container>
                    <Row className="row-no-margin report-header-row">
                      <Col md={10} className="col-no-padding">
                        <h5 className="dashboard-title">My Orders</h5>
                      </Col>
                      <Col md={2} className="col-no-padding">
                      </Col>
                    </Row>
                    { this.state.netError ? (
                      // alert(
                      //   "It seems you are offline. Please check your internet connection"
                      // )
                      console.log('')
                      
                    ) : this.state.isProcessing ? (
                      <div className="text-center">
                        <BallPulseSync color={"#F05F87"} loading="true" />
                        <p className="loading-p">Loading...</p>
                      </div>
                    ) : this.state.reports.length > 0 ? (
                      Object.values(this.state.reports).map((row,i) => {
                        return (
                          <Row className="order-row-dashboard row-no-margin" key={i}>
                            <Col md={5} className="col-no-padding">
                              <p className="order-name-dashboard order-title">
                                {row.test_name}
                              </p>
                              <p className="order-label">
                                {row.is_bundle === 0 ? "Test" : "Bundle Test"}
                              </p>
                            </Col>
                            <Col md={2} className="col-no-padding">
                              <p className="order-name-dashboard order-title">
                                {row.order_status == null ? 'Pending' : row.order_status == 1 ? 'Sample Collected' : row.order_status ==2 ? 'In the Lab' : 'Result is Ready'}
                              </p>
                              <p className="order-label">Status</p>
                            </Col>
                            <Col md={2} className="col-no-padding">
                              <p className="order-name-dashboard order-id-dashboard order-title" onClick={() => this.openModal(row.receipt_id)} style={{cursor:'pointer'}}>
                                {row.receipt_id}
                              </p>
                              <p className="order-label">Order ID</p>
                            </Col>
                            <Col md={3} className="col-no-padding">
                              {
                                row.is_bundle == 1 ? 
                                <a  className="btn btn-default report-button float-right-button" onClick={() => this.openModal(row.receipt_id)} style={{cursor:'pointer'}}>
                                View Details
                              </a>:  row.order_status == 3 ?
                                <a className="btn btn-default report-button float-right-button" href={row.pdf_link} target="_blank"><button className="buy-test-button" style={{width:'150px'}}>View Result</button></a>:
                               <div className="btn btn-default report-button float-right-button">
                               Report Pending
                             </div>
                              }
                            </Col>
                          </Row>
                        );
                        
                      })
                    ) : (
                            ""
                          )}
                    {this.state.emptyOrder ? (
                      <Row className="order-row-dashboard row-no-margin text-center">
                        <Col md={12} className="col-no-padding dashboard-empty-state">
                          <div className="dashboard-empty-state-item"><img src={emptybox} alt="no-orders-yet" className="emptybox"></img></div>
                          <div className="dashboard-empty-state-item"><h6 className="dashboard-no-order-p">
                            You have no orders yet
                          </h6></div>
                          <div className="dashboard-empty-state-item"><Link to="/buytests" className="dashboard-buytest">
                            Buy Tests
                          </Link></div>
                        </Col>
                      </Row>
                    ) : (
                        ""
                      )}
                  </Container>
                </Col>
              </Row>
            </div>
          </Container>

          <Modal size="lg"
            centered show={this.state.show} onHide={() => this.setState({show:false})}>
              { this.state.order.map((row, i) => {
                return(
                  <>
                    <Modal.Header closeButton>
              <Modal.Title>
                <p className="order-name-dashboard order-title">
                  {row.receipt_id}
                </p>
                <p className="order-label">Order ID</p>

              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="order-details-section">
                <Row className="padding-bottom-large">
                 
                  <Col md={4}>
                    <p className="order-name-dashboard order-title">
                      {row.created_at}  
                      <p className="order-label">Order Date</p>              
                </p>

                  </Col>
                  
                </Row>
                {/* <Row>
                  <Col md={12}>
                    <p className="order-name-dashboard order-title">
                      No 17b Sybil Iroche, Lekki Phase 1
                </p>
                    <p className="order-label">Delivery Location</p>
                  </Col>
                </Row> */}
              </div>

              <Table className="col-no-padding responsive_custom_table"  borderless>
                <thead>
                  <tr>

                    <th>Test</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th></th>
                  </tr>
                </thead>

                { row.is_bundle == 0 ? 
                  <tbody className="responsive_row">
                  <tr>
                    <td data-column="Test">{row.test_name}</td>
                    <td data-column="Quantity">1</td>
                    <td data-column="Amount">₦{parseInt(row.price).toLocaleString('us', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td></td>
                  </tr>
                </tbody>
              : row.is_bundle == 1  ? 
                  row.bundle_tests.map(rw => {
                    return (
                      <tbody>
                      <tr>
                        <td data-column="Test">{rw.test_name}</td>
                        <td data-column="Quantity">1</td>
                        <td data-column="Amount">₦{parseInt(rw.price).toLocaleString('us', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td>
                        {
                                rw.order_status == 3 ? 
                                <a className="btn btn-default report-button float-right-button" href={rw.pdf_link} target="_blank"><button className="buy-test-button" style={{width:'150px'}}>View Result</button></a>
                                : 
                               <button className="btn btn-default report-button float-right-button">
                               Report Pending
                             </button>
                              }
                              </td>
                      </tr>
                    </tbody>
                    )
                  })
              :''}
               

              </Table>

            </Modal.Body>
                  </>
                )
              })}
            
          </Modal>


        </div>
        <ToastContainer autoClose={2000} />
        {/* //Featured Tests Section */}
      </div>
    );
  }
}

export default Reports;
