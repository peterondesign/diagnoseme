import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import "./../../css/Dashboard.css";
import bgelementsHomepage from "./../../assets/images/bgelementsHomepage.svg";
import Sidebar from "./Sidebar";
import key_illustration from "../../assets/images/key_illustration.png";
import Modal from "react-bootstrap/Modal";
import { getPin } from "./../../actions";
import DebugSentry from "../../apis/DebugSentry";

class RecoverPin extends React.Component {
  state = {
    show: false,
    isSubmitted: false,
    loading: false
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleShow = () => {
    this.setState({
      show: true
    });
  };

  handleClose = () => {
    this.setState({
      show: false
    });
  };

  handleGetPin = event => {
    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let password = event.target.password.value;

    const user = {
      password
    };

    if (user.password) {
      this.promise = this.props.getPin(user.password);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });
    }
  };

  render() {
    const { user, isSubmitted, loading } = this.state;
    const { response } = this.props.user;
    if (response) {
      var pinArray = [];
      pinArray = response.pin ? response.pin.split("") : [];
    }

    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
          <Container>
            <div className="dashboard-block">
              <Row>
                <Col md={2} className="sidebar-dashboard">
                  <div
                    style={{
                      marginBottom: "70px",
                      marginLeft: "auto",
                      marginRight: "auto",
                      textAlign: "center"
                    }}
                  >
                    <Link
                      to="/account/dashboard"
                      style={{ textDecoration: "none" }}
                      className="buy-test-sidebar"
                    >
                      Dashboard{" "}
                    </Link>
                  </div>
                  <div className="left-pane">
                    <Sidebar />
                  </div>
                </Col>
                <Col md={10} className="right-dashboard">
                  <Container>
                    <Row className="row-no-margin report-header-row">
                      <Col md={12} className="col-no-padding">
                        <h5 className="dashboard-title">Recover Result Password</h5>
                      </Col>
                    </Row>

                    <Row className="mb-5 order-row-dashboard pin-recovery-holder row-no-margin">
                      <Col md={3} className="recover-pin-illustration">
                        <img src={key_illustration} alt="Result Password"></img>
                      </Col>
                      <Col md={9} className="pin-recovery">
                        <p className="body-text">
                          To recover your Result Password please click the button below. You
                          will be asked to re-enter your account password
                        </p>
                        <Button
                          onClick={this.handleShow}
                          className="btn homepage-text-primary-button initiate-button d-block "
                        >
                          Show Result Password
                        </Button>
                      </Col>
                    </Row>
                  </Container>
                </Col>
              </Row>
            </div>
          </Container>

          <Modal show={this.state.show} onHide={this.handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Reveal Result Password</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <form onSubmit={this.handleGetPin}>
                <div
                  className={
                    "form-group" +
                    (isSubmitted && !user.password ? " has-error" : "")
                  }
                >
                  <label>Password</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    onChange={this.handleChange}
                  />
                  {isSubmitted && !user.password && (
                    <div className="help-block">Password is required</div>
                  )}
                </div>

                <button
                  type="submit"
                  className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block "
                  disabled={loading}
                >
                  {loading && (
                    <i
                      className="fa fa-refresh fa-spin"
                      style={{ marginRight: "5px" }}
                    />
                  )}
                  {loading && <span>Processing...</span>}
                  {!loading && <span>Submit</span>}
                </button>
              </form>

              <div className="your-pin">
                <div className="body-text">
                  {/* Your Personal Identification Number */}
                </div>
                <div className="pin-row recover">
                  {response && pinArray.length > 0 ? (
                    <Row>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[0]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[1]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[2]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[3]}
                        />
                      </Col>
                    </Row>
                  ) : (
                    <Row>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                    </Row>
                  )}
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </div>
        <ToastContainer autoClose={2000} />
        {/* //Featured Tests Section */}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { user: state.user };
};

export default connect(mapStateToProps, { getPin })(RecoverPin);
