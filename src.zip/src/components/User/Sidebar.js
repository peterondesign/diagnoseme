import React from "react";
import { NavLink, Link } from "react-router-dom";
import '../../css/Dashboard.css';
import Dashboard from "./Dashboard";

function Sidebar() {
  return (
    <ul className="dashboard-nav">

      <NavLink exact to="/account/dashboard" activeClassName="active-dashboard">
        <li className="dashboard-nav-li">Dashboard</li>
      </NavLink>

      <NavLink to="/account/reports" activeClassName="active-dashboard">
        <li className="dashboard-nav-li">My Orders</li>
      </NavLink>

      <NavLink to="/account/profile" activeClassName="active-dashboard">
        <li className="dashboard-nav-li">Profile</li>
      </NavLink>

      <NavLink to="/account/settings" activeClassName="active-dashboard">
        <li className="dashboard-nav-li">
         Settings
      </li>
      </NavLink>
    </ul>
  );
}

export default Sidebar;
