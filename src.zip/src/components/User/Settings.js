import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import "./../../css/Dashboard.css";
import bgelementsHomepage from "./../../assets/images/bgelementsHomepage.svg";
import Sidebar from "./Sidebar";
import key_illustration from "../../assets/images/key_illustration.png";
import Modal from "react-bootstrap/Modal";
import InputGroup from "react-bootstrap/InputGroup";
import {
  getPin,
  deactivateAccount,
  deleteAccount,
  changePassword
} from "../../actions";
import DebugSentry from "../../apis/DebugSentry";

class RecoverPin extends React.Component {
  state = {
    user: {},
    show: false,
    isSubmitted: false,
    loading: false,
    showPassword: false,
    showAccount: false,
    disableButton: true,
    confirmationCheck: false,
    confirmationCheckInputTouched: false,
    checkPasswordInputTouched: false,
    passwordCheck: false,
    showIf: false,
    ShowDe: false
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      },
      showIf: true,
      ShowDe: false
    });
  };

  handleChangeButton = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      },
      ShowDe: true,
      showIf: false
    });
  };

  handleShow = () => {
    this.setState({
      show: true
    });
  };

  handleShowPassword = () => {
    this.setState({
      showPassword: true
    });
  };

  handleClosePassword = () => {
    this.setState({
      showPassword: false
    });
  };

  handleShowAccount = () => {
    this.setState({
      showAccount: true
    });
  };

  handleCloseAccount = () => {
    this.setState({
      showAccount: false
    });
  };

  handleClose = () => {
    this.setState({
      show: false
    });
  };

  handleConfirm = event => {
    const { value } = event.target;

    if (value === "DELETE MY ACCOUNT") {
      this.setState({
        confirmationCheck: true,
        confirmationCheckInputTouched: true
      });
    } 
    else if (value === "DEACTIVATE MY ACCOUNT") {
      this.setState({
        confirmationCheck: true,
        confirmationCheckInputTouched: true
      });
    } 
    else {
      this.setState({
        confirmationCheck: false,
        confirmationCheckInputTouched: true
      });
    }
  };

  handleDeactivateDelete = event => {
    this.setState({
      isSubmitted: true
    });

    event.preventDefault();

    let action = event.target.action.value;
    let password = event.target.password.value;

    const user = {
      action,
      password
    };

    if (user.password && user.action) {
      if (user.action === "delete") {
        this.promise = this.props.deleteAccount(user.password);
        this.promise
          .catch(() => {})
          .then(() => {
            this.setState({ loading: false });
          });
      }

      if (user.action === "deactivate") {
        this.promise = this.props.deactivateAccount(user.password);
        this.promise
          .catch(() => {})
          .then(() => {
            this.setState({ loading: false });
          });
      }
    }
  };

  handleGetPin = event => {
    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let password = event.target.password.value;

    const user = {
      password
    };

    if (user.password) {
      this.promise = this.props.getPin(user.password);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });
    }
  };

  handleChangePassword = event => {
    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let old_password = event.target.password.value;
    let new_password = event.target.new_password.value;

    const user = {
      old_password,
      new_password
    };

    if (user.old_password && user.new_password) {
      this.promise = this.props.changePassword(user);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });
    }
  };

  handlePasswordCheck = event => {
    const { user } = this.state;
    const { value } = event.target;

    if (user.new_password === value) {
      this.setState({
        passwordCheck: true,
        checkPasswordInputTouched: true
      });
    } else {
      this.setState({
        passwordCheck: false,
        checkPasswordInputTouched: true
      });
    }
  };

  handleButtonDisable = passwordCheck => {
    if (passwordCheck) {
      return true;
    }
    return false;
  };

  render() {
    const {
      user,
      isSubmitted,
      loading,
      confirmationCheck,
      confirmationCheckInputTouched,
      passwordCheck,
      checkPasswordInputTouched
    } = this.state;
    const { response } = this.props.user;
    if (response) {
      var pinArray = [];
      pinArray = response.pin ? response.pin.split("") : [];
    }

    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsHomepage" alt=""></img>
          <Container>
            <div className="dashboard-block">
              <Row className="sidebar-row">
                <Col md={2} className="sidebar-dashboard">
                 
                  <div className="left-pane">
                    <Sidebar />
                  </div>
                </Col>
                <Col md={10} className="right-dashboard">
                  <Container>
                    <Row className="row-no-margin report-header-row">
                      <Col md={12} className="col-no-padding">
                        <h5 className="dashboard-title">Recover Result Password</h5>
                      </Col>
                    </Row>

                    <Row className="mb-5 order-row-dashboard pin-recovery-holder row-no-margin">
                      <Col md={3} className="recover-pin-illustration">
                        <img src={key_illustration} alt="Result Password"></img>
                      </Col>
                      <Col md={9} className="pin-recovery">
                        <p className="body-text">
                          To recover your Result Password please click the button below. You
                          will be asked to re-enter your password
                        </p>
                        <Button
                          onClick={this.handleShow}
                          className="btn homepage-text-primary-button initiate-button d-block "
                        >
                          Show Result Password
                        </Button>
                      </Col>
                    </Row>

                    <Row className="row-no-margin report-header-row">
                      <Col md={12} className="col-no-padding">
                        <h5 className="dashboard-title">Account Settings</h5>
                      </Col>
                    </Row>

                    <Row className="row-no-margin report-header-row">
                      <Col className="dashboard-component-border">
                        <p className="setting-header">
                          <b>Change Password</b>
                        </p>
                        <p className="setting-description">
                          Create a new password for your account
                        </p>
                        <p
                          onClick={this.handleShowPassword}
                          style={{ color: "#697DC4", cursor: "pointer" }}
                        >
                          View
                        </p>
                      </Col>
                      <Col className="dashboard-component-border">
                        <p className="setting-header">
                          <b>Deactivate/Delete Account</b>
                        </p>
                        <p className="setting-description">
                          Temporarily deactivate or permanently delete your
                          account
                        </p>
                        <p
                          onClick={this.handleShowAccount}
                          style={{ color: "#697DC4", cursor: "pointer" }}
                        >
                          View
                        </p>
                      </Col>
                    </Row>

                 
                  </Container>
                </Col>
              </Row>
            </div>
          </Container>

          {/* Modal for Change Password */}

          <Modal
            show={this.state.showPassword}
            onHide={this.handleClosePassword}
          >
            <Modal.Header closeButton>
              <Modal.Title>Change Password</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <form onSubmit={this.handleChangePassword}>
                <div
                  className={
                    "form-group" +
                    (isSubmitted && !user.password ? " has-error" : "")
                  }
                >
                  <label>Enter current password</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    onChange={this.handleChange}
                  />
                  {isSubmitted && !user.password && (
                    <div className="help-block">Password is required</div>
                  )}
                </div>

                <div
                  className={
                    "form-group" +
                    (isSubmitted && !user.new_password ? " has-error" : "")
                  }
                >
                  <label>Enter new password</label>
                  <input
                    type="password"
                    name="new_password"
                    className="form-control"
                    onChange={this.handleChange}
                    onPaste={this.handleNoPaste}
                  />
                  {isSubmitted && !user.new_password && (
                    <div className="help-block">Enter your new password</div>
                  )}
                </div>

                <div
                  className={
                    "form-group" +
                    (isSubmitted && !user.confirm_password ? " has-error" : "")
                  }
                >
                  <label>Confirm new password</label>
                  <input
                    type="password"
                    name="confirm_password"
                    className="form-control"
                    onChange={this.handleChange}
                    onInput={this.handlePasswordCheck}
                    onPaste={this.handleNoPaste}
                  />
                  {isSubmitted && !user.confirm_password && (
                    <div className="help-block">Confirm your Password</div>
                  )}
                  {!passwordCheck && checkPasswordInputTouched && (
                    <div className="help-block">
                      Passwords does not match
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block "
                  disabled={loading || !this.handleButtonDisable(passwordCheck)}
                >
                  {loading && (
                    <i
                      className="fa fa-refresh fa-spin"
                      style={{ marginRight: "5px" }}
                    />
                  )}
                  {loading && <span>Processing...</span>}
                  {!loading && <span>Submit</span>}
                </button>
              </form>
            </Modal.Body>
          </Modal>

          {/* //Modal for Change Password */}

          {/* Modal for Deactivate Account */}

          <Modal
            size="lg"
            show={this.state.showAccount}
            onHide={this.handleCloseAccount}
          >
            <Modal.Header closeButton>
              <Modal.Title>Deactivate/Delete Account</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              {isSubmitted && !user.action && (
                <div className="help-block">You need to tick an option</div>
              )}
              <form onSubmit={this.handleDeactivateDelete}>
                <div
                  className={
                    "dashboard-component-border mt-3 mb-3" +
                    (isSubmitted && !user.action ? " has-error" : "")
                  }
                >
                  <InputGroup>
                    <InputGroup.Prepend>
                      <InputGroup.Radio
                        aria-label="Radio button for following text input"
                        type="radio"
                        name="action"
                        value="deactivate"
                        onChange={this.handleChange}
                      />
                      <p className="delete-action-text">Deactivate account</p>
                    </InputGroup.Prepend>

                    <p className="delete-action">
                      Deactivating your account is temporary. Your reports and
                      profile information will be available when you reactivate
                      by logging in
                    </p>
                  </InputGroup>
                </div>

                <div className="dashboard-component-border mb-3">
                  <InputGroup>
                    <InputGroup.Prepend>
                      <InputGroup.Radio
                        aria-label="Radio button for following text input"
                        type="radio"
                        name="action"
                        value="delete"
                        onChange={this.handleChangeButton}
                      />
                      <p className="delete-action-text">Delete account</p>
                    </InputGroup.Prepend>

                    <p className="delete-action">
                      Deleting account is permanent Your reports and profile
                      information will be deleted. For up to 30 days after
                      deletion it is still possible to restore your account if
                      it was accidentally or wrongfully deleted.
                    </p>
                  </InputGroup>
                </div>
                { this.state.showIf ?
                   <>
                   <Row className="mb-4">
                     <Col md={6}>
                       <div
                         className={
                           "form-group" +
                           (isSubmitted && !user.password ? " has-error" : "")
                         }
                       >
                         <label>Enter password to confirm</label>
                         <input
                           type="password"
                           name="password"
                           className="form-control"
                           onChange={this.handleChange}
                         />
                         {isSubmitted && !user.password && (
                           <div className="help-block">Password is required</div>
                         )}
                       </div>
                     </Col>
   
                     <Col md={6}>
                       <div className="form-group">
                         <label>Deactivate My Account</label>
                         <input
                           placeholder="Type 'Deactivate My Account' to Confirm"
                           type="text"
                           name="confirmation"
                           className="form-control"
                           onChange={this.handleConfirm}
                         />
                         {confirmationCheckInputTouched && !confirmationCheck && (
                           <div className="help-block">
                             Type "DEACTIVATE MY ACCOUNT" for confirmation
                           </div>
                         )}
                         
                       </div>
                     </Col>
                   </Row>
   
                   {!confirmationCheck ? (
                     <button
                       type="submit"
                       className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block w-100"
                       disabled
                     >
                       Submit
                     </button>
                   ) : (
                     <button
                       type="submit"
                       className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block w-100"
                       disabled={loading}
                     >
                       {loading && (
                         <i
                           className="fa fa-refresh fa-spin"
                           style={{ marginRight: "5px" }}
                         />
                       )}
                       {loading && <span>Processing...</span>}
                       {!loading && <span>Submit</span>}
                     </button>
                   )}
                   </>
   
                : this.state.ShowDe ?
                <>
                <Row className="mb-4">
                  <Col md={6}>
                    <div
                      className={
                        "form-group" +
                        (isSubmitted && !user.password ? " has-error" : "")
                      }
                    >
                      <label>Enter password to confirm</label>
                      <input
                        type="password"
                        name="password"
                        className="form-control"
                        onChange={this.handleChange}
                      />
                      {isSubmitted && !user.password && (
                        <div className="help-block">Password is required</div>
                      )}
                    </div>
                  </Col>

                  <Col md={6}>
                    <div className="form-group">
                      <label>Delete My Account</label>
                      <input
                        placeholder="Type 'Delete My Account' to Confirm"
                        type="text"
                        name="confirmation"
                        className="form-control"
                        onChange={this.handleConfirm}
                      />
                      {confirmationCheckInputTouched && !confirmationCheck && (
                        <div className="help-block">
                          Type "DELETE MY ACCOUNT" for confirmation
                        </div>
                      )}
                      
                    </div>
                  </Col>
                </Row>

                {!confirmationCheck ? (
                  <button
                    type="submit"
                    className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block w-100"
                    disabled
                  >
                    Submit
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block w-100"
                    disabled={loading}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing...</span>}
                    {!loading && <span>Submit</span>}
                  </button>
                )}
                </>:''}
                               </form>
            </Modal.Body>
          </Modal>

          {/* // Modal for Delete Account */}

          {/* Modal for Reveal PIN */}

          <Modal show={this.state.show} onHide={this.handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Reveal Result Password</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <form onSubmit={this.handleGetPin}>
                <div
                  className={
                    "form-group" +
                    (isSubmitted && !user.password ? " has-error" : "")
                  }
                >
                  <label>Password</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    onChange={this.handleChange}
                  />
                  {isSubmitted && !user.password && (
                    <div className="help-block">Password is required</div>
                  )}
                </div>

                <button
                  type="submit"
                  className="btn mt-3 mb-3 homepage-text-primary-button initiate-button d-block "
                  disabled={loading}
                >
                  {loading && (
                    <i
                      className="fa fa-refresh fa-spin"
                      style={{ marginRight: "5px" }}
                    />
                  )}
                  {loading && <span>Processing...</span>}
                  {!loading && <span>Submit</span>}
                </button>
              </form>

              <div className="your-pin">
                <div className="body-text">
                  {/* Your Personal Identification Number */}
                </div>
                <div className="pin-row recover">
                  {response && pinArray.length > 0 ? (
                    <Row>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[0]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[1]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[2]}
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control visible-pin"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value={pinArray[3]}
                        />
                      </Col>
                    </Row>
                  ) : (
                    <Row>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                      <Col lg={3} md={3} sm={3} xs={3}>
                        <input
                          className="pin-input form-control"
                          readOnly
                          style={{ borderColor: "#d9dcde" }}
                          value="*"
                        />
                      </Col>
                    </Row>
                  )}
                </div>
              </div>
            </Modal.Body>
          </Modal>

          {/* // Modal for Reveal PIN */}
        </div>
        <ToastContainer autoClose={2000} />
        {/* //Featured Tests Section */}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { user: state.user };
};

export default connect(mapStateToProps, {
  getPin,
  deactivateAccount,
  deleteAccount,
  changePassword
})(RecoverPin);
