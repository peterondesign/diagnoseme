import React, { useState, useEffect } from "react";

import {
  BrowserRouter,
  Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import history from "./../history";

import Layout from "./Layout";
import NoMatch from "./NoMatch";
import Login from "./Auth/Login";
import ResetPassword from "./Auth/ResetPassword";

import BookingSuccess from "./Auth/Verification/BookingSuccess";

import VerificationSuccess from "./Auth/Verification/VerificationSuccess";
import VerificationFailed from "./Auth/Verification/VerificationFailed";
import LoginCheckout from "./Auth/LoginCheckout";
import Signup from "./Auth/Signup";
import CovidSignup from "./Auth/CovidSignup";
import Returnee from "./Auth/Returnee";
import ReturneeReferral from "./Auth/ReturneeReferral";
import ForgotPassword from "./Auth/ForgotPassword";
import Summary from "./Order/Summary";
import ReviewOrder from "./Order/ReviewOrder";
import Information from "./Order/Information";
import PurposeOfTest from "./Order/PurposeOfTest";
import PaymentSuccess from "./Order/PaymentSuccess";
import PaymentFailure from "./Order/PaymentFailure";
import Travel from "./Order/Travel";
import OrderDetails from "./Order/OrderDetails";
import MyAppointments from "./Order/MyAppointments.js";
import BookMyAppointments from "./Order/BookMyAppointments.js";
import OrderSuccess from "./Order/OrderSuccess";
import BookAppointment from "./Order/BookAppointment";
import BookingCalendar from "../Calendar";
import CIF from "./Order/CIF";
import CIF1 from "./Order/CIF1";
import CIF2 from "./Order/CIF2";
import CIF3 from "./Order/CIF3";
import CIF4 from "./Order/CIF4";
import CIF5 from "./Order/CIF5";
// import CIF6 from "./Order/CIF6";
// import CIF7 from "./Order/CIF7";
// import Travel from "./Order/Travel";

import Address from "./Order/Address";
import Payment from "./Order/Payment";
import BuyTests from "./BuyTests";
import Providers from "./Providers";
import AboutUs from "./AboutUs";
import Terms from "./Terms";
import Privacy from "./Privacy";
import Covid19Privacy from "./Covid19Privacy";
import Help from "./Help";
import Home from "./Home";
import CovidHomepage from "./CovidHomepage";
import Errorpage from "./Error";
import ScrollToTop from "./ScrollToTop";
import "../css/App.css";
import Cart from "./Cart";
import Dashboard from "./User/Dashboard";
import Profile from "./User/Profile";

import UserActivity from "./UserActivity";
import Reports from "./User/Reports";
import Settings from "./User/Settings";
import { render } from "@testing-library/react";
import { API_URL } from "../apis/diagnosemeApi";
import Booking from "../Booking";

function Authenticated({ component: C, appProps, ...rest }) {
  return (
    <Route
      {...rest}
      render={(props) =>
        appProps !== null ? <C {...props} {...appProps} /> : <Redirect to="/auth/login" />
      }
    />
  );
}

function UnAuthenticated({ component: C, appProps, ...rest }) {
  console.log(appProps);
  return (
    <Route
      {...rest}
      render={(props) =>
        appProps === null ? <C {...props} {...appProps} /> : <Dashboard />
      }
    />
  );
}

function App() {
  const [appState, setAppState] = useState(null);
  const [state, setState] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}returnee/state`)
      .then((res) => res.json())
      .then((response) => {
        console.log(response);
        setState(response.data);
      })
      .catch((error) => console.log(error));
  }, []);

  useEffect(() => {
    let user = localStorage.getItem("user");
    setAppState(user);
  }, []);

  const renderState = (routerProps) => {
    let stateName = routerProps.match.params.id;
    let foundState = state.find((obj) => obj.name.toLowerCase() === stateName);
    return foundState ? (
      <Returnee state={foundState} loader="true" />
    ) : (
      <NoMatch />
    );
  };

  return (
    <BrowserRouter>
      <Router history={history}>
        <Layout>
          {localStorage.getItem("user") !== null ? <UserActivity /> : ""}
          <ScrollToTop />
          <Switch>
            <Route path="/error" component={Errorpage} />
            <Route path="/privacy" component={Privacy} />
            <Route path="/covid-19/privacy" component={Covid19Privacy} />
            <Route path="/terms" component={Terms} />
            <Route path="/about-us" component={AboutUs} />
            <Route path="/help" component={Help} />

            <UnAuthenticated
              appProps={appState}
              path="/"
              exact
              component={CovidHomepage}
            />
            <UnAuthenticated
              appProps={appState}
              path="/auth/login"
              exact
              component={Login}
            />
            <UnAuthenticated
              appProps={appState}
              path="/auth/login/checkout"
              component={LoginCheckout}
            />

            <UnAuthenticated
              appProps={appState}
              path="/auth/signup"
              component={Signup}
            />

            <Route
              path="/covid19/:id"
              exact
              render={(routerProps) => renderState(routerProps)}
            />
            <Route
              path="/covid19/booking/register/"
              exact
              component={ReturneeReferral}
            />

            <UnAuthenticated
              appProps={appState}
              path="/auth/forgot_password"
              component={ForgotPassword}
            />
            <UnAuthenticated
              appProps={appState}
              path="/user/reset-password/:handle"
              component={ResetPassword}
            />
            <UnAuthenticated
              appProps={appState}
              path="/user/covid/:token"
              component={CovidSignup}
            />
            <Route path="/booking/success" component={BookingSuccess} />

            <Route
              path="/auth/verify/success"
              component={VerificationSuccess}
            />
            <Route path="/auth/verify/failed" component={VerificationFailed} />
            <Authenticated
              appProps={appState}
              path="/account/dashboard"
              component={Dashboard}
            />
            <Authenticated
              appProps={appState}
              path="/account/profile"
              component={Profile}
            />
            <Authenticated
              appProps={appState}
              path="/account/reports"
              component={Reports}
            />
            <Authenticated
              appProps={appState}
              path="/account/settings"
              component={Settings}
            />

            <Authenticated
              appProps={appState}
              path="/order/details"
              component={OrderDetails}
            />

            <Authenticated
              appProps={appState}
              path="/order/review"
              component={ReviewOrder}
            />

            <Authenticated
              appProps={appState}
              path="/order/payment/success"
              component={PaymentSuccess}
            />

            <Authenticated
              appProps={appState}
              path="/order/payment/failure"
              component={PaymentFailure}
            />

            <Authenticated
              appProps={appState}
              path="/order/myappointments"
              component={MyAppointments}
            />

            <Authenticated
              appProps={appState}
              path="/order/bookmyappointments"
              component={BookMyAppointments}
            />

            <Route path="/booking/appointment" component={Booking} />

            <Route path="/booking/calendar" component={BookingCalendar} />

            <Route path="/providers" component={Providers} />

            <Route path="/order/travel" component={Travel} />

            <Route path="/order/purpose" component={PurposeOfTest} />

            <Route path="/order/travel" component={Travel} />

            <Route path="/order/BookAppointment" component={BookAppointment} />

            <Route path="/appointment/success" component={OrderSuccess} />

            {/* <Route path="/buytests" component={BuyTests}/>
            {/* CIF */}
            <Route path="/order/CIF" component={CIF} />

            <Route path="/order/CIF1" component={CIF1} />

            <Route path="/order/CIF2" component={CIF2} />

            <Route path="/order/CIF3" component={CIF3} />

            <Route path="/order/CIF4" component={CIF4} />

            <Route path="/order/CIF5" component={CIF5} />

            {/* <Route path="/order/CIF6" component={CIF6}/>

          <Route path="/order/CIF7" component={CIF7}/> */}

            {/* <Route path="/buytests" component={BuyTests}/>
          {/* <Route path="/buytests" component={BuyTests}/>
          <Route path="/cart" component={Cart}/>
          <Route path="/checkout" component={Summary} />
          <Route path="/order/summary" component={Summary} />
          <Route path="/order/information" component={Information} />
          <Route path="/order/address" component={Address} />
          <Route path="/order/payment" component={Payment} />  */}

            <Route component={NoMatch} />
          </Switch>
        </Layout>
      </Router>
    </BrowserRouter>
  );
}

export default App;
