import Header from './Header';
import Footer from './Footer';
import Cart from './Cart';
import CookieMessage from './CookieMessage';
import React, {Component} from 'react';


export default class Layout extends Component {
    render() {
        return (
            <div>
                <Cart/>
                <Header/>
                {this.props.children}
                <CookieMessage className="mb-5"/>
                <Footer/>
            </div>
        )
    }
}
