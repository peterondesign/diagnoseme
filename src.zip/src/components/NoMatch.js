import React from 'react'
import { NavLink as Link } from "react-router-dom";
import notFound from '../assets/images/missingillustration.svg';
import '../css/NoMatch.css';

const NoMatch = () => {
    return (
        <div>
            <section className="A404-section">
                    <div className="container-fluid">
                        <div className="row no-margin-row">
                            <div className="col-md-12">
                                <div className="missingimage mx-auto">
                                    
                                    <div className="row ">
                                        {/* <h5 className="no-match-header-sub">
                                            Unfortunately, we couldn't find the page you were looking for
                                        </h5><br></br> */}
                                        <div className="col-md-offset-4 mx-auto col-md-10">
                                        <img src={notFound} className="img-responsive mx-auto missing-img" alt="404" />
                                        <h5 className="no-match-header-sub">
                                            Unfortunately, we couldn't find the page you were looking for
                                        </h5><br></br>
                                        <Link to="/"> 
                                        <button className="btn btn-primary no-match-btn btn-block">Go to Home</button>
                                        </Link>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
        </div>
    )
}

export default NoMatch
