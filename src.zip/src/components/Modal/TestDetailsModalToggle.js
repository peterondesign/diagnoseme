import React, { useState } from 'react';
import { Link } from 'react-router-dom'

import TestDetailsModal from './../Modal/TestDetailsModal';

const TestDetailsModalToggle = ({ tat, onCloseModal, onHide, show, images, sample, why, test_for, title, testId, test, price, is_bundle, delivery_methods }) => {

    const [modalShow, setModalShow] = useState(false);
   
    const handleShow = () => setModalShow(true)
    const handleClose= () => setModalShow(false)
    return (
      <span>
          <Link onClick={handleShow}>{title}</Link>
            <TestDetailsModal
                show={modalShow}
                onHide={handleClose}
                testId={testId}
                test={test}
                price={price}
                test_for={test_for}
                why={why}
                sample={sample}
                images={images}
                is_bundle={is_bundle}
                onCloseModal={handleClose}
                tat={tat}
                delivery_methods={delivery_methods}
            />
      </span>
    );
    
};

export default TestDetailsModalToggle
