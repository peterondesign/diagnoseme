import React from 'react'
import ReactDOM from 'react-dom'
import './../../css/LocationModal.css';
import { Container , Row , Col, Modal, Form, Card, Button } from 'react-bootstrap';

const LocationModal = (props) => {

    return ReactDOM.createPortal(
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            >

            <Modal.Header closeButton></Modal.Header>

            <Modal.Body>
                
                <Container>
                    <Row>
                        
                        <div className="checkout">
                            <Card style={{ width: '100%' }}>
                                <Card.Header>Delivery Method</Card.Header>

                                <Card.Body>
                                
                                    <Row>
                                        <Col md={6}>
                                            <Card.Title>Region</Card.Title>
                                            <Form.Control as="select">
                                                <option value="Lagos">Lagos </option>
                                            </Form.Control>
                                        </Col>

                                        <Col md={6}>
                                            <Card.Title>City</Card.Title>
                                            <Form.Control as="select">
                                                <option>Lekki Phase 1</option>
                                            </Form.Control>
                                        </Col>
                                        
                                    </Row>

                                    <hr className="divider"/>

                                    <Row>

                                        <Col md={12}>
                                            <h6 className="modal-title-inner">Collection Centers near you</h6>
                                        </Col>

                                        <Col md={12}>
                                            
                                            <Row>
                                                <Col md={1}>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" />
                                                    </div>
                                                </Col>

                                                <Col md={6}>
                                                    <p className="location-modal-header">MedPlus (Freedom Way)</p>
                                                    <p className="location-modal-p1">Address</p>
                                                    <p className="location-modal-p2">No 20, Freedom Way, Opposite Greenville Mall</p>
                                                </Col>

                                                <Col md={5}>
                                                    <p className="location-modal-p1">Opening Hours</p>            
                                                    <p className="location-modal-p2 location-opening">Monday - Friday <span className="pull-right">9am - 5pm</span></p>
                                                    <p className="location-modal-p2 location-opening">Saturday - Sunday <span className="pull-right">11am - 12pm</span></p> 
                                                </Col>
                                            </Row>
                                                
                                        </Col>
                                        
                                    </Row>
                
                                </Card.Body>
                            </Card>
                        </div>

                    </Row>
                </Container>
                
            </Modal.Body>

            <Modal.Footer>
                <Button onClick={props.onHide} className="order-next">Select Collection Center</Button>
            </Modal.Footer>
        </Modal>,
        document.querySelector('#modal')
    );

};

export default LocationModal
