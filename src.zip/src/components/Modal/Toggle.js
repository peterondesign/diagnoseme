import React, { useState } from 'react';
import { ButtonToolbar, Button } from 'react-bootstrap';
import LocationModal from './../Modal/LocationModal';

const Toggle = (props) => {

    const [modalShow, setModalShow] = useState(false);
  
    return (
      <span>
          <a className="see-location pull-right" onClick={() => setModalShow(true)}>{props.title}</a>
            <LocationModal
                show={modalShow}
                onHide={() => setModalShow(false)}
            />
      </span>
    );
    
};

export default Toggle
