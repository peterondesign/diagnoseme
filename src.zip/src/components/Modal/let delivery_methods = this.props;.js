let delivery_methods = this.props;
    const d = JSON.parse(this.props.delivery_methods)    
    console.log('dddd: ',d[1]);
{
    d[0]==='undefined'? '' : <div className="test-delivery-method">{d[0]}</div>
  }
  {
    d[1]==='undefined'? '' : <div className="test-delivery-method">{d[1]}</div>
  }
  {
    d[2]==='undefined'? '' : <div className="test-delivery-method">{d[2]}</div>
  }