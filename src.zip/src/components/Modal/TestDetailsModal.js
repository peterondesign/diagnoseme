import React, { Component } from "react";
import ReactDOM from "react-dom";
import { connect } from "react-redux";
import { addToCart } from "../../actions/cart";
import { toast } from "react-toastify";

import "./../../css/TestDetailsModal.css";
import {
  Tabs,
  Tab,
  Container,
  Row,
  Col,
  Modal,
  Form,
  Card,
  Button,
  ButtonToolbar,
  Tooltip,
  OverlayTrigger
} from "react-bootstrap";
import { Link } from "react-router-dom";

class TestDetailsModal extends Component {
  render() {
    // let delivery_methods = this.props;

    // if(delivery_methods) {
    //   let delivery_methods_array = delivery_methods.split(', ');
    // }

    // console.log('Delivery method: ',  delivery_methods);
    // console.log("Cart props: ", this.props);
    const add2cart = (testId, test, price, is_bundle, quantity) => {
      addToCart(testId, test, price, is_bundle, quantity);
      this.props.onCloseModal();
    };

    const buyNow = (testId, test, price, is_bundle, quantity) => {
      addToCart(testId, test, price, is_bundle, quantity);
      this.props.onCloseModal();
      if (localStorage.getItem('user') === null) {
        localStorage.setItem('checkout', true);
        window.location.href = '/auth/login'
      } else {
        localStorage.setItem('checkout', false);
        window.location.href = '/order/summary'
      }
    }

    const addToCart = (testId, test, price, is_bundle, quantity) => {
      this.props.addToCart(testId, test, price, is_bundle, quantity);
    };

    const quantity = 1;

    return ReactDOM.createPortal(
      <Modal
        {...this.props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        id="test-details-modal-order"
      >
        <Modal.Header closeButton></Modal.Header>

        <Modal.Body>
          <Container>
            <Row className="test-details-header-group">
              <Col md={4} style={{ padding: "0px 0px" }}>
                <img src={this.props.images} id="test-image-on-modal"></img>
              </Col>

              <Col md={8} className="no-padding-on-mobile">
                <div className="test-details-header">
                  <div className="test-title-modal">{this.props.test}</div>
                  <div className="test-turnaround-time">
                    Turnaround time:{this.props.tat}
                    <ButtonToolbar>
                      {["right"].map(placement => (
                        <OverlayTrigger
                          key={placement}
                          placement={placement}
                          overlay={
                            <Tooltip>
                              This refers to the time from when the sample is
                              received in the lab until the result is sent to
                              you
                            </Tooltip>
                          }
                        >
                          <svg
                            className="ml-2 my-auto"
                            xmlns="http://www.w3.org/2000/svg"
                            width="15"
                            height="15"
                            viewBox="0 0 17.8 17.8"
                          >
                            <g
                              id="Icon_feather-info"
                              data-name="Icon feather-info"
                              transform="translate(-2.5 -2.5)"
                            >
                              <path
                                id="Path_75"
                                data-name="Path 75"
                                d="M19.8,11.4A8.4,8.4,0,1,1,11.4,3,8.4,8.4,0,0,1,19.8,11.4Z"
                                transform="translate(0 0)"
                                fill="none"
                                stroke="#000"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1"
                              />
                              <path
                                id="Path_76"
                                data-name="Path 76"
                                d="M18,21.36V18"
                                transform="translate(-6.6 -6.6)"
                                fill="none"
                                stroke="#000"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1"
                              />
                              <path
                                id="Path_77"
                                data-name="Path 77"
                                d="M18,12h0"
                                transform="translate(-6.6 -3.96)"
                                fill="none"
                                stroke="#000"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1"
                              />
                            </g>
                          </svg>
                        </OverlayTrigger>
                      ))}
                    </ButtonToolbar>
                  </div>
                  <div className="test-delivery-method-group">
                    {/* <div className="test-delivery-method">{this.props.delivery_methods}</div> */}
                    <div className="test-delivery-method">
                      At home service
                    </div>
                    <div className="test-delivery-method">
                      Self-Sampling Kit
                    </div>
                    <div className="test-delivery-method">
                      Collection Center
                    </div>
                  </div>
                </div>
              </Col>
            </Row>

            <Row>
              <div className="test-details-border">
                <div className="test-details-text">
                  <Tabs
                    defaultActiveKey="Tests-for"
                    id="test-details-text-control"
                  >
                    <Tab
                      eventKey="Tests-for"
                      title="Tests for"
                      id="test-details-text-control"
                    >
                      {this.props.test_for}
                    </Tab>
                    <Tab
                      eventKey="Why-Get-Tested"
                      title="Why Get Tested"
                      id="test-details-text-control"
                    >
                      {this.props.why}
                    </Tab>
                    <Tab
                      eventKey="Sample-Required"
                      title="Sample Required"
                      id="test-details-text-control"
                    >
                      {this.props.sample}
                    </Tab>
                  </Tabs>
                </div>
              </div>
            </Row>
          </Container>
        </Modal.Body>
        <Modal.Footer>
          <Row className="justify-content-space-between">
            <Col md={6} className="no-padding-on-mobile text-center-mobile my-auto pl-0 pr-0">
              <div className="test-price-modal">
                <span style={{ fontFamily: "arial" }}>₦</span>
                {parseInt(this.props.price).toLocaleString("us", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}
              </div>
            </Col>

            <Col md={6} className="no-padding-on-mobile pl-0 pr-0">

              <div class="button-group">
                <div>
                  <Link
                    onClick={() =>
                      add2cart(
                        this.props.testId,
                        this.props.test,
                        this.props.price,
                        this.props.is_bundle,
                        quantity
                      )
                    }

                    className="btn outline-button-custom"
                  >
                    Add to Cart
                  </Link>
                </div>
                <div>

                  <Link
                    onClick={() =>
                      buyNow(
                        this.props.testId,
                        this.props.test,
                        this.props.price,
                        this.props.is_bundle,
                        quantity
                      )
                    }

                    className="btn primary-button-custom"
                  >
                    Buy Now
                  </Link>
                </div>

              </div>

            </Col>
          </Row>
        </Modal.Footer>
      </Modal>,
      document.querySelector("#modal")
    );
  }
}

const mapStateToProps = state => {
  return {
    isCart: state.cart.isCart,
    cart: state.cart.cart
  };
};

const mapDispatchToProps = dispatch => {
  return {
    addToCart: (testId, test, price, is_bundle) => {
      dispatch(addToCart(testId, test, price, is_bundle));
    }
  };
};

export default connect(mapStateToProps, { addToCart })(TestDetailsModal);
