import React from 'react';
import Logo from '../assets/images/diagnoseme_logo.svg'
import '../css/Footer.css';
import { NavLink, Link } from "react-router-dom";
import { Container, Row, Col } from 'react-bootstrap';

import MediaQuery from "react-responsive";


const Footer = () => {

  return (
    <div className="footer-box">
      <Container>
        <div className="footer-top-section">
          <Row>
            <Col md={6} className="text-center-mobile">
              <a href="mailto:hello@diagnosemeafrica.com" style={{ color: "#CED6EC" }}>hello@diagnosemeafrica.com</a>
            </Col>
            <MediaQuery minDeviceWidth={990}>
              <Col md={6} className="text-center-mobile">
                <a href="tel:+2347003424667363" className="footer-top-section-right" style={{ color: "#CED6EC" }}>Phone:  0700DIAGNOSEME (+234 700 342 466 7363)</a>
              </Col>
            </MediaQuery>
            <MediaQuery maxDeviceWidth={990}>
              <Col md={6} className="text-center-mobile">
                <a href="tel:+2347003424667363" className="footer-top-section-right" style={{ color: "#CED6EC" }}>Phone:  0700DIAGNOSEME <br></br> (+234 700 342 466 7363)</a>
              </Col>
            </MediaQuery>
          </Row>
        </div>
        <div className="footer-bottom-section">
          <Row>
            <Col md={4} className="text-center-mobile">
              <img src={Logo} className="logo-footer" alt="logo" />
              <p style={{ color: 'white', fontSize: '10px', marginTop: '5px' }}>Commited to you</p>
              <div className="social-icon-row">

                <ul className="social-icon social-icon-md">
                  <li><a href="#" target="_blank"><i className="fab fa-facebook"></i></a></li>
                  <li><a href="#" target="_blank"><i className="fab fa-twitter"></i></a></li>
                  <li><a href="#" target="_blank"><i className="fab fa-instagram"></i></a></li>
                </ul>

              </div>
            </Col>

            <Col md={8} className="footer-top-section-right text-center-mobile">
              <Row>
                <Col md={3} className="hidden-footer-col">

                  <ul className="footer-header-title"><p>Coming Soon</p>

                    <li><a href="#">Ordering for a Friend</a></li>
                    <li><a href="#">Ordering for a Dependent</a></li>

                  </ul>

                </Col>

                <Col md={3}>

                  <ul className="footer-header-title"><p>Quick Links</p>

                    {/* <NavLink activeClassName="text-white"  to="/auth/signup"><li><a>Sign up</a></li></NavLink> */}
                    <NavLink activeClassName="text-white" to="/auth/login"><li><a>Log in</a></li></NavLink>

                  </ul>

                </Col>



                <Col md={3}>

                  <ul className="footer-header-title"><p>Resources</p>

                    <NavLink activeClassName="text-white" to="/help"><li>Help</li></NavLink>
                    {/* <NavLink activeClassName="text-white"  to="/terms"><li>Terms of Service</li></NavLink> */}
                    <NavLink activeClassName="text-white" to="/privacy"><li>Privacy Notice</li></NavLink>
                    <NavLink activeClassName="text-white" to="/covid-19/privacy"><li>Covid-19 Privacy Notice</li></NavLink>

                  </ul>

                </Col>

                <Col md={3}>

                  <ul className="footer-header-title"><p>Company</p>

                    <NavLink activeClassName="text-white" to="/about-us"><li>About Us</li></NavLink>
                    {/* <li><a href="#">Partnerships</a></li> */}
                    {/* <li><a href="#">Work with us</a></li> */}


                  </ul>

                </Col>
              </Row>

            </Col>
          </Row>

        </div>
      </Container>

    </div>



  );

}

export default Footer



