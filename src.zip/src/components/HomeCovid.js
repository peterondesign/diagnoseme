import React from 'react';
import { Row, Container, Button, Card, Col } from 'react-bootstrap';
import Accordion from 'react-bootstrap/Accordion';
import Form from 'react-bootstrap/Form';
import { Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import '../css/HomeCovid.css';
import covidimg from '../assets/images/covidimg.jpg';
import whatiscovid from '../assets/images/whatiscovid.png';


const Home = () => {

    return (
        <div>
            <div className="section-padding">
                <Container>
                    <Row className="text-img-group-covid">
                        <Col md={6}>
                            <img src={covidimg} id="covidimg" alt="covid"></img>
                        </Col>
                        <Col md={6} className="text-group-covid my-auto body-text">
                            <h3>Test for the respiratory illness coronavirus disease (COVID-19) and the associated SARS-CoV-2 virus</h3>
                            <p>DiagnoseMe is gearing up to provide COVID-19 testing.
                            <b>Kindly note that the test will only be made available to individuals who
                            provide a doctor’s prescription.</b>
                            </p>
                            <div className="d-flex cta-covid">
                                <Button className="cta-home-button">
                                    Sign up to our Newsletter
                            </Button>
                                <p className="my-auto body-text">*Dates will be announced in the week of the 23rd of March.
                            </p>
                            </div>
                        </Col>
                    </Row>
                </Container>

                <div className="section-blue-covid">
                    <Container>


                        <Row>

                            <Col md={6}>
                                <p className="title-header">What is COVID-19?</p>
                                <p className="body-text">Coronaviruses (CoV) are a large family of viruses that cause illness ranging from the common cold to more severe diseases such as Middle East Respiratory Syndrome (MERS-CoV) and Severe Acute Respiratory Syndrome (SARS-CoV).

                                <br></br> <br></br>

                                Coronavirus disease (COVID-19) is a new strain that was discovered in 2019. COVID-19 is the infectious disease caused by the most recently discovered coronavirus. This new virus and disease were unknown before the outbreak began in Wuhan, China, in December 2019. Common signs of infection include respiratory symptoms such as fever, cough, shortness of breath and breathing difficulties and in rare cases, respiratory distress.
                                </p>

                            </Col>
                            <Col md={6}>
                                <img src={whatiscovid} id="covidimg" alt="covid"></img>
                            </Col>
                        </Row>
                    </Container>
                </div>
                <ToastContainer autoClose={2000} />
            </div>

            {/* //Newsletter CTA Section */}


        </div>
    );
}

export default Home;