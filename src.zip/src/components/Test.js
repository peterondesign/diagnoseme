import React, { Component } from "react";

import { connect } from "react-redux";
import { fetchFeaturedTests } from "../actions";
import { Row, Card, Col, Tabs, Tab } from 'react-bootstrap';
import TestCard from './TestCard/TestCard'
import TestImage1 from '../assets/images/TestImage1.jpg';
import { Link } from "react-router-dom";
import TestDetailsModalToggle from './Modal/TestDetailsModalToggle';
import EmptyStateTest from '../assets/images/emptystate_testcard.svg'

class Test extends Component {
  componentDidMount() {
    this.props.fetchFeaturedTests();
  }

  render() {
    return (
      <React.Fragment>
        {this.props.showTests ? (
          Object.values(this.props.tests.data).map(row => {
            return (
              <Col md={4} key={row.id}>
                <TestCard
                  images={row.file}
                  testName={row.title}
                  description={
                    row.description
                  }
                  price={row.price}
                  sample={row.sample_required}
                  why={row.why_get_tested}
                  test_for={row.test_for}
                  testId={row.id}
                  is_bundle={row.is_bundle}
                  tat={row.tat}
                  label={"Buy Tests"}
                />
              </Col>
            );
          })
        ) : (
            <div>
              <Row id="emptystatetests">
                <Col md={4} className="text-center">
                  <img src={EmptyStateTest} id="emptystatetest"></img>
                </Col>
                <Col md={4} className="text-center">
                  <img src={EmptyStateTest} id="emptystatetest"></img>
                </Col>
                <Col md={4} className="text-center">
                  <img src={EmptyStateTest} id="emptystatetest"></img>
                </Col>
              </Row>
            </div>
          )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return { tests: state.tests.allTests, showTests: state.tests.showTests };
};

export default connect(mapStateToProps, { fetchFeaturedTests })(Test);
