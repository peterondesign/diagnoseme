import React, { Component } from "react";
import {  Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import DebugSentry from '../apis/DebugSentry';



class CookieMessage extends Component {
    
    state = {
        messagePosition: null,

    }

    constructor(props) {
        super(props);
    
        DebugSentry.instantiate();
      }
    
      componentDidCatch(error, errorInfo) {
        DebugSentry.catchException(error, errorInfo);
      }

    IAcceptCookies = () => {
        localStorage.setItem('cookiesAccepted', '!!34588774637fgdgdhj..eeeeee')
        this.setState({ messagePosition: !this.state.messagePosition })
    }

    renderClass = (messagePosition) => {
        if (messagePosition === null) return '';
        if (messagePosition === true) return 'slide-down-custom';
    }

    render() {
        const getCookie = localStorage.getItem('cookiesAccepted')
        console.log('lo',getCookie)
        return (
            <>
            { getCookie !== '!!34588774637fgdgdhj..eeeeee' ?

            <div className={"cookie-message-container " + this.renderClass(this.state.messagePosition)}>
                <Container>
                    <Row className="cookie-message-content">
                        <div className="w-75 center-on-mobile">
                            <p className="my-auto cookie-message-statement">We use cookies to provide website functionality and personalize content. Our <Link className="text-white" to="/privacy"><b><u>Privacy Notice</u></b></Link> provides more information on data, privacy and your browsing experience</p>
                        </div>
                        <div className="my-auto center-horizontal-on-mobile" onClick={() => this.IAcceptCookies()}>
                            <div className="my-auto btn cookie-message-button">
                                Accept Cookies
                        </div>
                        </div>
                    </Row>
                </Container>
            </div>
            : '' } </>
        );
    }
}


export default CookieMessage;
