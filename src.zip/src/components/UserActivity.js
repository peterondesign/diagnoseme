import React from "react";
import DebugSentry from '../apis/DebugSentry';



class UserActivity extends React.Component {
  constructor(props) {
    super(props);

    this.state = { logginStatus: true };
    this.events = [
      "load",
      "mousemove",
      "mousedown",
      "click",
      "scroll",
      "keypress"
    ];

    this.logout = this.logout.bind(this);
    this.resetTimeout = this.resetTimeout.bind(this);

    for (var i in this.events) {
      window.addEventListener(this.events[i], this.resetTimeout);
    }

    this.setTimeout();
    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  clearTimeout() {
    if (this.warnTimeout) clearTimeout(this.warnTimeout);
    if (this.logoutTimeout) clearTimeout(this.logoutTimeout);
  }

  setTimeout() {
    this.warnTimeout = setTimeout(this.warn, 210 * 1000);

    this.logoutTimeout = setTimeout(this.logout, 850 * 1000);
  }
  resetTimeout() {
    this.clearTimeout();
    this.setTimeout();
  }

  warn() {
    console.log("You will be logged out automatically soon.");
  }


  logout() {
    // Send a logout request to the API
    console.log("Sending a logout request to the API...");
    localStorage.removeItem('user')
    alert('Sorry, we had to log you out due to inactivity. You will be required to log in again to resume. Click OK to Continue')
    this.setState({ logginStatus: false });
    this.destroy(); // Cleanup
    window.location.href = "/"
  }

  destroy() {
    this.clearTimeout();

    for (var i in this.events) {
      window.removeEventListener(this.events[i], this.resetTimeout);
    }
  }
  render() {
    return (
      <div className="App">
        
      </div>
    );
  }
}

export default UserActivity
