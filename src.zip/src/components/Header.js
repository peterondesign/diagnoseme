import React, { Component } from 'react';
import { NavDropdown } from 'react-bootstrap';
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import MobileHeader from './MobileHeader';
import MediaQuery from 'react-responsive';
import Cart from './Cart'

import Logo from '../assets/images/diagnoseme_logo.svg'
import '../css/Header.css';
// import Cart from './Cart'
import { Container, Row, Col, Badge } from 'react-bootstrap';
import Sticky from 'react-sticky-el';
import DebugSentry from '../apis/DebugSentry';


class MenuLinks extends React.Component {

  constructor(props) {
    super(props);
    // Only when a user is NOT logged in
    this.state = {
      links: [
      // {
      //   text: 'Buy Tests',
      //   link: '/buytests',
      // }, 
      {
        text: 'For Providers',
        link: '/providers',
      }, 
      {
        text: 'Help',
        link: '/help',
      }]
    }
    DebugSentry.instantiate();
  }
  render() {
    const user = localStorage.getItem('user')

    let links = this.state.links.map((link, i) => <div className="menu-item-desktop" activeClassName="header-active" ref={i + 1}><NavLink to={link.link} className="menu-item-desktop" activeClassName="header-active">{link.text}</NavLink></div>);

    return (
          user == null ? <>
            {links}
          </> : <>
              {/* <div className="menu-item-desktop" activeClassName="header-active"><NavLink to="/buytests" className="menu-item-desktop" activeClassName="header-active">Buy Tests</NavLink></div> */}
              <div className="menu-item-desktop" activeClassName="header-active"><NavLink to="/order/myappointments" className="menu-item-desktop" activeClassName="header-active">My Appointments</NavLink></div>
              <div className="menu-item-desktop" activeClassName="header-active"><NavLink to="/help" className="menu-item-desktop" activeClassName="header-active">Help</NavLink></div>
            </>
    )
  }
}

class Header extends Component {
  state = {
    show: false
  }
  logout = () => {
    localStorage.removeItem('user')
    window.location.href = "/"
  }

  render() {
    const user = localStorage.getItem('user')
    return (
      <div>
        <Sticky className="sticky-header">

          <div className="bg-dark-blue">

            {/* Mobile Header Starts */}

            <MediaQuery maxDeviceWidth={1200}>
              <MobileHeader />
            </MediaQuery>

            {/* //Mobile Header Starts */}

            <MediaQuery minDeviceWidth={1200}>
              <Container>
                <Row>
                  <Col md={3}>
                    <NavLink to="/"><img src={Logo} className="header-logo" alt=""></img></NavLink>
                  </Col>

                  <Col md={6}>
                    <div className="menu-items-desktop">
                      <MenuLinks />
                    </div>
                  </Col>

                  <Col md={3}>
                    <div className="menu-items-desktop float-right justify-content-end">

                      {/* <NavLink to="/buytests">
                        <div className="menu-item-desktop search-icon">

                          <svg xmlns="http://www.w3.org/2000/svg" width="20.5875" height="18.85083" viewBox="0 0 24.705 22.621">
                            <g id="Group_198" data-name="Group 198" transform="translate(1.5 1.5)">
                              <g id="Icon_feather-search" data-name="Icon feather-search" transform="translate(0)">
                                <path id="Path_1" data-name="Path 1" d="M19.478,12.013A7.489,7.489,0,1,1,11.989,4.5,7.5,7.5,0,0,1,19.478,12.013Z" transform="translate(-4.5 -4.5)" fill="none" stroke="#f05f87" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                                <path id="Path_2" data-name="Path 2" d="M31.92,31.658l-6.945-6.683" transform="translate(-10.836 -12.658)" fill="none" stroke="#f05f87" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                              </g>
                            </g>
                          </svg>

                        </div>
                      </NavLink> */}
                      {
                        user == null ? <>
                          <div className="menu-item-desktop" activeClassName="header-active">
                            <NavLink to="/auth/login" className="menu-item-desktop" activeClassName="header-active">Login</NavLink>
                            <NavLink to="/auth/signup" className="menu-item-desktop" activeClassName="header-active">Create Account</NavLink>
                          </div>

                        </> : <>
                            <div className="menu-item-desktop" activeClassName="header-active">
                              <NavLink to="/account/dashboard" isActive={(match, location) => {
                                return location.pathname.includes("/account/");
                              }} className="menu-item-desktop" activeClassName="header-active">Dashboard
                          </NavLink>
                            </div>
                            <div className="menu-item-desktop dropdown-toggle" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span style={{ cursor: 'pointer' }} className="menu-item-desktop" activeClassName="header-active">{JSON.parse(user).first_name}</span> </div>
                            <div class="dropdown-menu login-dropdown" aria-labelledby="dropdownMenuLink">
                              <p class="dropdown-item" style={{ cursor: 'pointer' }} onClick={this.logout}>Logout</p>
                            </div>
                          </>
                      }
                    </div>
                  </Col>
                </Row>
              </Container>
            </MediaQuery>
          </div>
          <div style={{ position: 'absolute', zIndex: 99, opacity: 1 }}>
            {
              this.state.show ? <Cart /> : <div></div>
            }
          </div>
        </Sticky>
      </div>

    );
  }
}

const mapStateToProps = state => {
  return {
    cart: state.cart.cart
  };
};

export default connect(mapStateToProps, null)(Header);



