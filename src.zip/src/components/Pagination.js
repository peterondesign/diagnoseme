import React from 'react';

const Pagination = ({ testPerPage, totalTest, paginate }) => {
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(totalTest / testPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <nav>
      <ul className='pagination'>
        {pageNumbers.map(number => (
          <li key={number} className='page-item'>
            <div style={{ cursor:'pointer'}} onClick={() => paginate(number)} href='#' className='page-link'>
              {number}
            </div>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Pagination;
