import React, { Component } from "react";

import { connect } from "react-redux";
import { BannerTests } from "../actions";
import { Col, Container } from 'react-bootstrap';
import BannerCard from './TestCard/BannerCard'

import { BallPulseSync } from "react-pure-loaders";
import Carousel from 'react-bootstrap/Carousel';
import DebugSentry from '../apis/DebugSentry';

class Banner extends Component {
  componentDidMount() {
    this.props.BannerTests();
  }

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  render() {
    return (
      <React.Fragment>
        <Carousel  className="custom-carousel">
          {this.props.showBanners ? (
            Object.values(this.props.banners.data).map((row, i) => {
              return (


                <Carousel.Item key={i}>
                  <BannerCard
                    image={row.image}
                    images={row.image}
                    banner_description={
                      row.banner_description
                    }
                    description={
                      row.description
                    }
                    testId={row.test_id}
                    test={row.test}
                    price={row.price}
                    is_bundle={row.is_bundle}
                    tat={row.tat}
                    test_for={row.test_for}
                    why={row.why_get_tested}
                    sample={row.sample_required}
                    label={"Buy Tests"}
                  />
                </Carousel.Item>



              );
            })
          ) : (
              <Col md={12} className="text-center">
                <div className="text-center">
                  <BallPulseSync color={"#F05F87"} loading="true" />
                </div>
              </Col>
            )}
        </Carousel>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => {
  return { banners: state.banners.allBanners, showBanners: state.banners.showBanners };
};

export default connect(mapStateToProps, { BannerTests })(Banner);
