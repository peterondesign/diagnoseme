import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";
import { Container, Row, Col } from "react-bootstrap";

import { connect } from "react-redux";
import { login } from "./../../actions";

import "./../../css/Checkout.css";
import "./../../css/Auth.css";
import DebugSentry from "../../apis/DebugSentry";

class Login extends Component {

  state = {
    user: {},
    isSubmitted: false,
    inCorrectLogin: false,
    success: false,
    loading: false
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    if(localStorage.getItem('user') === null) {
      localStorage.removeItem('user')
    }
    
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleLogin = event => {
    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let email = event.target.email.value;
    let password = event.target.password.value;

    const user = {
      email,
      password
    };

    if (user.email && user.password) {
      this.promise = this.props.login(user);
      this.promise.catch(() => {}).then(() => {  this.setState({loading : false}) });
    }

  };

  render() {

    const { user, isSubmitted, loading } = this.state;

    const { response } = this.props.user;
    // const dog = undefined;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>

        <Container>
          {/* <button
          className="btn auth-button"
          onClick={() => {console.log(dog.colour)}}
          >Test Sentry</button> */}
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">
                <Row className="auth-links-card">
                  <div
                    className="nav col-md-12 auth-card-nav"
                    id="myTab"
                    role="tablist"
                  >
                     <Link className="order-line" to="/auth/login">
                    <div className="text-center register-nav2">
                     
                     Login
                     
                    </div>
                    </Link>
                    <Link className="order-line" to="/auth/signup">
                    <div className="text-center login-nav2">
                     
                        Sign up
                      
                    </div>
                    </Link>
                  </div>
                </Row>

                <form className="auth-form" onSubmit={this.handleLogin}>

                {response == null ? '' : response.data === "Account is currently Deactivated" ? <div>
                  <p className="account-deactivate-banner">Your account is currently deactivated. If you wish to re-activated your account, kindly contact support at hello@diagnosemeafrica.com</p>
                </div> : ""}
                

                  <p className="signup-h1">
                    Log in with your email address to continue
                  </p>

                  <div
                    className={
                      "form-group" +
                      (isSubmitted && !user.email ? " has-error" : "")
                    }
                  >
                    <label>Email address</label>
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      onChange={this.handleChange}
                    />
                    {isSubmitted && !user.email && (
                      <div className="help-block">
                        Email address is required
                      </div>
                    )}
                  </div>

                  <div
                    className={
                      "form-group" +
                      (isSubmitted && !user.password ? " has-error" : "")
                    }
                  >
                    <label>Password</label>
                    <input
                      type="password"
                      name="password"
                      className="form-control"
                      onChange={this.handleChange}
                    />
                    {isSubmitted && !user.password && (
                      <div className="help-block">Password is required</div>
                    )}
                  </div>

                  <p className=" text-right">
                    <Link
                      className="forgot-password"
                      to="/auth/forgot_password"
                    >
                      forgot password?
                    </Link>
                  </p>

                  <button
                    type="submit"
                    className="btn auth-button"
                    disabled={loading}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing</span>}
                    {!loading && <span>Login</span>}
                    
                  </button>
                  <hr />
                  <p className="">
                    <Link className="forgot-password" to="/auth/signup">
                      Create a new account
                    </Link>
                  </p>
                </form>
              </div>
            </Col>
          </Row>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = state => {  
  return { 
    user: state.user,
  };
};

export default connect(mapStateToProps, { login })(Login);
