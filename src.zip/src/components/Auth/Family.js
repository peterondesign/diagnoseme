import React from "react";
import { Row, Col} from "react-bootstrap";
import "react-toastify/dist/ReactToastify.css";

const Family = () => {
  return (
    <div className="family-member-section">
      <h6 className="family-member-header">
        Enter Information for family member
      </h6>
      <hr className="family-member-hr" />
      <Row>
        <Col md={6}>
          <div
            className={
              "form-group"
            }
          >
            <label>
              First Name<span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="first_name"
              required
              className="form-control"
            />
          </div>
        </Col>

        <Col md={6}>
          <div
            className={
              "form-group"
            }
          >
            <label>
              Last Name<span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="last_name"
              className="form-control"
            />
          </div>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <div
            className={
              "form-group"
            }
          >
            <label>
              Gender
              <span className="red-asterisk">*</span>
            </label>
            <select
              name="gender"
              id="gender"
              className="form-control"
            >
              <option value="" selected="selected">
                - Select -
              </option>

              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
        </Col>

        <Col md={6}>
          <div
            className={
              "form-group"
            }
          >
            <label>
              Date of birth<span className="red-asterisk">*</span>
            </label>
            <input
              type="date"
              name="dob"
              className="form-control"
            />
          </div>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <div
            className={
              "form-group"
            }
          >
            <label>
              Email address <span className="red-asterisk">*</span>
            </label>
            <input
              type="email"
              name="email"
              className="form-control"
            />
          </div>
        </Col>

        <Col md={6}>
          <div
            className={
              "form-group" 
            }
          >
            <label>
              Passport Number
              <span className="red-asterisk">*</span>
            </label>
            <input
              type="text"
              name="passport_number"
              className="form-control"
            />
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default Family;