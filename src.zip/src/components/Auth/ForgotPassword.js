import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Alert } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";

import { connect } from "react-redux";
import { forgotPassword } from "./../../actions";
import DebugSentry from "../../apis/DebugSentry";

import "./../../css/Checkout.css";
import "./../../css/Auth.css";

class ForgotPassword extends Component {
  state = {
    user: {},
    isSubmitted: false,
    inCorrectLogin: false,
    success: false,
    loading: false
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleLogin = event => {
    this.setState({
      isSubmitted: true,
      loading: true
    });

    event.preventDefault();

    let email = event.target.email.value;

    const user = {
      email,
    };

    if (user.email) {
      this.promise = this.props.forgotPassword(user);
      this.promise.catch(() => {}).then(() => {  this.setState({loading : false}) });
    }
  };

  render() {
    const response = this.props.user;
    console.log(response);
    
    const { user, isSubmitted, loading } = this.state;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt="" />

        <Container>
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">

                <form className="auth-form" onSubmit={this.handleLogin}>
                  <p className="signup-h1">Forgot password?</p>

                  <div
                    className={
                      "form-group" +
                      (isSubmitted && !user.email ? " has-error" : "")
                    }
                  >
                    <label>Email address</label>
                    <input
                      type="email"
                      name="email"
                      placeholder="Enter email address to help us identify you"
                      className="form-control"
                      onChange={this.handleChange}
                    />
                    {isSubmitted && !user.email && (
                      <div className="help-block">
                        Email address is required
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="btn auth-button"
                    disabled={loading}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing</span>}
                    {!loading && <span>Send Password Reset to My Email</span>}
                    
                  </button>
                  <hr />
                  <p className="">
                    <Link className="forgot-password" to="/auth/login">
                      Have an account? Log in
                    </Link>
                  </p>
                </form>
              </div>
            </Col>
          </Row>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { user: state.user };
};

export default connect(mapStateToProps, { forgotPassword })(ForgotPassword);
