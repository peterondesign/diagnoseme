import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../../assets/images/bgelementsHomepage.svg";
import VerificationFailed from "../../../assets/images/verification/VerificationFailed.svg";
import { Container, Row, Col } from "react-bootstrap";

import { connect } from "react-redux";
import { login } from "../../../actions";

class Login extends Component {
    state = {
        user: {},
        isSubmitted: false,
    }

    render() {
        const { user, isSubmitted } = this.state;

        return (
            <div className="bg-transparent">
                <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
                <Container>
                    <Row className="mx-auto panel">
                        <Col md={10} className="card auth-card mx-auto padding-verification">
                            <div className="text-center-mobile">
                                <img src={VerificationFailed} alt="VerificationFailed"></img>
                            </div>
                            <div className="title-header text-center-mobile pb-0">
                                Verification Failed
                                </div>
                            <div className="body-text text-center-mobile">
                                There was an error verifying your email.
                                    <br></br>
                                    Please enter your email address to request a new verification email.
                                </div>
                            <div className="body-text text-center-mobile">
                                <div
                                    className={
                                        "form-group" +
                                        (isSubmitted && !user.email ? " has-error" : "")
                                    }
                                >
                                    <label>Enter your email address</label>
                                    <input
                                        type="email"
                                        name="email"
                                        className="form-control"
                                        onChange={this.handleChange}
                                    />
                                    {isSubmitted && !user.email && (
                                        <div className="help-block">
                                            Email address is required
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="text-center-mobile">
                                <Link to="/auth/login">
                                    <button className="btn homepage-text-primary-button text-center w-100 d-block">
                                        Resend Verification Email
                                        </button>
                                </Link>
                            </div>
                        </Col>
                    </Row>
                </Container>
                <ToastContainer autoClose={2000} />
            </div >
        );
    }
}

const mapStateToProps = state => {
    return {
        user: state.user,
    };
};

export default connect(mapStateToProps, { login })(Login);
