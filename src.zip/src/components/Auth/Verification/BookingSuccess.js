import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../../assets/images/bgelementsHomepage.svg";
import VerificationSuccess from "../../../assets/images/verification/VerificationSuccess.svg";
import { Container, Row, Col } from "react-bootstrap";


const BookingSuccess = () => {
    return (
        <div className="bg-transparent">
            <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
                <Container>
                    <Row className="mx-auto panel">
                        <Col md={10} className="card auth-card mx-auto padding-verification">
                            <div className="text-center-mobile">
                                <img src={VerificationSuccess} alt="VerificationSuccess"></img>
                            </div>
                            <div className="title-header text-center-mobile pb-0">
                                Thank you for booking an appointment for your COVID-19 test.
                            </div>
                            <div className="body-text text-center-mobile">
                                In a few moments, you'll receive an email to complete the process.
                            </div>
                        </Col>
                    </Row>
                </Container>
            <ToastContainer autoClose={2000} />
        </div >
    );
}

export default BookingSuccess;