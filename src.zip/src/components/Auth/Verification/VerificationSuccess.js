import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../../assets/images/bgelementsHomepage.svg";
import VerificationSuccess from "../../../assets/images/verification/VerificationSuccess.svg";
import { Container, Row, Col } from "react-bootstrap";

import { connect } from "react-redux";
import { login } from "../../../actions";

class Login extends Component {

    render() {

        return (
            <div className="bg-transparent">
                <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
                    <Container>
                        <Row className="mx-auto panel">
                            <Col md={10} className="card auth-card mx-auto padding-verification">
                                <div className="text-center-mobile">
                                    <img src={VerificationSuccess} alt="VerificationSuccess"></img>
                                </div>
                                <div className="title-header text-center-mobile pb-0">
                                    Your account has been successfully verified.
                                </div>
                                <div className="body-text text-center-mobile">
                                    In a few moments, you'll be prompted to log in.
                                    
                                    <br></br>

                                    If you are not asked to log in, you can click the button below
                                </div>
                                <div className="text-center-mobile">
                                    <Link to="/auth/login">
                                        <button className="btn homepage-text-primary-button text-center verify-button d-block">
                                            Log in
                                        </button>
                                    </Link>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                <ToastContainer autoClose={2000} />
            </div >
        );
    }
}

const mapStateToProps = state => {
    return {
        user: state.user,
    };
};

export default connect(mapStateToProps, { login })(Login);
