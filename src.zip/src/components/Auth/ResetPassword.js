import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";

import { connect } from "react-redux";
import { checkResetPasswordToken, resetPassword } from "../../actions";

import "./../../css/Checkout.css";
import "./../../css/Auth.css";
import DebugSentry from "../../apis/DebugSentry";

class ResetPassword extends Component {
  state = {
    user: {},
    isSubmitted: false,
    inCorrectLogin: false,
    success: false,
    validated: false
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    const { handle } = this.props.match.params;
    if (handle) {
      this.props.checkResetPasswordToken(handle);
    }
    this.setState({
      validated : true
    })
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleChangePassword = event => {
    this.setState({
      isSubmitted: true
    });

    event.preventDefault();

    let email = event.target.email.value;
    let password = event.target.password.value;
    let token = event.target.token.value;
    

    const user = {
      email,
      password,
      token
    };

    console.log(user);
  
    if (user) {
      this.props.resetPassword(user);
    }
  };

  render() {
    const response = this.props.user.response;
    console.log(response);

    const { user, isSubmitted } = this.state;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>

        <Container>
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">
              {response && response.success ? (
                  <form className="auth-form" onSubmit={this.handleChangePassword}>
                    <p className="signup-h1">Reset your password</p>
                    <input name="email" hidden value={response.data.email}/>
                    <input name="token" hidden value={response.data.token}/>
                    <div
                      className={
                        "form-group" +
                        (isSubmitted && !user.password ? " has-error" : "")
                      }
                    >
                      <label>Enter Password</label>
                      <input
                        type="password"
                        name="password"
                        className="form-control"
                        onChange={this.handleChange}
                      />
                      {isSubmitted && !user.password && (
                        <div className="help-block">
                          Password is required
                        </div>
                      )}
                    </div>

                    <div
                      className={
                        "form-group" +
                        (isSubmitted && !user.confirm_password ? " has-error" : "")
                      }
                    >
                      <label>Confirm your Password</label>
                      <input
                        type="password"
                        name="confirm_password"
                        className="form-control"
                        onChange={this.handleChange}
                      />
                      {isSubmitted && !user.confirm_password && (
                        <div className="help-block">
                          You must provide a password confirmation
                        </div>
                      )}
                    </div>

                    <button type="submit" className="btn auth-button">
                      Reset Password
                    </button>
                    <hr />
                    <p className="">
                      <Link className="forgot-password" to="/auth/login">
                        Have an account? Log in
                      </Link>
                    </p>
                  </form>
                ): (
                  <h4>Invalid Link</h4>
                )}
              </div>
            </Col>
          </Row>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { user: state.user };
};

export default connect(mapStateToProps, { checkResetPasswordToken, resetPassword })(
  ResetPassword
);
