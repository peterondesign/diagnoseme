import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Alert } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PhoneInput from "react-phone-input-2";
import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";
import Family from "./Family";

import { connect } from "react-redux";
import { bookReturneeAppointment } from "./../../actions";
import DebugSentry from "../../apis/DebugSentry";

import "./../../css/Auth.css";
import countries from "./../../countries";

class ReturneeReferral extends Component {
  state = {
    user: {},
    family: {},
    familyArray: [],
    loading: false,
    isSubmitted: false,
    emailCheck: true,
    checkEmailInputTouched: false,
    success: false,
    error: [],
    phone: "",
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value,
      },
    });
  };

  handleNoPaste = (event) => {
    event.preventDefault();
    return false;
  };

  handleEmailCheck = (event) => {
    const { user, checkEmailInputTouched } = this.state;
    const { value } = event.target;

    if (user.email === value) {
      this.setState({
        emailCheck: true,
        checkEmailInputTouched: true,
      });
    } else {
      this.setState({
        emailCheck: false,
        checkEmailInputTouched: true,
      });
    }
  };

  handleCheckFamily = () => {
    let family = document.getElementById("family");
    let familySection = document.getElementById("family-member-plus");
    // let familyField = document.querySelector(".family-member-section");

    if (family.checked === true) {
      familySection.style.display = "block";
    } else {
      familySection.style.display = "none";
      // familyField.style.display = "none";
    }
  };

  handleSelectNumber = (event) => {
    const { value } = event.target;
    let number = Number(value);
    var data = Array(number).fill(0);

    this.setState({
      family: {
        set: true,
        number: value,
      },
      familyArray: data,
    });
  };

  handleButtonDisable = (emailCheck, loading) => {
    if (emailCheck || loading) {
      return true;
    }
    return false;
  };

  handleRegistration = (event) => {
    this.setState({
      isSubmitted: true,
      loading: true,
    });

    event.preventDefault();

    let first_name = event.target.first_name.value;
    let last_name = event.target.last_name.value;
    let name = first_name + " " + last_name;
    let email = event.target.email.value;
    let confirm_email = event.target.confirm_email.value;
    let flight_number = "";
    let gender = "";
    let address = "";
    let phone = "";
    let dob = "";
    let state_of_arrival = "";
    let country_of_departure = "";
    let date_of_arrival = "";
    let passport_number = "";

    const user = {
      name,
      first_name,
      last_name,
      confirm_email,
      email,
      phone,
      gender,
      dob,
      address,
      state_of_arrival,
      country_of_departure,
      date_of_arrival,
      passport_number,
      flight_number,
    };

    let data = [];

    let patient = {
        first_name,
        last_name,
        email,
        gender,
        dob,
        passport_number,
    };

    data.push(patient);

    const payload = {
        phone,
        address,
        state_of_arrival,
        country_of_departure,
        date_of_arrival,
        flight_number,
        family : data
    };

    console.log(payload);

    if (
      user.email
    ) {
      this.promise = this.props.bookReturneeAppointment(payload);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });
    } else {
      this.setState({
        loading: false,
      });
    }
  };

  render() {
    const { response } = this.props.user;

    const {
      user,
      family,
      familyArray,
      loading,
      isSubmitted,
      emailCheck,
      checkEmailInputTouched,
    } = this.state;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
        <Container>
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">
                <Row className="auth-links-card">
                  <div
                    class="nav col-md-12 auth-card-nav"
                    id="myTab"
                    role="tablist"
                  >
                    <Link className="order-line" to="/auth/login">
                      <div class="text-center register-nav2">
                        COVID-19 test pre-registration
                      </div>
                    </Link>
                  </div>
                </Row>

                <form
                  className="auth-form-new"
                  onSubmit={this.handleRegistration}
                >
                  <p className="booking-notice">
                    <i>
                      Please be reminded that this is a mandatory requirement by the Federal Government of Nigeria, in alignment with the Nigerian Centre for Disease Control,  for all travellers entering into Nigeria.
                    </i>
                  </p>
                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.email ? " has-error" : "")
                        }
                      >
                        <label>
                          Email address <span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="email"
                          name="email"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.email && (
                          <div className="help-block">
                            Email address is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.confirm_email
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Confirm Email address
                          <span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="email"
                          name="confirm_email"
                          className="form-control"
                          onChange={this.handleChange}
                          onInput={this.handleEmailCheck}
                          onPaste={this.handleNoPaste}
                        />
                        {isSubmitted && !user.confirm_email && (
                          <div className="help-block">
                            Re-enter email address is required
                          </div>
                        )}
                        {!emailCheck && checkEmailInputTouched && (
                          <div className="help-block">
                            Email address does not match
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.first_name ? " has-error" : "")
                        }
                      >
                        <label>
                          First Name<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="first_name"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.first_name && (
                          <div className="help-block">
                            First Name is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.last_name ? " has-error" : "")
                        }
                      >
                        <label>
                          Last Name<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="last_name"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.last_name && (
                          <div className="help-block">
                            Last Name is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <button
                    type="submit"
                    className="btn auth-button"
                    disabled={!this.handleButtonDisable(emailCheck, loading)}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing...</span>}
                    {!loading && <span>Submit</span>}
                  </button>
                </form>
              </div>
            </Col>
          </Row>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return { user: state.user };
};

export default connect(mapStateToProps, { bookReturneeAppointment })(ReturneeReferral);
