import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import PinInput from "react-pin-input";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PhoneInput from "react-phone-input-2";
import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";
import key_illustration from "../../assets/images/key_illustration.png";

import { connect } from "react-redux";
import { register, emailCheck, phoneCheck } from "./../../actions";

import "./../../css/Auth.css";
import DebugSentry from "../../apis/DebugSentry";

class Signup extends Component {
  state = {
    user: {},
    userDetails: [],
    isSubmitted: false,
    emailExist: false,
    phoneExist: false,
    emailCheck: false,
    checkEmailInputTouched: false,
    ageCheck: {
      check: false,
      message: ""
    },
    success: false,
    error: [],
    phone: "",
    toPin: false,
    myPin: 0,
    pinMessage: "",
    btnLabel: "Signup"
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleNoPaste = event => {
    event.preventDefault();
    return false;
  };

  handleEmailValidation = event => {
    const { value } = event.target;

    if (value) {
      this.props.emailCheck(value);
    }
  };

  handlePhoneValidation = phone => {
    if (phone) {
      this.props.phoneCheck(phone);
    }
  };

  handleEmailCheck = event => {
    const { user, checkEmailInputTouched } = this.state;
    const { value } = event.target;

    if (user.email === value) {
      this.setState({
        emailCheck: true,
        checkEmailInputTouched: true
      });
    } else {
      this.setState({
        emailCheck: false,
        checkEmailInputTouched: true
      });
    }
  };

  handleAgeCheck = event => {
    const { value } = event.target;

    if (value) {
      const dob = new Date(value).getFullYear();
      const year = new Date().getFullYear();
      const age = Number(year - dob);
      if (age >= 0 && age < 18) {
        this.setState({
          ageCheck: {
            check: false,
            message:
              "You must be 18 years old or above to create an account on DiagnoseMe"
          }
        });
      } else if (age < 0) {
        this.setState({
          ageCheck: {
            check: false,
            message: `Provided Year cannot exceed ${new Date().getFullYear()}`
          }
        });
      } else {
        this.setState({
          ageCheck: {
            check: true,
            message: ""
          }
        });
      }
    }
  };

  handleButtonDisable = (emailCheck, ageCheck, emailTaken, phoneTaken) => {
    if (emailCheck && ageCheck && !emailTaken && !phoneTaken) {
      return true;
    }
    return false;
  };

  goToPin = () => {
    this.setState({ toPin: true });
  };

  handleRegistration = event => {
    this.setState({
      isSubmitted: true
    });

    event.preventDefault();

    let first_name = event.target.first_name.value;
    let last_name = event.target.last_name.value;
    let name = first_name + " " + last_name;
    let email = event.target.email.value;
    let confirm_email = event.target.confirm_email.value;
    let password = event.target.password.value;
    let gender = event.target.gender.value;
    let phone = event.target.phone.value;
    let dob = event.target.dob.value;
    let state = event.target.state.value;

    const user = {
      name,
      first_name,
      last_name,
      email,
      password,
      phone,
      gender,
      dob,
      confirm_email,
      state
    };

    if (
      user.first_name &&
      user.last_name &&
      user.email &&
      user.password &&
      user.gender &&
      user.dob &&
      user.state &&
      user.phone
    ) {
      this.setState({
        toPin: true,
        userDetails: user,
        btnLabel: "Complete Signup",
        isSubmitted: false
      });
    }
  };

  passwordConfirmation = value => {
    if (this.state.myPin === value) {
      this.setState({ isSubmitted: true });
    } else {
      alert("Pin not match. Please try again");
    }
  };

  saveUserDetails = e => {
    e.preventDefault();
    this.setState({
      btnLabel: "Please wait .......",
      isSubmitted: false
    });
    const { userDetails, myPin } = this.state;
    userDetails.pin = myPin;
    if (
      userDetails.first_name &&
      userDetails.last_name &&
      userDetails.email &&
      userDetails.password &&
      userDetails.gender &&
      userDetails.dob &&
      userDetails.state &&
      userDetails.phone
    ) {
      this.props.register(userDetails);
    }
  };

  render() {
    const { response } = this.props.user;
    let emailTaken = null;
    let phoneTaken = null;
    if (response) {
      if (
        response.data === true &&
        response.message === "Email already exist"
      ) {
        emailTaken = response.data;
      }

      if (
        response.data === true &&
        response.message === "Phone number already exist"
      ) {
        phoneTaken = response.data;
      }
    }

    const {
      user,
      isSubmitted,
      emailCheck,
      ageCheck,
      toPin,
      checkEmailInputTouched
    } = this.state;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
        {toPin === false ? (
          <Container>
            <Row className="mx-auto panel">
              <Col md={8} className="card auth-card mx-auto">
                <div className="panel-header">
                  <Row className="auth-links-card">
                    <div
                      class="nav col-md-12 auth-card-nav"
                      id="myTab"
                      role="tablist"
                    >
                      <Link className="order-line" to="/auth/login">
                        <div class="text-center login-nav2">Login</div>
                      </Link>
                      <Link className="order-line" to="/auth/signup">
                        <div class="text-center register-nav2 ">Create an account</div>
                      </Link>
                    </div>
                  </Row>

                  <form
                    className="auth-form"
                    onSubmit={this.handleRegistration}
                  >
                    <p className="signup-h1">Create an account</p>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            ((isSubmitted && !user.email) || emailTaken
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>
                            Email address{" "}
                            <span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="email"
                            name="email"
                            className="form-control"
                            onChange={this.handleChange}
                            onInput={this.handleEmailValidation}
                          />
                          {isSubmitted && !user.email && (
                            <div className="help-block">
                              Email address is required
                            </div>
                          )}
                          {emailTaken && (
                            <div className="help-block">
                              Email address already exist{" "}
                              <Link
                                className="forgot-password"
                                to="/auth/login"
                              >
                              Log in
                              </Link>
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.confirm_email
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>
                            Confirm Email address
                            <span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="email"
                            name="confirm_email"
                            className="form-control"
                            onChange={this.handleChange}
                            onInput={this.handleEmailCheck}
                            onPaste={this.handleNoPaste}
                          />
                          {isSubmitted && !user.confirm_email && (
                            <div className="help-block">
                              Re-enter email address is required
                            </div>
                          )}
                          {!emailCheck && checkEmailInputTouched && (
                            <div className="help-block">
                              Email address does not match
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.first_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>
                            First Name<span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="text"
                            name="first_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.first_name && (
                            <div className="help-block">
                              First Name is required
                            </div>
                          )}
                        </div>
                      </Col>

                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.last_name ? " has-error" : "")
                          }
                        >
                          <label>
                            Last Name<span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="text"
                            name="last_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.last_name && (
                            <div className="help-block">
                              Last Name is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            ((isSubmitted && !user.phone) || phoneTaken
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>
                            Phone Number<span className="red-asterisk">*</span>
                          </label>
                          <PhoneInput
                            country="ng"
                            placeholder="Enter Phone Number"
                            enableSearch={true}
                            value={this.state.phone}
                            onChange={phone => {
                              this.setState({ phone });
                              this.handlePhoneValidation(phone);
                            }}
                            inputProps={{
                              name: "phone",
                              className: "form-control"
                            }}
                          />
                          {isSubmitted && !user.phone && (
                            <div className="help-block"></div>
                          )}
                          {phoneTaken && (
                            <div className="help-block">
                              Phone number already exist
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.dob ? " has-error" : "")
                          }
                        >
                          <label>
                            Date of birth<span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="date"
                            name="dob"
                            className="form-control"
                            onChange={this.handleChange}
                            onInput={this.handleAgeCheck}
                          />
                          {isSubmitted && !user.dob && (
                            <div className="help-block">
                              Date of birth is required
                            </div>
                          )}
                          {!ageCheck.check && (
                            <div className="help-block">{ageCheck.message}</div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.state ? " has-error" : "")
                          }
                        >
                          <label>
                            State of Residence
                            <span className="red-asterisk">*</span>
                          </label>
                          <select
                            name="state"
                            id="state"
                            className="form-control"
                            onChange={this.handleChange}
                          >
                            <option value="" selected="selected">
                              - Select -
                            </option>
                            <option value="Abia">Abia</option>
                            <option value="Adamawa">Adamawa</option>
                            <option value="Akwa Ibom">Akwa Ibom</option>
                            <option value="Anambra">Anambra</option>
                            <option value="Bauchi">Bauchi</option>
                            <option value="Bayelsa">Bayelsa</option>
                            <option value="Benue">Benue</option>
                            <option value="Borno">Borno</option>
                            <option value="Cross River">Cross River</option>
                            <option value="Delta">Delta</option>
                            <option value="Ebonyi">Ebonyi</option>
                            <option value="Edo">Edo</option>
                            <option value="Ekiti">Ekiti</option>
                            <option value="Enugu">Enugu</option>
                            <option value="FCT">FCT</option>
                            <option value="Gombe">Gombe</option>
                            <option value="Imo">Imo</option>
                            <option value="Jigawa">Jigawa</option>
                            <option value="Kaduna">Kaduna</option>
                            <option value="Kano">Kano</option>
                            <option value="Katsina">Katsina</option>
                            <option value="Kebbi">Kebbi</option>
                            <option value="Kogi">Kogi</option>
                            <option value="Kwara">Kwara</option>
                            <option value="Lagos">Lagos</option>
                            <option value="Nassarawa">Nassarawa</option>
                            <option value="Niger">Niger</option>
                            <option value="Ogun">Ogun</option>
                            <option value="Ondo">Ondo</option>
                            <option value="Osun">Osun</option>
                            <option value="Oyo">Oyo</option>
                            <option value="Plateau">Plateau</option>
                            <option value="Rivers">Rivers</option>
                            <option value="Sokoto">Sokoto</option>
                            <option value="Taraba">Taraba</option>
                            <option value="Yobe">Yobe</option>
                            <option value="Zamfara">Zamfara</option>
                            <option value="Outside Nigeria">
                              Outside Nigeria
                            </option>
                          </select>
                          {isSubmitted && !user.state && (
                            <div className="help-block">
                              State of Residence is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.gender ? " has-error" : "")
                          }
                        >
                          <label>
                            Biological Sex<span className="red-asterisk">*</span>
                          </label>
                          <br />
                          <label>
                            <input
                              className="radio-form"
                              name="gender"
                              type="radio"
                              value="Male"
                              onChange={this.handleChange}
                            />
                            Male
                          </label>
                          <label>
                            <input
                              className="radio-form"
                              name="gender"
                              type="radio"
                              value="Female"
                              onChange={this.handleChange}
                            />
                            Female
                          </label>
                          {isSubmitted && !user.gender && (
                            <div className="help-block">Gender is required</div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.password ? " has-error" : "")
                          }
                        >
                          <label>
                            Password<span className="red-asterisk">*</span>
                          </label>
                          <input
                            type="password"
                            minlength="6"
                            name="password"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.password && (
                            <div className="help-block">
                              Password is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group d-flex" +
                            (isSubmitted && !user.terms ? " has-error" : "")
                          }
                        >
                          <br />
                          <label for="terms" className="terms-check">
                            <input
                              className="checkbox-form"
                              name="terms"
                              type="checkbox"
                              required
                              id="terms"
                              value="I Agree to Terms"
                              onChange={this.handleChange}
                            />
                            <p
                              style={{
                                paddingTop: "10px",
                                paddingLeft: "10px"
                              }}
                            >
                              Check here to indicate that you have read and
                              agreed to the
                              <a href="/terms" target="_blank">
                                {" "}
                                Terms and Conditions
                              </a>
                            </p>
                          </label>

                          {isSubmitted && !user.terms && (
                            <div className="help-block">
                              You need to agree to our terms and conditions
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <button
                      type="submit"
                      className="btn auth-button"
                      disabled={
                        !this.handleButtonDisable(
                          emailCheck,
                          ageCheck.check,
                          emailTaken,
                          phoneTaken
                        )
                      }
                    >
                      Sign Up
                    </button>
                    <hr />
                    <p className="">
                      <Link className="forgot-password" to="/auth/login">
                        Have an account? Log in
                      </Link>
                    </p>
                  </form>
                </div>
              </Col>
            </Row>
          </Container>
        ) : (
          <Container>
            <Row className="mx-auto panel">
              <Col md={8} className="card auth-card mx-auto">
                <div className="panel-header">
                  <form className="auth-form" onSubmit={this.saveUserDetails}>
                    <h6 className="">Set your Result Password</h6>

                    <Row>
                      <Col md={12} style={{ padding: "0px" }}>
                        <div>
                          <img
                            src={key_illustration}
                            className="img-responsive mx-auto d-block key-illustrator"
                            alt=""
                          />
                        </div>
                      </Col>
                      <Col md={12}>
                        <p>
                        To access your results and sensitive information on
                          your account, a Result Password is required (4-digit Number). If you forget your
                          Result Password, you can recover from your dashboard.
                        </p>
                      </Col>
                    </Row>

                    <Row className="pin-row">
                      <div className="enter-pin-label">
                        <p>
                          Enter Pin
                        </p>
                      </div>
                      <br />
                      <div className="enter-pin-block">
                      <PinInput
                        length={4}
                        initialValue=""
                        secret
                        onChange={(value, index) => {}}
                        type="numeric"
                        style={{ marginLeft: "80px" }}
                        inputStyle={{ borderColor: "red", marginLeft: "10px" }}
                        inputFocusStyle={{ borderColor: "blue" }}
                        onComplete={(value, index) => {
                          this.setState({ myPin: value });
                        }}
                      />
                      </div>
                    </Row>
                    <Row className="pin-row">
                    <div className="enter-pin-label">
                        <p>
                          Confirm Pin
                        </p>
                      </div>
                      <br />
                      <div className="enter-pin-block">
                      <PinInput
                        length={4}
                        initialValue=""
                        secret
                        onChange={(value, index) => {}}
                        type="numeric"
                        style={{ marginLeft: "57px" }}
                        inputStyle={{ borderColor: "red", marginLeft: "10px" }}
                        inputFocusStyle={{ borderColor: "blue" }}
                        onComplete={(value, index) => {
                          this.passwordConfirmation(value);
                        }}
                      />
                      </div>
                      
                    </Row>
                    <Row className="pin-row">
                    <button
                      type="submit"
                      className="btn auth-button d-block pull-right"
                      id="pin-btn"
                      disabled={!this.state.isSubmitted}
                    >
                      {this.state.btnLabel}
                    </button>
                    </Row>
                    <hr />
                    <p className="">
                      <Link className="forgot-password" to="/auth/login">
                        Have an account? Log in
                      </Link>
                    </p>
                  </form>
                </div>
              </Col>
            </Row>
          </Container>
        )}
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return { user: state.user };
};

export default connect(mapStateToProps, { register, emailCheck, phoneCheck })(
  Signup
);
