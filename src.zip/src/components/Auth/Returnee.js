import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";
import { Container, Row, Col, Alert } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PhoneInput from "react-phone-input-2";
import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";
import Family from "./Family";

import { connect } from "react-redux";
import { bookReturneeAppointment } from "./../../actions";

import "./../../css/Auth.css";
import countries from "./../../countries";
import DebugSentry from "../../apis/DebugSentry";

class Returnee extends Component {
  state = {
    user: {},
    family: {},
    familyArray: [],
    loading: false,
    isSubmitted: false,
    emailCheck: true,
    checkEmailInputTouched: false,
    success: false,
    error: [],
    phone: "",
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value,
      },
    });
  };

  handleNoPaste = (event) => {
    event.preventDefault();
    return false;
  };

  handleEmailCheck = (event) => {
    const { user, checkEmailInputTouched } = this.state;
    const { value } = event.target;

    if (user.email === value) {
      this.setState({
        emailCheck: true,
        checkEmailInputTouched: true,
      });
    } else {
      this.setState({
        emailCheck: false,
        checkEmailInputTouched: true,
      });
    }
  };

  handleCheckFamily = () => {
    let family = document.getElementById("family");
    let familySection = document.getElementById("family-member-plus");
    // let familyField = document.querySelector(".family-member-section");

    if (family.checked === true) {
      familySection.style.display = "block";
    } else {
      familySection.style.display = "none";
      // familyField.style.display = "none";
    }
  };

  handleSelectNumber = (event) => {
    const { value } = event.target;
    let number = Number(value);
    var data = Array(number).fill(0);

    this.setState({
      family: {
        set: true,
        number: value,
      },
      familyArray: data,
    });
  };

  handleButtonDisable = (emailCheck, loading) => {
    if (!emailCheck || loading) {
      return true;
    }
    return false;
  };

  handleRegistration = (event) => {
    this.setState({
      isSubmitted: true,
      loading: true,
    });

    event.preventDefault();

    let first_name = event.target.first_name.value;
    let last_name = event.target.last_name.value;
    let name = first_name + " " + last_name;
    let email = event.target.email.value;
    let confirm_email = event.target.confirm_email.value;
    let flight_number = event.target.flight_number.value;
    let gender = event.target.gender.value;
    let address = event.target.address.value;
    let phone = event.target.phone.value;
    let dob = event.target.dob.value;
    let state_of_arrival = event.target.state_of_arrival.value;
    let country_of_departure = event.target.country_of_departure.value;
    let date_of_arrival = event.target.date_of_arrival.value;
    let passport_number = event.target.passport_number.value;
    let company_id = event.target.company_id.value;
    let sample_collection_center = event.target.sample_collection_center.value;

    const user = {
      name,
      first_name,
      last_name,
      confirm_email,
      email,
      phone,
      gender,
      dob,
      address,
      state_of_arrival,
      country_of_departure,
      date_of_arrival,
      passport_number,
      flight_number,
      company_id,
      sample_collection_center,
    };

    let data = [];

    let number = this.state.family.number

    let count = Number(number);

    let patient = {
        first_name,
        last_name,
        email,
        gender,
        dob,
        passport_number,
    };

    data.push(patient);

    if(count > 0 ){

        let first_name_1 = event.target.first_name_1.value;
        let last_name_1 = event.target.last_name_1.value;
        let dob_1 = event.target.dob_1.value;
        let gender_1 = event.target.gender_1.value;
        let passport_number_1 = event.target.passport_number_1.value;
        let email_1 = event.target.email_1.value;

        patient = {
            first_name: first_name_1,
            last_name: last_name_1,
            email: email_1,
            gender: gender_1,
            dob: dob_1,
            passport_number: passport_number_1
        };
        
        data.push(patient);

    }

    if (count > 1) {

        let first_name_2 = event.target.first_name_2.value;
        let last_name_2 = event.target.last_name_2.value;
        let dob_2 = event.target.dob_2.value;
        let gender_2 = event.target.gender_2.value;
        let passport_number_2 = event.target.passport_number_2.value;
        let email_2 = event.target.email_2.value;

        patient = {
            first_name: first_name_2,
            last_name: last_name_2,
            email: email_2,
            gender: gender_2,
            dob: dob_2,
            passport_number: passport_number_2
        };

        data.push(patient);
        
    }

    if (count > 2) {
        
        let first_name_3 = event.target.first_name_3.value;
        let last_name_3 = event.target.last_name_3.value;
        let dob_3 = event.target.dob_3.value;
        let gender_3 = event.target.gender_3.value;
        let passport_number_3 = event.target.passport_number_3.value;
        let email_3 = event.target.email_3.value;

        patient = {
            first_name: first_name_3,
            last_name: last_name_3,
            email: email_3,
            gender: gender_3,
            dob: dob_3,
            passport_number: passport_number_3
        };

        data.push(patient);

    }

    if (count > 3) {

        let first_name_4 = event.target.first_name_4.value;
        let last_name_4 = event.target.last_name_4.value;
        let dob_4 = event.target.dob_4.value;
        let gender_4 = event.target.gender_4.value;
        let passport_number_4 = event.target.passport_number_4.value;
        let email_4 = event.target.email_4.value;

        patient = {
            first_name: first_name_4,
            last_name: last_name_4,
            email: email_4,
            gender: gender_4,
            dob: dob_4,
            passport_number: passport_number_4
        };

        data.push(patient);

    }

    if (count > 4) {
        
        let first_name_5 = event.target.first_name_5.value;
        let last_name_5 = event.target.last_name_5.value;
        let dob_5 = event.target.dob_5.value;
        let gender_5 = event.target.gender_5.value;
        let passport_number_5 = event.target.passport_number_5.value;
        let email_5 = event.target.email_5.value;

        patient = {
            first_name: first_name_5,
            last_name: last_name_5,
            email: email_5,
            gender: gender_5,
            dob: dob_5,
            passport_number: passport_number_5
        };

        data.push(patient);

    }

    // for (let index = 0; index < count; index++) {
        
    //     let patient = {
    //         first_name: first_name_1,
    //         last_name: last_name_1,
    //         email: email_1,
    //         gender: gender_1,
    //         dob: dob_1,
    //         passport_number: passport_number_1
    //       };

    //       data.push(patient);

    // }

    const payload = {
        phone,
        address,
        state_of_arrival,
        country_of_departure,
        date_of_arrival,
        flight_number,
        company_id,
        sample_collection_center,
        family : data
    };

    if (
      user.flight_number
    ) {
      this.promise = this.props.bookReturneeAppointment(payload);
      this.promise
        .catch(() => {})
        .then(() => {
          this.setState({ loading: false });
        });
    } else {
      this.setState({
        loading: false,
      });
    }
  };

  render() {
    const { response } = this.props.user;
    const { state } = this.props;
    const {
      user,
      family,
      familyArray,
      loading,
      isSubmitted,
      emailCheck,
      checkEmailInputTouched,
    } = this.state;

    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
        <Container>
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">
                <Row className="auth-links-card">
                  <div
                    class="nav col-md-12 auth-card-nav"
                    id="myTab"
                    role="tablist"
                  >
                    <Link className="order-line" to="/auth/login">
                      <div class="text-center register-nav2">
                        Book a COVID-19 test appointment
                      </div>
                    </Link>
                  </div>
                </Row>

                <form
                  className="auth-form-new"
                  onSubmit={this.handleRegistration}
                >
                  <p className="booking-notice">
                    <i>
                      Please be reminded that this is a mandatory requirement by the Federal Government of Nigeria, in alignment with the Nigerian Centre for Disease Control,  for all travellers entering into Nigeria.
                    </i>
                  </p>
                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.email ? " has-error" : "")
                        }
                      >
                        <label>
                          Email address <span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="email"
                          name="email"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.email && (
                          <div className="help-block">
                            Email address is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.confirm_email
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Confirm Email address
                          <span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="email"
                          name="confirm_email"
                          className="form-control"
                          onChange={this.handleChange}
                          onInput={this.handleEmailCheck}
                          onPaste={this.handleNoPaste}
                        />
                        {isSubmitted && !user.confirm_email && (
                          <div className="help-block">
                            Re-enter email address is required
                          </div>
                        )}
                        {!emailCheck && checkEmailInputTouched && (
                          <div className="help-block">
                            Email address does not match
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.first_name ? " has-error" : "")
                        }
                      >
                        <label>
                          First Name<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="first_name"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.first_name && (
                          <div className="help-block">
                            First Name is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.last_name ? " has-error" : "")
                        }
                      >
                        <label>
                          Last Name<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="last_name"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.last_name && (
                          <div className="help-block">
                            Last Name is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div className={"form-group"}>
                        <label>
                          Phone Number<span className="red-asterisk">*</span>
                        </label>
                        <PhoneInput
                          country="ng"
                          placeholder="Enter Phone Number"
                          enableSearch={true}
                          value={this.state.phone}
                          onChange={(phone) => {
                            this.setState({ phone });
                          }}
                          inputProps={{
                            name: "phone",
                            className: "form-control",
                          }}
                        />
                        {/* {isSubmitted && !user.phone && (
                            <div className="help-block">Phone number is required</div>
                          )} */}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.dob ? " has-error" : "")
                        }
                      >
                        <label>
                          Date of birth<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="date"
                          name="dob"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.dob && (
                          <div className="help-block">
                            Date of birth is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.gender ? " has-error" : "")
                        }
                      >
                        <label>
                          Gender
                          <span className="red-asterisk">*</span>
                        </label>
                        <select
                          name="gender"
                          id="gender"
                          className="form-control"
                          onChange={this.handleChange}
                        >
                          <option value="" selected="selected">
                            - Select -
                          </option>

                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                        {isSubmitted && !user.gender && (
                          <div className="help-block">Gender is required</div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.date_of_arrival
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Date of arrival<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="date"
                          name="date_of_arrival"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.date_of_arrival && (
                          <div className="help-block">
                            Date of birth is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={12}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.address ? " has-error" : "")
                        }
                      >
                        <label>
                          Address<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="address"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        <input
                          type="hidden"
                          name="company_id"
                          defaultValue={this.props.state.company_id}
                          className="form-control"
                          onChange={this.handleChange}
                        />
                         <input
                          type="hidden"
                          name="sample_collection_center"
                          defaultValue={this.props.state.smaple_collection_center}
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.address && (
                          <div className="help-block">Address is required</div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.country_of_departure
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Country of Departure
                          <span className="red-asterisk">*</span>
                        </label>
                        <select
                          name="country_of_departure"
                          id="country_of_departure"
                          className="form-control"
                          onChange={this.handleChange}
                        >
                          <option value="" selected="selected">
                            - Select -
                          </option>
                          {countries.map(function (country) {
                            return (
                              <option value={country.name}>
                                {country.name}
                              </option>
                            );
                          })}
                        </select>
                        {isSubmitted && !user.country_of_departure && (
                          <div className="help-block">
                            Country of Departure is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.state_of_arrival
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          City of Arrival
                          <span className="red-asterisk">*</span>
                        </label>
                        
                        <select
                          name="state_of_arrival"
                          id="state_of_arrival"
                          className="form-control"
                          onChange={this.handleChange}
                        >
                          {/* <option value="" selected="selected">
                            - Select -
                          </option> */}
                          { this.props.state.name.toLowerCase() === 'abuja' ? 
                          <option value={`FCT`}>{this.props.state.name}</option>
                        : <option value={this.props.state.name}>{this.props.state.name}</option>
                        }
                          
                          {/* <option value="FCT">FCT</option>
                          <option value="Lagos">Lagos</option>
                          <option value="Rivers">Rivers</option> */}
                        </select>
                        {isSubmitted && !user.state_of_arrival && (
                          <div className="help-block">
                            State of Arrival is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.flight_number
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Flight Number<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="flight_number"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.flight_number && (
                          <div className="help-block">
                            Flight Number is required
                          </div>
                        )}
                      </div>
                    </Col>

                    <Col md={6}>
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.passport_number
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Passport Number<span className="red-asterisk">*</span>
                        </label>
                        <input
                          type="text"
                          name="passport_number"
                          className="form-control"
                          onChange={this.handleChange}
                        />
                        {isSubmitted && !user.passport_number && (
                          <div className="help-block">
                            Passport Number is required
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={12}>
                      <div className={"form-group d-flex"}>
                        <br />
                        <label for="terms" className="terms-check">
                          <input
                            className="checkbox-form"
                            name="family"
                            type="checkbox"
                            id="family"
                            value="Yes"
                            onClick={this.handleCheckFamily}
                          />
                          <p
                            style={{
                              paddingTop: "10px",
                              paddingLeft: "10px",
                            }}
                          >
                            If you'd like to book a test for your family member(s) please click here
                          </p>
                        </label>
                      </div>
                    </Col>
                    <Col md={12} id="family-member-plus">
                      <div
                        className={
                          "form-group" +
                          (isSubmitted && !user.state_of_arrival
                            ? " has-error"
                            : "")
                        }
                      >
                        <label>
                          Number of family members
                          <span className="red-asterisk">*</span>
                        </label>
                        <select
                          name="number_of_family"
                          id="number_of_family"
                          className="form-control"
                          onChange={this.handleSelectNumber}
                        >
                          <option value="" selected="selected">
                            - Select -
                          </option>

                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                        </select>
                      </div>
                    </Col>
                  </Row>

                  {family &&
                    family.set &&
                    familyArray.map((item, key) => {
                      return (
                        <div className="family-member-section">
                          <h6 className="family-member-header">
                            Enter Information for family member {key + 1}
                          </h6>
                          <hr className="family-member-hr" />
                          <Row>
                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  First Name
                                  <span className="red-asterisk">*</span>
                                </label>
                                <input
                                  type="text"
                                  name={`first_name_${key + 1}`}
                                  onChange={this.handleChange}
                                  className="form-control"
                                />
                              </div>
                            </Col>

                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  Last Name
                                  <span className="red-asterisk">*</span>
                                </label>
                                <input
                                  type="text"
                                  name={`last_name_${key + 1}`}
                                  onChange={this.handleChange}
                                  className="form-control"
                                />
                              </div>
                            </Col>
                          </Row>

                          <Row>
                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  Gender
                                  <span className="red-asterisk">*</span>
                                </label>
                                <select
                                  name={`gender_${key + 1}`}
                                  onChange={this.handleChange}
                                  className="form-control"
                                >
                                  <option value="" selected="selected">
                                    - Select -
                                  </option>

                                  <option value="Male">Male</option>
                                  <option value="Female">Female</option>
                                </select>
                              </div>
                            </Col>

                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  Date of birth
                                  <span className="red-asterisk">*</span>
                                </label>
                                <input
                                  type="date"
                                  name={`dob_${key + 1}`}
                                  onChange={this.handleChange}
                                  className="form-control"
                                />
                              </div>
                            </Col>
                          </Row>

                          <Row>
                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  Email address{" "}
                                  <span className="red-asterisk">*</span>
                                </label>
                                <input
                                  type="email"
                                  name={`email_${key + 1}`}
                                  value={user && user.email}
                                  onChange={this.handleChange}
                                  className="form-control"
                                />
                              </div>
                            </Col>

                            <Col md={6}>
                              <div className={"form-group"}>
                                <label>
                                  Passport Number
                                  <span className="red-asterisk">*</span>
                                </label>
                                <input
                                  type="text"
                                  name={`passport_number_${key + 1}`}
                                  onChange={this.handleChange}
                                  className="form-control"
                                />
                              </div>
                            </Col>
                          </Row>
                        </div>
                      );
                    })}

                  <button
                    type="submit"
                    className="btn auth-button"
                    disabled={this.handleButtonDisable(emailCheck, loading)}
                  >
                    {loading && (
                      <i
                        className="fa fa-refresh fa-spin"
                        style={{ marginRight: "5px" }}
                      />
                    )}
                    {loading && <span>Processing...</span>}
                    {!loading && <span>Submit</span>}
                  </button>
                </form>
              </div>
            </Col>
          </Row>
        </Container>
        <ToastContainer autoClose={2000} />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return { user: state.user };
};

export default connect(mapStateToProps, { bookReturneeAppointment })(Returnee);
