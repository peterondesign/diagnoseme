import React, { Component } from "react";
import { NavLink as Link } from "react-router-dom";

import bgelementsHomepage from "../../assets/images/bgelementsHomepage.svg";
import { Container, Row, Col } from "react-bootstrap";

import { connect } from "react-redux";
import { login } from "./../../actions";

import "./../../css/Checkout.css";
import "./../../css/Auth.css";
import DebugSentry from "../../apis/DebugSentry";

class Verify extends Component {
  state = {
    user: null
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }
  

  render() {
    return (
      <div className="bg-transparent">
        <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>

        <Container>
          <Row className="mx-auto panel">
            <Col md={8} className="card auth-card mx-auto">
              <div className="panel-header">
                <h4>Verification Successful</h4>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.user
  };
};

export default connect(mapStateToProps, { login })(Verify);
