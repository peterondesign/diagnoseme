import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import Accordion from "react-bootstrap/Accordion";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import PhoneInput from "react-phone-input-2";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "react-phone-input-2/lib/style.css";
import "../css/Home.css";
import HomepageImageProvider from "../assets/images/homepageImageProvider.jpg";
import PersonalisedTreatmentsImage from "../assets/images/PersonalisedTreatmentsImage.png";
import bgelementsHomepage from "../assets/images/bgelementsHomepage.svg";
import SignupProvider from "../assets/images/SignupProvider.png";
import PlaceholderIcon from "../assets/images/placeholdericon.svg";
import ImprovedDiagnostics from "../assets/images/improved_diagnostics.svg";
import Carecoordination from "../assets/images/care_co-ordination.svg";
import PersonalizedPortal from "../assets/images/personalized_portal.svg";
import MediaQuery from "react-responsive";

import { HashLink as HashLink } from 'react-router-hash-link';

import DebugSentry from '../apis/DebugSentry';
import { connect } from "react-redux";
import { registerProvider } from "./../actions/provider";

class Providers extends Component {
  state = {
    user: {},
    isSubmitted: false,
    success: false,
    phone: "",
    faqHide: "d-none",
    hideButton: "d-block homepage-text-outline-button mx-auto"
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  changeClassName = newName => {
    this.setState({
      faqHide: newName,
      hideButton: "d-none"
    });
  };

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleRegister = event => {
    this.setState({
      isSubmitted: true
    });

    event.preventDefault();

    let first_name = event.target.first_name.value;
    let last_name = event.target.last_name.value;
    let email = event.target.email.value;
    let phone = event.target.phone.value;
    let hospital_name = event.target.hospital_name.value;
    let role = event.target.role.value;

    const user = {
      first_name,
      last_name,
      email,
      phone,
      hospital_name,
      role
    };

    console.log(user);


    if (
      user.first_name &&
      user.last_name &&
      user.email &&
      user.phone &&
      user.hospital_name &&
      user.role
    ) {
      this.props.registerProvider(user);
    }
  };

  render() {
    const { user, isSubmitted, phone } = this.state;

    const { faqHide, hideButton } = this.state;

    return (
      <div>
        <div className="section-padding">
          <Container>
            {/* Homepage Section */}

            <Row>
              <Col md={6} className="homepage-text-group">
                <div className="homepage-text-group-box">
                  <div className="homepage-text-main-copy">
                    Are you new to the DiagnoseMe platform?
                  </div>
                  <div className="homepage-text-sub-copy">
                    Gain access to our seamless, secure web portal to order your diagnostics tests. Create a free Provider account and order tests across a range of conditions including: cancers, autoimmune and hormonal disorders, viral and bacterial infections, vitamin deficiencies, allergies, and more.
                  </div>
                  <div className="homepage-text-buttons">

                    {/* <a href="#providersignup" className="homepage-text-primary-button" style={{ padding: "15px 40px" }}>
                      Sign up to begin ordering
                      </a> */}
                    <HashLink smooth to="/providers#signup" className="homepage-text-primary-button" style={{ padding: "15px 40px" }}>
                      Sign up to begin ordering
                    </HashLink>
                    <div className="homepage-text-secondary-button">
                    </div>
                    {/* <div className="homepage-text-secondary-button">
                      <Link to="/" className="homepage-text-secondary-button">
                        <svg
                          className="ml-2 mr-2"
                          xmlns="http://www.w3.org/2000/svg"
                          width="18.233"
                          height="2"
                          viewBox="0 0 18.233 2"
                        >
                          <path
                            id="StraightLine"
                            d="M47.233,0H29"
                            transform="translate(-29 1)"
                            fill="none"
                            stroke="#6473a8"
                            stroke-width="2"
                          />
                        </svg>
                        View All Tests
                      </Link>
                    </div> */}
                  </div>
                  <MediaQuery minDeviceWidth={990}>
                    <a
                      href="https://provider.diagnosemeafrica.com/"
                      target="_blank"
                      className="homepage-text-secondary-button mt-3"
                    >
                      <svg
                        className="mr-2"
                        xmlns="http://www.w3.org/2000/svg"
                        width="18.233"
                        height="2"
                        viewBox="0 0 18.233 2"
                      >
                        <path
                          id="StraightLine"
                          d="M47.233,0H29"
                          transform="translate(-29 1)"
                          fill="none"
                          stroke="#6473a8"
                          strokeWidth="2"
                        />
                      </svg>
                        Already have an account? Login
                      </a>
                  </MediaQuery>
                  <MediaQuery maxDeviceWidth={990}>
                    <a
                      href="https://provider.diagnosemeafrica.com/"
                      target="_blank"
                      className="mx-auto text-center homepage-text-secondary-button"
                    >
                      Already have an account? Login
                      </a>
                  </MediaQuery>
                </div>
              </Col>

              <Col md={6} className="d-none d-lg-block">
                <img
                  src={bgelementsHomepage}
                  id="bgelementsHomepage"
                  alt="Background Elements"
                />
                <img
                  src={HomepageImageProvider}
                  id="HomepageImage"
                  alt="Homepage Image"
                />
              </Col>
            </Row>
          </Container>
        </div>

        {/* //Homepage Section */}

        {/* Personalised Tests Section */}

        {/* <div className="bg-light-greyblue">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={6}>
                  <img
                    src={PersonalisedTreatmentsImage}
                    id="PersonalisedTreatmentsImage"
                    alt="Personalised Treatments"
                  ></img>
                </Col>

                <Col md={6} className="homepage-text-group">
                  <div className="about-diagnoseme-text-group">
                    <div className="title-header text-center-mobile">
                      Personalized treatment at your fingertips.
                    </div>
                    <div className="homepage-text-sub-copy">
                      Create a free Provider account and order tests across a range of conditions including: cancers, autoimmune and hormonal disorders, viral and bacterial infections, vitamin deficiencies, allergies, and more.
                    </div>
                    <div className="text-center-mobile">
                      <a
                        href="http://provider.diagnoseme.africa:8001/"
                        target="_blank"
                        className="homepage-text-secondary-button"
                      >
                        <svg
                          className="mr-2"
                          xmlns="http://www.w3.org/2000/svg"
                          width="18.233"
                          height="2"
                          viewBox="0 0 18.233 2"
                        >
                          <path
                            id="StraightLine"
                            d="M47.233,0H29"
                            transform="translate(-29 1)"
                            fill="none"
                            stroke="#6473a8"
                            strokeWidth="2"
                          />
                        </svg>
                        Login to the Portal
                      </a>
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </Container>
        </div> */}

        {/* //Personalised Tests Section */}

        {/* Contact CTA Section */}

        <div className="bg-darkblue">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={12}>
                  <p
                    className="newsletter-text text-center"
                    style={{ fontSize: "18px" }}
                  >
                    Call us <b> <a href="tel:+2347003424667363" style={{ color: "white" }}>0700DIAGNOSEME (+234 700 342 466 7363)</a></b> to help with setting up
                    your account
                  </p>
                </Col>
              </Row>
            </div>
          </Container>
        </div>

        {/* //Contact CTA Section */}

        {/* What you get Section */}

        <div className="bg-white">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={12}>
                  <p className="title-header text-center">What you get</p>
                </Col>

                <Col md={4}>
                  <div className="What-you-get text-center text-center">
                    <div>
                      <img
                        src={ImprovedDiagnostics}
                        id="Placeholdericon"
                        alt="ImprovedDiagnostics"
                      ></img>
                    </div>
                    <div className="homepage-text-sub-copy text-center">
                      <b>Precision</b>
                    </div>
                    <div className="homepage-text-sub-copy text-center What-you-get-text">
                      We are improving outcomes for patients in Africa through the delivery of precision diagnostics
                    </div>
                  </div>
                </Col>

                <Col md={4}>
                  <div className="What-you-get text-center">
                    <div>
                      <img
                        src={Carecoordination}
                        id="Placeholdericon"
                        alt="CareCoordination"
                      ></img>
                    </div>
                    <div className="homepage-text-sub-copy text-center">
                      <b>Reliable Service</b>
                    </div>
                    <div className="homepage-text-sub-copy text-center What-you-get-text">
                      We combine our expertise with best-in-class laboratory equipment to provide reliable testing services
                    </div>
                  </div>
                </Col>

                <Col md={4}>
                  <div className="What-you-get text-center">
                    <div>
                      <img
                        src={PersonalizedPortal}
                        id="Placeholdericon"
                        alt="PersonalizedPortal"
                      ></img>
                    </div>
                    <div className="homepage-text-sub-copy text-center">
                      <b>Prompt Delivery</b>
                    </div>
                    <div className="homepage-text-sub-copy text-center What-you-get-text">
                      Specialists tests are done locally, enabling quick turnaround times for improved outcomes
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </Container>
        </div>

        {/* //What you get Section */}

        {/* Sign up as a Provider Section */}
        <div className="bg-grey-gradient section-padding" style={{ paddingTop: "65px" }} id="signup" name="signup">
          <Container>
            <Row>
              <Col md={5} className="homepage-text-group">
                <div className="about-diagnoseme-text-group">
                  <div className="title-header text-center-mobile">
                    Sign up, get approved, start ordering
                  </div>
                  <Form onSubmit={this.handleRegister}>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.email ? " has-error" : "")
                          }
                        >
                          <label>Email address</label>
                          <input
                            type="email"
                            name="email"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.email && (
                            <div className="help-block">
                              Email address is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.first_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>First Name</label>
                          <input
                            type="text"
                            name="first_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.first_name && (
                            <div className="help-block">
                              First Name is required
                            </div>
                          )}
                        </div>
                      </Col>

                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.last_name ? " has-error" : "")
                          }
                        >
                          <label>Last Name</label>
                          <input
                            type="text"
                            name="last_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.last_name && (
                            <div className="help-block">
                              Last Name is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name ? " has-error" : "")
                          }
                        >
                          <label>Hospital Name</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            placeholder="What hospital or laboratory are you associated with?"
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Hospital name is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.role ? " has-error" : "")
                          }
                        >
                          <label>Role</label>

                          <Form.Control
                            as="select"
                            name="role"
                            onChange={this.handleChange}
                            placeholder="What is your role"
                          >
                            <option></option>
                            <option>Doctor</option>
                            <option>Nurse</option>
                            <option>Lab Scientist</option>
                            <option>Pharmacist</option>
                            <option>Hospital Administrator</option>
                          </Form.Control>
                          {isSubmitted && !user.role && (
                            <div className="help-block">
                              Your Role is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !phone ? " has-error" : "")
                          }
                        >
                          <label>Phone Number</label>
                          <PhoneInput
                            country="ng"
                            placeholder="Enter Phone Number"
                            enableSearch={true}
                            value={this.state.phone}
                            onChange={phone => this.setState({ phone })}
                            inputProps={{
                              name: "phone",
                              className: "form-control"
                            }}
                          />
                          {isSubmitted && !phone && (
                            <div className="help-block">
                              Phone number is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Button className="btn-custom-pink" type="submit">
                      Contact me for verification
                    </Button>
                  </Form>
                </div>
              </Col>
              <Col md={7}>
                <img src={SignupProvider} id="AboutImage" alt=""></img>
              </Col>
            </Row>
          </Container>
        </div>

        {/* //Sign up as a Provider Section */}

        {/* FAQ on Homepage Section */}

        <div className="bg-white">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={12}>
                  <p className="mt-3 mb-1 pt-3 pb-1 title-header text-center-desktop">
                    Frequently Asked Questions
                  </p>
                </Col>
                <div className="faq-on-homepage">
                  <Accordion defaultActiveKey="0">
                    <Card>
                      <Accordion.Toggle as={Card.Header} eventKey="1">
                        <p className="body-text-blue">
                          What are the opening hours at DiagnoseMe?{" "}
                        </p>
                      </Accordion.Toggle>
                      <Accordion.Collapse eventKey="1">
                        <Card.Body>
                          <div className="body-text">
                            <ul>
                              <li>
                                We are not a walk-in lab. However our dispatch
                                riders will visit your hospital to pick up
                                samples between 9am - 4pm.
                              </li>
                            </ul>
                          </div>
                        </Card.Body>
                      </Accordion.Collapse>
                    </Card>
                    <Card>
                      <Accordion.Toggle as={Card.Header} eventKey="2">
                        <p className="body-text-blue">
                          What services are rendered by DiagnoseMe?
                        </p>
                      </Accordion.Toggle>
                      <Accordion.Collapse eventKey="2">
                        <Card.Body>
                          <div className="body-text">
                            <ul>
                              <li>
                              Our test services are currently offered in the areas of COVID-19 and clinical chemistry. We will be expanding our test menu to cover other areas in the coming weeks.</li>
                            </ul>
                          </div>
                        </Card.Body>
                      </Accordion.Collapse>
                    </Card>
                    <Card>
                      <Accordion.Toggle as={Card.Header} eventKey="3">
                        <p className="body-text-blue">
                          Can my sample be rejected?
                        </p>
                      </Accordion.Toggle>
                      <Accordion.Collapse eventKey="3">
                        <Card.Body>
                          <div className="body-text">
                            <ul>
                              <li>
                                Yes, your sample can be rejected if it does not meet our criteria for sample integrity. Please view our SOP for more information (available on request/sign up)
                              </li>
                            </ul>
                          </div>
                        </Card.Body>
                      </Accordion.Collapse>
                    </Card>

                    <Card>
                      <Accordion.Toggle as={Card.Header} eventKey="4">
                        <p className="body-text-blue">
                          What number can I call to make enquiries?
                        </p>
                      </Accordion.Toggle>
                      <Accordion.Collapse eventKey="4">
                        <Card.Body>
                          <div className="body-text">
                            <ul>
                              <li>Please call 0700DIAGNOSEME (+234 700 342 466 7363)</li>
                            </ul>
                          </div>
                        </Card.Body>
                      </Accordion.Collapse>
                    </Card>

                    <div className={faqHide}>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="5">
                          <p className="body-text-blue">
                            How can I be assured that test results are of the
                            highest standards?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="5">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Our principal aim is to consistently provide
                                  quality service to our clients, this is
                                  achieved by our world class equipped
                                  laboratory that complies with ISO15189
                                  standards.
                                </li>
                                <li>
                                  All laboratory processes are automated thus
                                  reducing laboratory processing time, with less
                                  exposure to human errors.
                                </li>
                                <li>
                                  Our laboratory personnel are fully trained
                                  across various specialties, they are also
                                  certified in good laboratory practice and the
                                  Nigerian health ethics code.
                                </li>
                                <li>
                                  We participate in all relevant technical
                                  External Quality Assurance (EQA) schemes,
                                  which are used to ensure the quality of all
                                  our procedures.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="6">
                          <p className="body-text-blue">
                            How do I register on the DiagnoseMe provider portal?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="6">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Please give us your information as specified
                                  on the website and a DiagnoseMe representative
                                  will be in touch with you.
                                </li>
                                <li>
                                  We may require some documentation before your
                                  account will be activated.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="7">
                          <p className="body-text-blue">
                            I forgot my password. How do I reset it?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="7">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Click the ‘forgot my password’ button below
                                  the provider login page
                                </li>
                                <li>
                                  Enter the email address you used when you
                                  opened your account. Click submit.
                                </li>
                                <li>
                                  A link to reset your password will be sent to
                                  the registered email on your account.
                                </li>
                                <li>Click on the link in your email.</li>
                                <li>Enter and confirm your new password.</li>
                                <li>
                                  Log in to your account using your email and
                                  new password.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="8">
                          <p className="body-text-blue">
                            Will I be notified when my results are ready?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="8">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Yes, you will receive an email notification as
                                  soon as your results are ready.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="9">
                          <p className="body-text-blue">
                            I don’t see my result notifications in my email?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="9">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Depending on your email settings, our
                                  notification may have ended up in your spam
                                  folder or junk email.
                                </li>
                                <li>
                                  If the turnaround time for delivery of your
                                  results has elapsed, you may also view your
                                  results on your dashboard.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="10">
                          <p className="body-text-blue">
                            Are all results for the test requested available on
                            DiagnoseMe portal?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="10">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Yes they are. Please log in with your admin
                                  details.
                                </li>
                                <li>All results will be on the portal.</li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="11">
                          <p className="body-text-blue">
                            Will results be ready at the same time?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="11">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Test results have different turnaround times.
                                </li>
                                <li>
                                  You will receive notifications via email as
                                  each result becomes availabl
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      {/* <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="12">
                          <p className="body-text-blue">
                            Is DiagnoseMe Provider portal free?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="12">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Yes, the portal is free for all DiagnoseMe
                                  clients, all you need to do is register and
                                  start ordering tests.
                                </li>
                                <li>
                                  However, your bill will be sent monthly for
                                  tests ordered via our portal.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card> */}
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="13">
                          <p className="body-text-blue">
                            How will I be billed?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="13">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  You will receive a bill in your email on a
                                  postpaid monthly basis. Our invoices are
                                  generally issued on the 1st of the month for
                                  tests ordered in the previous month.
                                </li>
                                <li>
                                  Kindly refer to our SOP for more information
                                  about our credit policy and payment due dates.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="14">
                          <p className="body-text-blue">
                            How can I pay my bill?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="14">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  You can make payments via bank transfer
                                  (preferable) or cheque.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="15">
                          <p className="body-text-blue">What is TAT?</p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="15">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  TAT is an acronym, it stands for: Turn Around
                                  Time.
                                </li>
                                <li>
                                  Turn around time is the time it takes to
                                  complete a test or investigation from when the
                                  sample was received in the Laboratory.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="16">
                          <p className="body-text-blue">
                            Is my information confidential?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="16">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Any information given to us is confidential,
                                  including your test results.
                                </li>
                                <li>
                                  Your personal information will only be used to
                                  order tests.
                                </li>
                                <li>
                                  Please see our privacy policy for more
                                  information on this.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="18">
                          <p className="body-text-blue">
                            How secure is my data?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="18">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  We use a heavily secure, state of the art cloud architecture system. Our data is fully encrypted, and is rendered useless outside of our system. Reliable access control ensures that only authorised personnel have access to the information they require and we also keep a log of IP addresses that access our information. Multiple brute force access attempts will be flagged from external IPs which are then blocked.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="19">
                          <p className="body-text-blue">
                            How soon can I get the results to the tests I have ordered?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="19">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  Each test type has its own peculiar turn around time indicated on the portal.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="20">
                          <p className="body-text-blue">
                            How do I receive my patient’s results?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="20">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  When your report(s) is/are ready, you will receive an email to view your report details on your dashboard
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                      <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="17">
                          <p className="body-text-blue">
                            Where and how can I lodge a complaint?
                          </p>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="17">
                          <Card.Body>
                            <div className="body-text">
                              <ul>
                                <li>
                                  To lodge a complaint, please send an email to
                                  hello@diagnosemeafrica.com or call 0700DIAGNOSEME (+234 700 342 466 7363) and a DiagnoseMe
                                  representative will respond to your queries.
                                </li>
                              </ul>
                            </div>
                          </Card.Body>
                        </Accordion.Collapse>
                      </Card>
                    </div>
                  </Accordion>
                </div>
              </Row>

              <Col md={6} className="mx-auto mt-4 mb-3 pt-4 pb-3">
                <div className="mx-auto text-center">
                  <Button
                    onClick={() => this.changeClassName("d-block")}
                    className={hideButton}
                  >
                    View All FAQs
                  </Button>
                </div>
              </Col>
            </div>
          </Container>
        </div>

        {/* //FAQ Section */}

        {/* Newsletter CTA Section */}

        <div className="bg-darkblue">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={6}>
                  <p className="newsletter-text">
                    {" "}
                    Stay up to date with discounts, new tests and company news
                  </p>
                </Col>
                <Col md={6} className="my-auto">
                  <Form>
                    <div className="newsletter-box">
                      <Form.Control
                        type="email"
                        placeholder="Enter email address"
                        className="height-input-auto"
                      />
                      <Button
                        variant="primary"
                        className="btn-custom"
                        type="submit"
                        value="Submit"
                      >
                        <Link to="/" className="newsletter-button">
                          Subscribe
                        </Link>
                      </Button>
                    </div>
                  </Form>
                </Col>
              </Row>
            </div>
          </Container>
          <ToastContainer position="top-right"
            autoClose={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable />
        </div>

        {/* //Newsletter CTA Section */}
      </div>
    );
  }
}

const mapPropsToState = state => {
  return { provider: state.provider };
};

export default connect(mapPropsToState, { registerProvider })(Providers);
