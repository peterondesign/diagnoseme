import React from "react";
import "../css/Cart.css";
import shoppingcart_emptystate from "../assets/images/shopping_cart_emptystate.svg";
import { Col, Button, Row } from "react-bootstrap";
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import { PropTypes } from 'prop-types'
import { deleteFromCart , emptyCart } from '../actions/cart'
import DebugSentry from '../apis/DebugSentry';

const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2
})

class Cart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      leftOpen: true,
      rightOpen: true,
      show: true,
      opencart: "d-none",
    }

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  changeClassName = (newName) => {
    this.setState({
      opencart: newName,
    });
  };

  handleEmptyCart = () => {
    this.props.emptyCart();
  }
 
  componentDidMount() {
    document.addEventListener('mousedown', this.handleClickOutside);
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.handleClickOutside);
  }

  setWrapperRef = (node) => {
    this.wrapperRef = node;
  }

  handleClickOutside = (event) => {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      this.setState({ show: !this.state.show })
    }
  }

  toggleSidebar = event => {
    let key = `${event.currentTarget.parentNode.id}Open`;
    this.setState({ [key]: !this.state[key] });
  };

  handleCheckoutPage = () => {
    let newName = 'd-none';
    if (localStorage.getItem('user') === null) {
      localStorage.setItem('checkout', true);
      this.setState({
        opencart: newName,
      });
      window.location.href = '/auth/login'
      // this.props.history.push('/auth/login')
    } else {
      localStorage.setItem('checkout', false);
      this.setState({
        opencart: newName,
      });
      window.location.href = '/order/summary'
    }
  }


  render() {

    const { opencart } = this.state;
    const getUser = localStorage.getItem("user");

    // console.log('Cookies in cart page: ',getUser)

    let sumPrice = 0
    const { cart } = this.props
    console.log(cart.cart.length)
    let rightOpen = this.state.rightOpen ? "open" : "closed";
    const deleteFromCart = (id, price) => {
      this.props.deleteFromCart(id, price);
    }

    return (
      <div>

        <div id="opencart" className={opencart}>
          <div class="fade modal-backdrop show" onClick={() => this.changeClassName('d-none')} style={{ zIndex: 900 }}></div>
          <div className="cart-card-control">
            <div className="cart-card">
              <div className="cart-card-header">
                <div className="d-flex">
                  <svg id="Icon_feather-shopping-cart" data-name="Icon feather-shopping-cart" xmlns="http://www.w3.org/2000/svg" width="25.801" height="24.764" viewBox="0 0 25.801 24.764">
                    <path id="Path_70" data-name="Path 70" d="M14.073,31.036A1.036,1.036,0,1,1,13.036,30,1.036,1.036,0,0,1,14.073,31.036Z" transform="translate(-3.245 -8.808)" fill="none" stroke="#4a557d" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                    <path id="Path_71" data-name="Path 71" d="M30.573,31.036A1.036,1.036,0,1,1,29.536,30,1.036,1.036,0,0,1,30.573,31.036Z" transform="translate(-8.345 -8.808)" fill="none" stroke="#4a557d" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                    <path id="Path_72" data-name="Path 72" d="M1.5,1.5H5.646L8.423,15.377A2.073,2.073,0,0,0,10.5,17.046H20.57a2.073,2.073,0,0,0,2.073-1.669l1.658-8.7H6.682" fill="none" stroke="#4a557d" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                  </svg>
                  <p className="cart-text pl-3 pr-3 my-auto">{this.props.cart.cart.length} Item(s)</p>
                </div>

                {/* Close Modal Button */}
                <div onClick={() => this.changeClassName('d-none')}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="20.953" height="20.953" viewBox="0 0 20.953 20.953">
                    <path id="Icon_ionic-md-close" data-name="Icon ionic-md-close" d="M28.477,9.619l-2.1-2.1L18,15.9,9.619,7.523l-2.1,2.1L15.9,18,7.523,26.381l2.1,2.1L18,20.1l8.381,8.381,2.1-2.1L20.1,18Z" transform="translate(-7.523 -7.523)" fill="#7f7f7f" />
                  </svg>
                </div>
              </div>
              {/* //Close Modal Button */}

              {
                cart.cart.length > 0 &&
                <div className="empty-cart-padding">
                  <Link onClick={this.handleEmptyCart} class="empty-cart-btn pull-right">Empty Cart</Link>
                </div>
              }

              <div className="cart-items-padding">
                <div className="fixed-height-items">
                
                <h6> </h6>
                <hr></hr>
                {
                  cart.cart.map(item => {
                    sumPrice += parseInt(item.price)
                    return (
                      <React.Fragment>
                        <Row className="col-md-11 cart-items-no-padding">
                          <Col className="">
                            <h6 className="cart-test-name">{item.test}</h6>
                            <span className="cart-test-price">Price: ₦{parseInt(item.price).toLocaleString('us', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            <br></br>
                          </Col>
                          <Col className="col-md-1 cart-items-no-padding">
                            {/* <i className="text-danger" style={{ cursor: 'pointer' }} onClick={() => deleteFromCart(item.testId, item.price)}>remove</i> */}
                            <i class="fa fa-trash pull-right" aria-hidden="true" style={{ cursor: 'pointer', color: 'red' }} onClick={() => deleteFromCart(item.testId, item.price)}></i>
                          </Col>
                        </Row>
                        <hr></hr>
                      </React.Fragment>
                      
                    )
                  })
                }
                </div>
                <div className="row">
                </div>
                {
                  this.props.cart.cart.length > 0 ?

                    <div className="row cart-">
                      <div className="col-md-12" style={{ float: 'left' }}><div className="cart-test-price"><b>Total: ₦{parseInt(sumPrice).toLocaleString('us', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b></div>
                        <Link onClick={() => this.handleCheckoutPage()} className="cart-checkout-button">
                          <div className="col-md-12 cart-checkout-button-wrapper text-center">
                              <div className="text-center mx-auto">Checkout</div>
                          </div>
                        </Link>
                      </div>                        
                    </div> :
                    <div className="text-center d-flex flex-column order-row-dashboard">
                      <div><img src={shoppingcart_emptystate}  className="mt-3" alt="Empty Cart" id="EmptyCart"></img></div>
                      <div className="mt-3">Your cart is empty</div>
                      <Link to="/buytests" className="cart-text-primary-outline-button"><div onClick={() => this.changeClassName('d-none')}>Buy Tests</div></Link>
                    </div>

                }
              </div>
            </div>
            </div>
          </div>

          {/* Cart Button */}
          {
            this.props.cart.cart.length > 0 ?
              (
                <div className="cart-button" onClick={() => this.changeClassName('d-block')}>
                  <div className="d-flex">
                    <span>
                      <svg id="Icon_feather-shopping-cart" data-name="Icon feather-shopping-cart" xmlns="http://www.w3.org/2000/svg" width="25.801" height="24.764" viewBox="0 0 25.801 24.764">
                        <path id="Path_70" data-name="Path 70" d="M14.073,31.036A1.036,1.036,0,1,1,13.036,30,1.036,1.036,0,0,1,14.073,31.036Z" transform="translate(-3.245 -8.808)" fill="none" stroke="#f8f8f8" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                        <path id="Path_71" data-name="Path 71" d="M30.573,31.036A1.036,1.036,0,1,1,29.536,30,1.036,1.036,0,0,1,30.573,31.036Z" transform="translate(-8.345 -8.808)" fill="none" stroke="#f8f8f8" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                        <path id="Path_72" data-name="Path 72" d="M1.5,1.5H5.646L8.423,15.377A2.073,2.073,0,0,0,10.5,17.046H20.57a2.073,2.073,0,0,0,2.073-1.669l1.658-8.7H6.682" fill="none" stroke="#f8f8f8" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                      </svg>
                    </span>
                    <h6 className="pl-2 pr-0 my-auto text-white">{this.props.cart.cart.length}</h6>
                    <h6 className="item-text pl-2 pr-2 my-auto text-white">Item(s)</h6>
                  </div>
                </div>
              ) : null
          }
          {/* //Cart Button */}
        </div>
    );
  }
}
const mapStateToProps = state => {
  return {
          cart: state.cart,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
          deleteFromCart: (id, price) => { dispatch(deleteFromCart(id, price))},
          emptyCart: () => {dispatch(emptyCart())}
  }
}

Cart.propTypes = {
          leftOpen: PropTypes.bool,
  rightOpen: PropTypes.bool,
  cart: PropTypes.object,
  show: PropTypes.bool
}

export default connect(mapStateToProps, mapDispatchToProps)(Cart);


