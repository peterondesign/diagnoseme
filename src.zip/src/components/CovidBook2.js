import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import Accordion from "react-bootstrap/Accordion";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import PhoneInput from "react-phone-input-2";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "react-phone-input-2/lib/style.css";
import "../css/Home.css";
import HomepageImageProvider from "../assets/images/homepageImageProvider.jpg";
import bgelementsHomepage from "../assets/images/bgelementsHomepage.svg";
import SignupProvider from "../assets/images/SignupProvider.png";
import MediaQuery from 'react-responsive';
import pattern from '../assets/images/pattern.svg';
import qualitystatementmobile from '../assets/images/qualitystatementmobile.png';




import { connect } from "react-redux";
import { registerProvider } from "../actions/provider";

class Providers extends Component {
  state = {
    user: {},
    isSubmitted: false,
    success: false,
    phone: "",
    faqHide: "d-none",
    hideButton: "d-block homepage-text-outline-button mx-auto"
  };

  changeClassName = newName => {
    this.setState({
      faqHide: newName,
      hideButton: "d-none"
    });
  };

  handleChange = event => {
    const { name, value } = event.target;
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [name]: value
      }
    });
  };

  handleRegister = event => {
    this.setState({
      isSubmitted: true
    });

    event.preventDefault();

    let first_name = event.target.first_name.value;
    let last_name = event.target.last_name.value;
    let email = event.target.email.value;
    let phone = event.target.phone.value;
    let hospital_name = event.target.hospital_name.value;
    let role = event.target.role.value;

    const user = {
      first_name,
      last_name,
      email,
      phone,
      hospital_name,
      role
    };

    console.log(user);

    if (
      user.first_name &&
      user.last_name &&
      user.email &&
      user.phone &&
      user.hospital_name &&
      user.role
    ) {
      this.props.registerProvider(user);
    }
  };

  render() {
    const { user, isSubmitted, phone } = this.state;

    const { faqHide, hideButton } = this.state;

    return (
      <div>

        {/* Sign up as a Provider Section */}
        <div className="bg-covidbook section-padding" id="providersignup">
          <Container>
            <Row className="justify-content-between">
              <Col md={7} className="flip-on-mobile homepage-text-group book_card">
                <div className="about-diagnoseme-text-group">
                  <div className="title-header text-center-mobile">
                    Book A Test
                  </div>

                  <Form onSubmit={this.handleRegister}>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.email ? " has-error" : "")
                          }
                        >
                          <label>Email address</label>
                          <input
                            type="email"
                            name="email"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.email && (
                            <div className="help-block">
                              Email address is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.first_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>First Name</label>
                          <input
                            type="text"
                            name="first_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.first_name && (
                            <div className="help-block">
                              First Name is required
                            </div>
                          )}
                        </div>
                      </Col>

                      <Col md={6}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.last_name ? " has-error" : "")
                          }
                        >
                          <label>Last Name</label>
                          <input
                            type="text"
                            name="last_name"
                            className="form-control"
                            onChange={this.handleChange}
                          />
                          {isSubmitted && !user.last_name && (
                            <div className="help-block">
                              Last Name is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Home Address</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            placeholder="For Sample Collection purposes"
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Sample collection address is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !phone ? " has-error" : "")
                          }
                        >
                          <label>Phone Number</label>
                          <PhoneInput
                            country="ng"
                            placeholder="Enter Phone Number"
                            enableSearch={true}
                            value={this.state.phone}
                            onChange={phone => this.setState({ phone })}
                            inputProps={{
                              name: "phone",
                              className: "form-control"
                            }}
                          />
                          {isSubmitted && !phone && (
                            <div className="help-block">
                              Phone number is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Date of Birth</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Date of Birth is required
                            </div>
                          )}
                        </div>

                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Passport Number</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Passport Number is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Country of Depature</label>
                          <Form.Control
                            as="select"
                            name="role"
                            onChange={this.handleChange}
                            placeholder="Select Country"
                          >
                            <option></option>
                            <option>Ghana</option>
                            <option>England</option>
                            <option>United States of America</option>
                          </Form.Control>
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Country of Depature is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.role ? " has-error" : "")
                          }
                        >
                          <label>State of Arrival</label>

                          <Form.Control
                            as="select"
                            name="role"
                            onChange={this.handleChange}
                            placeholder="What is your role"
                          >
                            <option></option>
                            <option>Lagos</option>
                            <option>Abuja</option>
                            <option>Port Harcourt</option>
                          </Form.Control>
                          {isSubmitted && !user.role && (
                            <div className="help-block">
                              State of Arrival is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Date of Arrival</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Date of Arrival is required
                            </div>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Flight Number</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Flight Number is required
                            </div>
                          )}
                        </div>

                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        <div
                          className={
                            "form-group" +
                            (isSubmitted && !user.hospital_name
                              ? " has-error"
                              : "")
                          }
                        >
                          <label>Preferred Testing Date (kindly note that this may change due to availability)</label>
                          <input
                            type="text"
                            name="hospital_name"
                            onChange={this.handleChange}
                            className="form-control"
                          />
                          {isSubmitted && !user.hospital_name && (
                            <div className="help-block">
                              Passport Number is required
                            </div>
                          )}
                        </div>
                        <label><b>Operating Times: 8am - 3pm, Monday - Sat</b></label>
                      </Col>
                    </Row>

                    <Button className="btn-custom-pink W-100" type="submit">
                      Submit
                    </Button>
                  </Form>
                </div>
              </Col>
              <Col md={4} className="book_card">
                <div className="about-diagnoseme-text-group">
                  <div className="title-header title-header-sm text-center-mobile">
                    <p>(<i>Only applicable to <b>Passengers returning to Nigeria</b></i>)</p>
                    <p><i>Please be reminded that this is a mandatory requirement by the Federal Government of Nigeria, in alignment with the NCDC for all travellers entering into Nigeria</i></p>
                    <ol>
                      <li>
                        This form is required to schedule a COVID-19 testing appointment
                      </li>
                      <li>
                        Select your preferred booking date (kindly note that this may change due to availability)
                      </li>
                      <li>
                        After filling the form, you will receive a an appointment confirmation email to show at the airport
                      </li>
                      <li>
                        You will also be required to fill a case information form before sample collection
                      </li>
                    </ol>
                  </div>
                </div>
                <img src={pattern} id="pattern" alt="Quality Statement"></img>
              </Col>
            </Row>
          </Container>
        </div>

        {/* //Sign up as a Provider Section */}



        {/* Newsletter CTA Section */}

        <div className="bg-darkblue">
          <Container>
            <div className="section-padding">
              <Row>
                <Col md={6}>
                  <p className="newsletter-text">
                    {" "}
                    Stay up to date with discounts, new tests and company news
                  </p>
                </Col>
                <Col md={6} className="my-auto">
                  <Form>
                    <div className="newsletter-box">
                      <Form.Control
                        type="email"
                        placeholder="Enter email address"
                        className="height-input-auto"
                      />
                      <Button
                        variant="primary"
                        className="btn-custom"
                        type="submit"
                        value="Submit"
                      >
                        <Link to="/" className="newsletter-button">
                          Subscribe
                        </Link>
                      </Button>
                    </div>
                  </Form>
                </Col>
              </Row>
            </div>
          </Container>
          <ToastContainer autoClose={2000} />
        </div>

        {/* //Newsletter CTA Section */}
      </div>
    );
  }
}

const mapPropsToState = state => {
  return { provider: state.provider };
};

export default connect(mapPropsToState, { registerProvider })(Providers);
