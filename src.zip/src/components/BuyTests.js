import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { ToastContainer } from "react-toastify";
import { connect } from "react-redux";
import "react-toastify/dist/ReactToastify.css";
import { PropTypes } from "prop-types";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import "../css/BuyTests.css";
import bgelementsHomepage from "../assets/images/bgelementsHomepage.svg";
import TestCard from "./TestCard/TestCard";
import Pagination from './Pagination'
import { BallPulseSync } from "react-pure-loaders";
import DebugSentry from '../apis/DebugSentry';


class BuyTests extends React.Component {
  state = {
    test: [],
    bundle: [],
    show: 'true',
    search: '',
    is_search: [],
    currentPage:1,
    testPerPage:6,
    isProcessing:true
  };

  constructor(props) {
    super(props);

    DebugSentry.instantiate();
  }

  componentDidCatch(error, errorInfo) {
    DebugSentry.catchException(error, errorInfo);
  }

  componentDidMount() {
    this.fetchAllTest();
    this.fetchAllBundleTest();
  }

  fetchAllTest = () => {
    fetch("https://api2.diagnosemeafrica.com/api/v1/test/all")
      .then(response => response.json())
      .then(response => this.setState({ test: response.data,isProcessing:false }))
      .catch(error => console.log("network error message: ", error));
  };

  fetchAllBundleTest = () => {
    fetch("https://api2.diagnosemeafrica.com/api/v1/test/bundle/all")
      .then(response => response.json())
      .then(response => this.setState({ bundle: response.data }))
      .catch(error => console.log("network error message: ", error));
  };
  changeTest = () => {
    this.setState({ show: 'test' });
  };
  changeBundle = () => {
    this.setState({ show: 'true' });
  };

  searchTest = (e) => {
        this.setState({show:'false'})

    this.setState({
     search: e.target.value
   });
   const { test } = this.state;
   let autoSearch = test

    let search = this.state.search.trim().toLowerCase();

   if(search.length > 0){

     autoSearch = test.filter((l) => {
       let allSearch = l.title.toLowerCase().match( search ) ;
       return allSearch;
     });
   } 
  else if(search.length  == 1) {
    this.setState({test:test, show:'true'})
   }


   this.setState({is_search:autoSearch})
 }

 //change page pagination
 paginate =(number) => {
   this.setState({currentPage: number})
 }

  render() {
   

    const { search, isProcessing, currentPage, testPerPage, show, test, bundle ,is_search} = this.state;

    const indexOfLastTest = currentPage * testPerPage
    const indexofFirstTest = indexOfLastTest - testPerPage
    const currentTest = test.slice(indexofFirstTest, indexOfLastTest)
    return (
      <div>
        <div className="bg-transparent">
          <img src={bgelementsHomepage} id="bgelementsOtherpages" alt=""></img>
          <Container>
            <div className="buy-tests-card">
              <Row className="section-padding">
                {/* <Col md={6} className="my-auto">
                  <p className="title-header my-auto text-center-mobile">
                    Our Health Tests
                  </p>
                </Col> */}
                <Col
                  md={6}
                  className="newsletter-box"
                  style={{ padding: "20px" }}
                >
                  <Form.Control
                    type="email"
                    placeholder="Search test name"
                    className="height-input-auto"
                    name="search"
                    autoComplete="off"
                    onChange={this.searchTest}
                  />
                  <Button
                    variant="primary"
                    className="btn-custom newsletter-button"
                    type="button"
                    value=""
                    onClick={this.searchTest}
                  >
                    
                      Search
                    
                  </Button>
                </Col>
              </Row>
              <Row>
                <Col md={12}>
                  <div className="test-categories">
                    <div className="test-category" onClick={this.changeBundle}>
                      <p className="test-category">All Tests</p>
                    </div>
                    <div className="test-category" onClick={this.changeTest}>
                      <p className="test-category">Bundle Tests</p>
                    </div>
                  </div>
                </Col>
              </Row>
              <Row>
                <div className="tests-on-homepage margin-fix">
                  {isProcessing ?
                  <div className="text-center mx-auto">
                  <BallPulseSync color={"#F05F87"} loading="true" />
                  <p className="loading-p">Loading...</p>
                </div> : show === 'true'
                    ? currentTest.map(row => {
                        return (
                          <Col md={4} key={row.id}>
                            <TestCard
                              images={row.file}
                              testName={row.title}
                              description={row.description}
                              price={row.price}
                              sample={row.sample_required}
                              why={row.why_get_tested}
                              test_for={row.test_for}
                              testId={row.id}
                              is_bundle={row.is_bundle}
                              delivery_methods={row.delivery_methods}
                              label={"Buy Tests"}
                            />
                          </Col>
                        );
                      })
                    : show === 'test' ? bundle.map(row => {
                        return (
                          <Col md={4} key={row.id}>
                           <TestCard
                              images={row.file}
                              testName={row.title}
                              description={row.description}
                              price={row.price}
                              sample={row.sample_required}
                              why={row.why_get_tested}
                              test_for={row.test_for}
                              testId={row.id}
                              is_bundle={row.is_bundle}
                              delivery_methods={row.delivery_methods}
                              label={"Buy Tests"}
                            />
                          </Col>
                        );
                      })
                    : show == 'false' ? is_search.map(row => {
                      return (
                        <Col md={4} key={row.id}>
                          
                          <TestCard
                            images={row.file}
                            testName={row.title}
                            description={row.description}
                            price={row.price}
                            label={"Buy Test"}
                          />
                        </Col>
                      );
                    }):''}
                </div>
              </Row>
              {
                this.state.show == 'false'  ?

                <div>

                <div className="mx-auto pt-2 pb-2 text-center">
                  <b>No results found</b>
                </div>

                <div className="mx-auto pt-2 pb-2 text-center">
                Notify me when a test for "{search}" is available
                </div>

                <Form>
                <div className="search-notification-box">
                    <Form.Control type="email" placeholder="Enter email address" className="" />
                    <Button variant="primary" className="pink-button" type="submit" value="Submit">
                      <Link to="/" className="pink-button newsletter-button">Submit</Link>
                    </Button> 
                </div>
                </Form>

                </div>

                : ''
            }
             {
                this.state.show == 'true'  ?
                <Row style={{margin: '0 auto', width:'0%'}}>
                <Pagination testPerPage={testPerPage} totalTest={test.length} paginate={this.paginate} />
              </Row> : ''
            }
            </div>              
          </Container>
        </div>
        <ToastContainer autoClose={2000} />
        {/* //Featured Tests Section */}
      </div>
    );
  }
}

BuyTests.propTypes = {
  test: PropTypes.array,
  bundle: PropTypes.array
};

const mapStateToProps = state => {

  return state
};

export default connect(mapStateToProps)(BuyTests);
