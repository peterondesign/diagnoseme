import diagnosemeApi from "./../apis/diagnosemeApi";
import diagnosemeApiV2 from "./../apis/diagnosemeApiV2";
import {
  UPDATE_ORDER_PAYLOAD,
  GET_AIRPORT,
  GET_DEPENDENTS,
  GET_COLLECTION_CENTERS,
  ADD_DEPENDENT,
  CREATE_ORDER,
  GET_ORDER_USER_DETAILS,
  GET_PENDING_BOOKINGS,
  GET_ALL_PENDING_BOOKINGS,
  BOOK_APPOINTMENT,
  VALIDATE_COUPON,
} from "./types";

import { toast } from "react-toastify";
import Cookies from "universal-cookie";
import history from "./../history";

export const updatePayload = (payload) => async (dispatch) => {
  console.log(payload);
  dispatch({
    type: UPDATE_ORDER_PAYLOAD,
    payload,
  });
};

export const getAirports = () => async (dispatch) => {
  await diagnosemeApiV2.get("airports").then(
    (response) => {
      console.log(response);
      if (response.data.success) {
        dispatch({
          type: GET_AIRPORT,
          payload: response.data,
        });
      }
    },
    (error) => {}
  );
};

export const getDependents = (id) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .get("fetch-dependents", {
      headers: headers,
    })
    .then(
      (response) => {
        dispatch({
          type: GET_DEPENDENTS,
          payload: response.data,
        });
      },
      (error) => {}
    );
};

export const addDependent = (dependent) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .post(
      "add-dependent",
      {
        name: dependent.name,
        phone: dependent.phone,
        gender: dependent.gender,
        dob: dependent.dob,
        first_name: dependent.first_name,
        last_name: dependent.last_name,
        email: dependent.email,
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      }
      if (response.data.success) {
        toast.success(response.data.message);
      }
      dispatch({
        type: ADD_DEPENDENT,
        payload: response.data.data,
      });
    })
    .catch((error) => {});
};

export const validateCoupon = (details) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .post(
      "validate-coupon",
      {
        coupon_code: details.coupon_code,
        count: details.count,
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.data);
      }
      if (response.data.success) {
        toast.success(response.data.message);
      }
      dispatch({
        type: VALIDATE_COUPON,
        payload: response.data,
      });
    })
    .catch((error) => {});
};

export const createOrder = (payload) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .post("order/complete", payload, {
      headers: headers,
    })
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      }
      if (response.data.success) {
        toast.success(response.data.message);
        localStorage.setItem("transaction", JSON.stringify(response.data.data));
        localStorage.removeItem("collection_center");
        localStorage.removeItem("order");
        localStorage.removeItem("centers");
        localStorage.removeItem("selectedAiportState");
        localStorage.removeItem("payload");
        localStorage.removeItem("response");
        localStorage.removeItem("covid_checkout");
      }
      dispatch({
        type: CREATE_ORDER,
        payload: response.data.data,
      });
    })
    .catch((error) => {});
};

export const bookAppointment = (payload) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .post("commercial/booking", payload, {
      headers: headers,
    })
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      }
      if (response.data.success) {
        toast.success(response.data.message);
        history.push("/appointment/success");
      }
      dispatch({
        type: BOOK_APPOINTMENT,
        payload: response.data.data,
      });
    })
    .catch((error) => {});
};

export const getCollectionCenters = () => async (dispatch) => {
  await diagnosemeApi.get(`collection_center/all`).then(
    (response) => {
      dispatch({
        type: GET_COLLECTION_CENTERS,
        payload: response.data,
      });
    },
    (error) => {}
  );
};

export const getOrderUserDetails = (order_id) => async (dispatch) => {
  await diagnosemeApiV2.get(`order/user/details/${order_id}`).then(
    (response) => {
      dispatch({
        type: GET_ORDER_USER_DETAILS,
        payload: response.data,
      });
    },
    (error) => {}
  );
};

export const getPendingBookings = (transaction_id) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .get(`transactions/${transaction_id}/pending-bookings`, {
      headers: headers,
    })
    .then(
      (response) => {
        dispatch({
          type: GET_PENDING_BOOKINGS,
          payload: response.data,
        });
      },
      (error) => {}
    );
};

export const getAllPendingBookings = () => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApiV2
    .get(`account/pending-bookings`, {
      headers: headers,
    })
    .then(
      (response) => {
        dispatch({
          type: GET_ALL_PENDING_BOOKINGS,
          payload: response.data,
        });
      },
      (error) => {}
    );
};
