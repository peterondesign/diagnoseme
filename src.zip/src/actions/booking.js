import diagnosemeApi from "./../apis/diagnosemeApi";
import {
  GET_PASSPORT_NUMBER,
  COLLECTION_CENTER_TIME_SLOTS
} from "../actions/types";
import { toast } from "react-toastify";
 
export const findPassport = passport_number => async dispatch => {
  await diagnosemeApi.post(`booking/find_passport`, passport_number).then(
    response => {
      console.log("data sent successfully: " + response.data.data );
      console.log("data sent successfully String: " + JSON.stringify(response));
      dispatch({
        type: GET_PASSPORT_NUMBER,
        payload: response.data
      });

      if (
        !response.data.success &&
        response.data.data === "Resource not found"
      ) {
        toast.error("Passport number cannot be found."); 
      }
      if (
        response.data.success &&
        response.data.message === "Appointment already booked"
      ) {
        toast.error("Your appointment has been booked already.");
      }
    },
    error => {
      toast.error(error);
    }
  );
};

export const getTimeSlots = data => async dispatch => {
  await diagnosemeApi.post(`booking/getBookingDetails`, data).then(
    response => {
      dispatch({
        type: COLLECTION_CENTER_TIME_SLOTS,
        payload: response.data
      });

      if (
        !response.data.success &&
        response.data.data === "Resource not found"
      ) {
        toast.error("An error occurred. Please try again");
      }
    },
    error => {
      toast.error(error);
    }
  );
};
