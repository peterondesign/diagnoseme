import Cookies from 'universal-cookie';

import { MAKE_PAYMENT } from './types';

import diagnosemeApi from "./../apis/diagnosemeApi";

export const makePayment = data => async dispatch => {
    const cookies = new Cookies();
    const headers = {
        'Content-Type': 'application/json',
        'authorization': cookies.get("authorization")
      }
    
    await diagnosemeApi
    .post("consumer/order/test/create", data, {
        headers: headers
      })
      .then((response) => {
        dispatch({
          type: MAKE_PAYMENT,
          payload: response.data
        })
      })
      .catch((error) => {
        dispatch({
          type: MAKE_PAYMENT,
          payload: error
        })
      })
}
  
  