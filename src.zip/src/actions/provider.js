import diagnosemeApi from "./../apis/diagnosemeApi";
import { toast } from "react-toastify";

export const registerProvider = user => async dispatch => {
  await diagnosemeApi
    .post("provider/register", {
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      phone: user.phone,
      hospital_name: user.hospital_name,
      role: user.role,
    })
    .then(
      response => {
          
        if (response.data.data === "Email address already exists") {
          return toast.error(response.data.data);
        }

        if (response.data.data === "Phone number already exists") {
            return toast.error(response.data.data);
          }

        if (response.data.success) {
          dispatch({
            type: "PROVIDER_REQUEST",
            payload: response
          });
          toast.success("We have received your request for a user account on our DiagnoseMe provider portal. A DiagnoseMe representative will contact you shortly.");
        }
      },
      error => {
        toast.error(error);
      }
    );
};

