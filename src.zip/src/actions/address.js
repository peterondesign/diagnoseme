import { ADD_ADDRESS } from './types';

export const addAddress = (user) => {
    return {
        type: ADD_ADDRESS,
        payload: user
    }
}
