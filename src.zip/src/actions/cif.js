import { CIF1, CIF2, CIF3, CIF4, CIF5 } from './types';

export const add_cif1 = (user) => {
    return {
        type: CIF1,
        payload: user
    }
}

export const add_cif2 = (user) => {
    return {
        type: CIF2,
        payload: user
    }
}

export const add_cif3 = (user) => {
    return {
        type: CIF3,
        payload: user
    }
}

export const add_cif4 = (user) => {
    return {
        type: CIF4,
        payload: user
    }
}

export const add_cif5 = (user) => {
    return {
        type: CIF5,
        payload: user
    }
}


