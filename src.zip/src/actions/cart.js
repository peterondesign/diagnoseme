import { ADD_TO_CART, DELETE_FROM_CART, EMPTY_CART } from './types';

export const addToCart = (testId, test, price, is_bundle, quantity) => {
    return {
        type: ADD_TO_CART,
        payload: {
            testId,
            test,
            price,
            is_bundle,
            quantity
        }
    }
}

export const deleteFromCart = (id,price) => {
    return {
        type: DELETE_FROM_CART,
        payload: {
            id,
            price
        }
    }
}

export const emptyCart = () => {
    return {
        type: EMPTY_CART
    }
}


