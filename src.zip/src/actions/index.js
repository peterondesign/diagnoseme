import diagnosemeApi from "./../apis/diagnosemeApi";
import {
  LOGIN,
  REGISTER,
  FORGOT_PASSWORD,
  ALL_TESTS,
  ALL_BANNERS,
  EMAIL_CHECK,
  PHONE_CHECK,
  FEATURED_TESTS,
  TOKEN_CHECK,
  RESET_PASSWORD,
  GET_PIN,
  DEACTIVATE_ACCOUNT,
  DELETE_ACCOUNT,
  CHANGE_PASSWORD,
  COMPLETE_ACCOUNT_SETUP,
  VERIFY_COVID_USER,
  BOOK_RETURNEE_APPOINTMENT,
  GET_RETURNEE_FLIGHT,
  UPDATE_ORDER_PAYLOAD,
} from "./types";
import history from './../history';
import { toast } from "react-toastify";
import Cookies from "universal-cookie";

export const register = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/create", {
      name: user.name,
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      confirm_email: user.confirm_email,
      phone: user.phone,
      gender: user.gender,
      dob: user.dob,
      password: user.password,
      state: user.state,
      pin: user.pin,
    })
    .then(
      (response) => {
        if (response.data.message === "Validation Error.") {
          return toast.error(response.data.data);
        }

        if (response.data.success) {
          toast.success(response.data.message)
          dispatch({
            type: REGISTER,
            payload: response.data,
          });
          history.push("/auth/login");
        }
      },
      (error) => {
        toast.error(error);
      }
    );
};

export const bookReturneeAppointment = (data) => async (dispatch) => {
  // console.log(data.family);
  await diagnosemeApi
    .post("returnee/create", {
      phone: data.phone,
      address: data.address,
      country_of_departure: data.country_of_departure,
      state_of_arrival: data.state_of_arrival,
      date_of_arrival: data.date_of_arrival,
      flight_number: data.flight_number,
      company_id: data.company_id,
      sample_collection_center: data.sample_collection_center,
      family: data.family,
    })
    .then(
      (response) => {
        if (response.data.message === "Validation Error.") {
          return toast.error(response.data.data);
        }

        if (response.data.success) {
          dispatch({
            type: BOOK_RETURNEE_APPOINTMENT,
            payload: response.data,
          });
          toast.success(response.data.message);
          setTimeout(function () {
            window.location.href = "/booking/success";
          }, 1000);
        }
      },
      (error) => {
        console.log(error);
        toast.error(error);
      }
    );
};

export const getFlight = (number) => async (dispatch) => {
  await diagnosemeApi.get(`returnee/flight/find/${number}`).then(
    (response) => {
      dispatch({
        type: GET_RETURNEE_FLIGHT,
        payload: response.data,
      });
    },
    (error) => {
      toast.error(error);
    }
  );
};

export const completeAccountSetup = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/complete/account", {
      name: user.name,
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      phone: user.phone,
      gender: user.gender,
      dob: user.dob,
      password: user.password,
      state: user.state,
      email_token: user.email_token,
      pin: user.pin,
    })
    .then(
      (response) => {
        console.log(response);
        if (response.data.message === "Validation Error.") {
          return toast.error(response.data.data);
        }
        if (response.data.success) {
          dispatch({
            type: COMPLETE_ACCOUNT_SETUP,
            payload: response.data,
          });
          toast.success(response.data.message);
          history.push("/auth/login");
          setTimeout(function () {
            window.location.href = "/auth/login";
          }, 3000);
        }
      },
      (error) => {
        toast.error(error);
      }
    );
};

export const fetchTests = () => async (dispatch) => {
  const response = await diagnosemeApi.get("test/all");
  dispatch({
    type: ALL_TESTS,
    payload: response.data,
  });
};

export const fetchFeaturedTests = () => async (dispatch) => {
  const response = await diagnosemeApi.get("test/featured");
  dispatch({
    type: FEATURED_TESTS,
    payload: response.data,
  });
};

export const BannerTests = () => async (dispatch) => {
  const response = await diagnosemeApi.get("banners/all");
  dispatch({
    type: ALL_BANNERS,
    payload: response.data,
  });
};

export const login = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/login", {
      email: user.email,
      password: user.password,
      user_agent: navigator.userAgent,
      device: "",
    })
    .then(
      (response) => {
        if (response.data.data === "Incorrect Login Credentials") {
          console.log(response);
          toast.error(response.data.data);
          dispatch({
            type: LOGIN,
            payload: { failed_login: true },
          });
        }

        if (response.data.data === "Account is currently Deactivated") {
          console.log(response);
          toast.error(response.data.data);
          dispatch({
            type: LOGIN,
            payload: response.data,
          });
        }

        if (response.data.success) {
          console.log(response);
          localStorage.setItem("user", JSON.stringify(response.data.data.user));
          const cookies = new Cookies();
          cookies.set("authorization", response.data.data.authorization, {
            path: "/",
          });
          dispatch({
            type: LOGIN,
            payload: response.data,
          });
          toast.success(response.data.message);
          if (localStorage.getItem("checkout")) {
            window.location.href = "/checkout";
          }
          if (localStorage.getItem("covid_checkout")) {
            let payload = JSON.parse(localStorage.getItem("payload"));
            dispatch({
              type: UPDATE_ORDER_PAYLOAD,
              payload,
            });
            window.location.href = "/order/details";
          }

          setTimeout(function () {
            window.location.href = "/account/dashboard";
          }, 1000);
        }
      },
      (error) => {
        console.log(error);
        toast.error(error);
      }
    );
};

export const loginCheckout = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/login", {
      email: user.email,
      password: user.password,
    })
    .then(
      (response) => {
        if (response.data.data === "Incorrect Login Credentials") {
          toast.error(response.data.data);
          dispatch({
            type: LOGIN,
            payload: response.data,
          });
        }

        if (response.data.success) {
          localStorage.setItem("user", JSON.stringify(response.data.data.user));

          const cookies = new Cookies();
          cookies.set("authorization", response.data.data.authorization, {
            path: "/",
          });

          dispatch({
            type: LOGIN,
            payload: response.data,
          });
          toast.success(response.data.message);

          if (localStorage.getItem("checkout")) {
            window.location.href = "/checkout";
          } else if (localStorage.getItem("covid_checkout")) {
            let payload = JSON.parse(localStorage.getItem("payload"));
            dispatch({
              type: UPDATE_ORDER_PAYLOAD,
              payload,
            });
            window.location.href = "/order/details";
          } else {
            window.location.href = "/account/dashboard";
          }

          localStorage.setItem("user", JSON.stringify(response.data.data.user));
        }
      },
      (error) => {
        toast.error(error);
      }
    );
};

export const forgotPassword = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/forgot-password", {
      email: user.email,
    })
    .then(
      (response) => {
        if (response.data.message === "This email does not exist") {
          toast.error("Email address does not exist");
        }

        if (response.data.success) {
          dispatch({
            type: FORGOT_PASSWORD,
            payload: response.data,
          });
          toast.success(
            "Great! A link to reset your password has been sent to your email address."
          );
          history.push("/auth/login");
          setTimeout(function () {
            window.location.href = "/auth/login";
          }, 5000);
        }
      },
      (error) => {
        toast.error(error);
      }
    );
};

export const verifyCovidUser = (token) => async (dispatch) => {
  await diagnosemeApi.get(`consumer/user/verify-user/covid/${token}`).then(
    (response) => {
      dispatch({
        type: VERIFY_COVID_USER,
        payload: response.data,
      });
    },
    (error) => {}
  );
};

export const emailCheck = (email) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/email/check", {
      email: email,
    })
    .then(
      (response) => {
        dispatch({
          type: EMAIL_CHECK,
          payload: response.data,
        });
      },
      (error) => {}
    );
};

export const phoneCheck = (phone) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/phone/check", {
      phone: phone,
    })
    .then(
      (response) => {
        dispatch({
          type: PHONE_CHECK,
          payload: response.data,
        });
      },
      (error) => {}
    );
};

export const checkResetPasswordToken = (token) => async (dispatch) => {
  await diagnosemeApi.get("consumer/user/reset-password/" + token).then(
    (response) => {
      dispatch({
        type: TOKEN_CHECK,
        payload: response.data,
      });
    },
    (error) => {}
  );
};

export const resetPassword = (user) => async (dispatch) => {
  await diagnosemeApi
    .post("consumer/user/reset-password/" + user.token, {
      email: user.email,
      password: user.password,
    })
    .then(
      (response) => {
        toast.success("Password reset is successful");
        window.location.href = "/auth/login";
        dispatch({
          type: RESET_PASSWORD,
          payload: response.data,
        });
      },
      (error) => {}
    );
};

export const getPin = (password) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApi
    .post(
      "consumer/user/pin/retrieval",
      {
        password: password,
        user_agent: navigator.userAgent,
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      } else {
        toast.success("Authentication successful");
      }
      dispatch({
        type: GET_PIN,
        payload: response.data.data,
      });
    })
    .catch((error) => {
      dispatch({
        type: GET_PIN,
        payload: error,
      });
    });
};

export const deactivateAccount = (password) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApi
    .post(
      "consumer/user/account/deactivate",
      {
        password: password,
        user_agent: navigator.userAgent,
        device: "",
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      } else {
        toast.success("Account Successfully Deactivated");
        localStorage.removeItem("user");
        cookies.remove("authorization");
        window.location.href = "/";
      }
      dispatch({
        type: DEACTIVATE_ACCOUNT,
        payload: response.data.data,
      });
    })
    .catch((error) => {
      dispatch({
        type: DEACTIVATE_ACCOUNT,
        payload: error,
      });
    });
};

export const deleteAccount = (password) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApi
    .post(
      "consumer/user/account/delete",
      {
        password: password,
        user_agent: navigator.userAgent,
        device: "",
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error(response.data.message);
      } else {
        toast.success("Account Successfully Deleted");
        localStorage.removeItem("user");
        cookies.remove("authorization");
        window.location.href = "/";
      }
      dispatch({
        type: DELETE_ACCOUNT,
        payload: response.data.data,
      });
    })
    .catch((error) => {
      dispatch({
        type: DELETE_ACCOUNT,
        payload: error,
      });
    });
};

export const changePassword = (user) => async (dispatch) => {
  const cookies = new Cookies();
  const headers = {
    "Content-Type": "application/json",
    authorization: cookies.get("authorization"),
  };

  await diagnosemeApi
    .post(
      "consumer/user/change/password",
      {
        old_password: user.old_password,
        new_password: user.new_password,
        user_agent: navigator.userAgent,
      },
      {
        headers: headers,
      }
    )
    .then((response) => {
      if (!response.data.success) {
        toast.error("Incorrect Password");
      } else {
        toast.success("Password successfully changed");
        window.location.href = "/account/dashboard";
      }
      dispatch({
        type: CHANGE_PASSWORD,
        payload: response.data.data,
      });
    })
    .catch((error) => {
      dispatch({
        type: CHANGE_PASSWORD,
        payload: error,
      });
    });
};
